# CoralScapes Segmentation Benchmark — U-Net vs SegFormer vs YOLO-Seg

An end-to-end, reproducible comparison of three segmentation architectures on the
official **CoralScapes** coral-reef dataset.

The question this project answers experimentally: *which architecture gives the best
overall performance on CoralScapes?* No model is assumed to win. The conclusion in
`outputs/comparison/final_comparison.md` is generated **from the measured results
only** — every unmeasured cell renders as `N/A` rather than being filled in.

---

## 1. Dataset facts (verified programmatically, not assumed)

Read straight from the local copy of the official release:

| Property | Value |
| --- | --- |
| Layout | Cityscapes-style: `leftImg8bit/<split>/<site>/`, `gtFine/<split>/<site>/` |
| Images | **2,075** total — 1,517 train / 166 val / 392 test |
| Resolution | 2048 × 1024 RGB (uniform) |
| Masks | 8-bit single-channel PNG holding raw class ids |
| Classes | **39 named classes** (ids 1–39) from `classes.json`, plus id **0 = unlabelled/void** |
| Palette | Official `colors.json`, used for every figure in the project |
| Sites | 35 dive sites: 27 train / 3 val / 5 test |
| Split integrity | **Site-disjoint** — no site appears in two splits (asserted at load time) |

The official split is used exactly as shipped and is never reshuffled.

### Label handling

Class id 0 is absent from `classes.json` and is treated as unlabelled/void. The
networks emit **40 logits so that channel *i* is class id *i*** — no remapping, no
invented ids. Channel 0 is never supervised (it is the loss `ignore_index`) and is
masked out at argmax, so a model can never predict the void label. Void pixels are
dropped before the confusion matrix is updated.

Analysis groups (used for reporting only — **the ground truth is never modified**):

- **Algae**: `algae covered substrate` (id 10)
- **Bleaching**: `other coral bleached` (4), `massive/meandering bleached` (16),
  `branching bleached` (19), `meandering bleached` (33)

---

## 2. Install

```bash
# PyTorch matching your GPU (CUDA 12.8 build needed for Blackwell / RTX 50-series)
pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128
pip install -r requirements.txt
```

Verify CUDA is live before training:

```bash
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
```

Point the code at your dataset copy if it is not at `../coralscapes/coralscapes`:

```bash
export CORALSCAPES_ROOT=/path/to/coralscapes      # PowerShell: $env:CORALSCAPES_ROOT=...
```

---

## 3. Run order

Each step is independent and re-runnable. Steps 1–3 are CPU work; 4–6 need the GPU.

```bash
# 1. EDA — writes dataset_stats.json (also produces the class weights used by the losses)
python -m src.explore

# 2. Convert semantic masks -> YOLO instance polygons
python -m src.annotation_conversion

# 3. VERIFY the conversion visually before training anything on it
python -m src.verify_yolo --n 20
#    inspect outputs/visualizations/yolo_annotation_verification/ and STOP if wrong

# 4. Sanity-check the models without committing to a training run
python -m src.train_unet --sanity-only
python -m src.train_segformer --sanity-only
python -m src.train_yolo --sanity-only

# 5. Train (validation-selected checkpoints; the test split is untouched here)
python -m src.train_unet       --epochs 18 --batch-size 4
python -m src.train_segformer  --epochs 18 --batch-size 4
python -m src.train_yolo       --epochs 30 --batch 8

# 6. Evaluate ONCE on the official test split, then benchmark and report
python -m src.evaluate --models unet segformer yolo_seg
python -m src.benchmark
python -m src.qualitative
python -m src.report --print
```

Single-image inference with any of the three models:

```bash
python -m src.predict path/to/reef.jpg --model segformer
```

```python
from src.predict import predict, visualize_prediction
result = predict("reef.jpg", "yolo_seg")   # "unet" | "segformer" | "yolo_seg"
visualize_prediction(result, save_path="demo.png")
```

`result` has the same keys for every model — `mask` (CoralScapes class ids),
`classes`, `inference_time_ms` — plus `instances` (box, mask, class, confidence)
for YOLO-Seg only.

### Tuning for your GPU

Everything lives in `src/config.py` and is overridable per run:

```bash
python -m src.train_unet --image-size 384 384 --batch-size 2   # if 8 GB is tight
```

---

## 4. Method notes

### Data leakage
The official split is site-disjoint, and `assert_no_site_leakage` re-verifies this at
load time (raising if any site or image stem appears in two splits). This matters
more than file-level de-duplication: images from one dive site are highly correlated,
so a shared site would leak even with no duplicated file. The test split is read by
`src/evaluate.py` only, once; checkpoint selection uses validation mIoU alone.

### Augmentation
Geometric ops (scale, crop, flip, ±12° rotate) are applied to image and mask
**together**, with the mask always resampled `NEAREST` so class ids are never blended.
Photometric ops (mild brightness/contrast/HSV) touch the image only. Masks are never
normalised. Colour jitter is kept mild deliberately: bleaching classes are *defined by
being pale*, so aggressive saturation shifts would corrupt the label semantics.
Vertical flips are excluded — transect imagery has a consistent gravity direction.

### Loss
Default **CE + Dice** with sqrt-inverse-frequency class weights (clipped to [0.25, 6]).
CoralScapes is severely long-tailed, which makes plain CE ignore the tail at almost no
cost; Dice scores each class on set overlap so a rare class counts as much as a common
one, and directly optimises the quantity mIoU measures. Full inverse-frequency
weighting was rejected — with a >10⁴ frequency ratio it destabilises training. Weighted
CE, Dice, Focal and plain CE are all available via `--loss` for re-running the choice.

### Training protocol (identical for both semantic models)
Same loss, resolution, schedule, augmentation and seed — so the comparison isolates
the architecture. AdamW with no weight decay on norm/bias terms, discriminative LRs
(encoder 3e-5, decoder 3e-4), linear warm-up → cosine decay, 2 epochs of frozen-encoder
decoder warm-up then full fine-tuning, AMP, grad clipping, early stopping on val mIoU.

### Semantic → instance conversion (the honest caveat)
CoralScapes ships **semantic** annotations; YOLO-Seg needs **instances**. The only
available signal is spatial connectivity, so each 8-connected component becomes one
instance. That is sound for some classes and wrong for others, so every class is tagged
in `data/yolo_seg/class_mapping.json`:

- **thing** — countable, discrete (fish, urchin, clam, human, trash). A component
  really is one object, unless two individuals overlap.
- **colony** — coral classes. A component is a *patch* of that morphotype, not one
  biological colony: adjacent colonies merge, an occluded colony splits. The masks are
  valid; the instance *counts* are not biologically meaningful.
- **stuff** — amorphous, uncountable (sand, background, rubble, dark, unknown hard
  substrate, **algae covered substrate**, seagrass, transect line). "One instance of
  sand" is not a meaningful object; there is no canonical decomposition at all.

Consequences carried into the results: for *stuff* classes, mAP measures how well YOLO
reproduces our connected-component heuristic, not a biologist's notion of detection —
which is exactly why the algae comparison reports mask IoU/Dice next to AP. Polygons
also cannot represent holes (a fish in front of coral is exported as a filled outer
contour), and `approxPolyDP` discards sub-pixel boundary detail.

`src/verify_yolo.py` quantifies this by rasterising the polygons back and comparing to
the original semantic mask. **That agreement is the ceiling YOLO-Seg could ever reach**
and is reported alongside its scores.

### Metrics
Pixel metrics come from one 40×40 confusion matrix per split: IoU = TP/(TP+FP+FN),
Dice = 2TP/(2TP+FP+FN), plus precision, recall and pixel accuracy. A class absent from
the split and never predicted is `NaN` and excluded from means — scoring it 0 would
punish a model for a class the split does not contain. Boundary quality uses
**Boundary IoU** (1% image-diagonal band) and **Boundary F1** (3 px contour tolerance),
accumulated over the split before dividing.

Ordinary image-classification accuracy is never used as a headline metric.

### Comparing across paradigms
Semantic mIoU and instance mAP are reported **side by side and never blended**. mAP
scores *ranked instance detections*; mIoU scores *pixel labelling*; no monotone
relation connects them. To place YOLO-Seg on the pixel axis at all, its instance masks
are rasterised into a semantic map (large regions painted first). Pixels covered by no
detection stay unlabelled and count as false negatives — a real property of applying an
instance model to an exhaustive-labelling task, and reported as
`mean_unclaimed_pixel_fraction`.

### Statistical reliability
95% CIs come from a percentile bootstrap resampling **whole images** (pixels within an
image are far from independent). Model pairs are compared with a **paired** bootstrap
on the same images. A difference whose CI contains zero is reported as *not resolvable
on this test set*, not as a win.

---

## 5. Project structure

```
coralscapes-segmentation/
├── data/yolo_seg/          generated YOLO dataset (images, labels, yaml, mapping)
├── notebooks/
│   └── coralscapes_benchmark.ipynb
├── src/
│   ├── config.py               paths, label metadata, hyper-parameters, seeding
│   ├── dataset.py              split indexing, leakage assertion, Dataset
│   ├── transforms.py           synchronised augmentation
│   ├── losses.py               CE / weighted CE / Dice / Focal / CE+Dice
│   ├── metrics.py              confusion matrix, boundary metrics, bootstrap
│   ├── models.py               U-Net + SegFormer builders
│   ├── engine.py               shared training loop
│   ├── sanity.py               pre-training invariant checks
│   ├── explore.py              EDA
│   ├── annotation_conversion.py  semantic masks -> YOLO polygons
│   ├── verify_yolo.py          visual + numeric verification
│   ├── train_unet.py / train_segformer.py / train_yolo.py
│   ├── evaluate.py             test-split evaluation (all three models)
│   ├── benchmark.py            parameters, latency, FPS, GPU memory
│   ├── qualitative.py          side-by-side comparison + error analysis
│   ├── explain.py              segmentation Grad-CAM, attention, confidence
│   ├── predict.py              unified predict(image_path, model_name)
│   └── report.py               final tables + conclusion
├── checkpoints/            best_unet.pth, best_segformer.pth, best_yolo_seg.pt
├── outputs/{unet,segformer,yolo_seg,visualizations,metrics,comparison}/
├── requirements.txt
└── README.md
```

---

## 6. Reproducibility

`set_seed()` seeds Python, NumPy, PyTorch (CPU + CUDA). Every run records its config,
library versions, hardware and training time into the outputs. The dataset version is
pinned by the local copy's `classes.json` / `colors.json`, which are read rather than
hard-coded, so a dataset revision that changed the label space would be detected by
`verify_label_mapping` rather than silently mis-scored.

Note that full bitwise determinism is not enforced by default: `cudnn.benchmark` is on
for speed. Pass `set_seed(seed, deterministic=True)` to trade throughput for exact
reproducibility.

---

## 7. Status

The code is complete and sanity-checked. Training runs are launched by the user — see
the run order in §3. Until `outputs/metrics/*.json` exist, `src/report.py` renders every
cell as `N/A` and states that no model can be recommended yet. That is intentional:
**no winner is declared before the experiments have actually been run.**

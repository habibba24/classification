# Setup and run on another machine

Complete from-scratch instructions. Copy-paste each block in order.

Assumes: **NVIDIA GPU**, **Python 3.10–3.12**, and a working internet connection.

---

## If you are an AI agent executing this file, read this first

**Prerequisites you cannot satisfy yourself — verify, then stop and ask if missing:**

1. The `coralscapes/` dataset folder (5.5 GB) must already be on this machine. You
   cannot download it from the original machine. Confirm with `python -m src.config`,
   which must print `exists=True`. If it prints `exists=False`, stop and ask the user
   for the dataset location — do not attempt to fetch a substitute dataset.
2. `python --version` must be 3.10–3.12. On 3.13+ some wheels do not exist. Stop and
   ask rather than building packages from source.

**Rules that must not be worked around.** This project's guards are deliberate, and
disabling one silently invalidates the experiment:

- **Never** train, tune, or select a checkpoint on the `test` split. It is read exactly
  once, by `src/evaluate.py`. Model selection uses `val` only.
- **Never** write results you did not measure. `src/report.py` renders `N/A` for
  anything unmeasured and refuses to name a winner without data. That behaviour is
  correct — do not "complete" a table by estimating, and do not declare a best model
  before the experiments have run.
- **Never** bypass the YOLO verification gate. `train_yolo.py` refusing to start
  without `src/verify_yolo.py` having run is intended. Run the conversion and
  verification instead of removing the check.
- **Do not** edit the ground-truth labels, remap class ids, or change the official
  train/val/test split.

**Long-running steps — run them in the background, never in a call that can time out
and be retried.** The conversion takes 15–25 min; each training run 35–60 min. A retry
loop over a partially finished training run wastes hours and can corrupt checkpoints.

**Report honestly.** If a step fails, say so and show the error. A partial benchmark
that is clearly labelled is useful; one that looks complete but contains invented
numbers is worse than nothing.

**One step needs a human:** after `src/verify_yolo.py`, the 20 figures in
`outputs/visualizations/yolo_annotation_verification/` should be reviewed by the user
before YOLO training. You may inspect them and summarise what you see, but ask the
user to confirm rather than deciding alone that the conversion is acceptable.

For the reasoning behind these rules (label handling, the semantic→instance conversion
caveats, why mAP and mIoU are not combined), read `README.md` §4.

---

## Step 1 — Copy two folders to the new machine

Keep them side by side, exactly like this:

```
<anywhere>\
├── coralscapes\              <- the dataset  (5.5 GB)
│   └── coralscapes\
│       ├── classes.json
│       ├── colors.json
│       ├── leftImg8bit\{train,val,test}\<site>\...
│       └── gtFine\{train,val,test}\<site>\...
└── coralscapes-segmentation\ <- this project (1.1 MB)
```

**Copy the project folder including `outputs/`.** It already contains
`outputs/metrics/dataset_stats.json` from a completed EDA run over all 2,075 masks, so
`python -m src.explore` loads from cache instead of re-scanning (~2 min saved), and the
loss class weights are read from that file. The `final_comparison.md` in there is an
all-`N/A` placeholder — `src/report.py` overwrites it once real results exist.

The code finds the dataset at `../coralscapes/coralscapes` relative to the project.
If you put it somewhere else, set this once per terminal session instead:

```powershell
$env:CORALSCAPES_ROOT = "D:\wherever\coralscapes\coralscapes"     # PowerShell
```
```bash
export CORALSCAPES_ROOT=/wherever/coralscapes/coralscapes          # Linux/macOS
```

---

## Step 2 — Check Python and GPU

```powershell
python --version
nvidia-smi
```

Note the **CUDA Version** printed top-right by `nvidia-smi` — you need it in Step 3.

---

## Step 3 — Install PyTorch (must match your GPU)

Pick the line for your card. This is the only place GPU choice matters.

```powershell
# RTX 50-series (Blackwell: 5050/5060/5070/5080/5090) -- REQUIRED for these cards
python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cu128

# RTX 20/30/40-series, or any older CUDA 12.x driver
python -m pip install torch torchvision --index-url https://download.pytorch.org/whl/cu124

# No NVIDIA GPU (CPU only -- training will be very slow, but everything runs)
python -m pip install torch torchvision
```

Verify before continuing:

```powershell
python -c "import torch; print(torch.__version__, '| cuda:', torch.cuda.is_available())"
```

Must print `cuda: True` (unless you deliberately installed the CPU build).
If it prints `False` on an NVIDIA machine, you used the wrong index URL — reinstall
with `--force-reinstall` and the correct one.

---

## Step 4 — Install everything else

```powershell
cd coralscapes-segmentation
python -m pip install -r requirements.txt
```

Confirm it all imports:

```powershell
python -c "import torch, cv2, albumentations, segmentation_models_pytorch, ultralytics, transformers, sklearn, timm; print('all imports OK')"
```

Re-check torch was not downgraded by the batch (ultralytics declares a torch
dependency and pip occasionally swaps in a CPU build):

```powershell
python -c "import torch; print(torch.__version__, torch.cuda.is_available())"
```

---

## Step 5 — Confirm the dataset is visible

```powershell
python -m src.config
```

Expected output:

```
DATA_ROOT      : ...\coralscapes\coralscapes  (exists=True)
NUM_CLASSES    : 40 logits, 39 evaluated classes
IGNORE_INDEX   : 0 (unlabeled)
```

plus your GPU name and memory. If `exists=False`, fix `CORALSCAPES_ROOT` (Step 1).

---

## Step 6 — Run the pipeline

Order matters. Times below are for an 8 GB laptop GPU; a desktop card will be faster.

```powershell
# --- data analysis (CPU, ~2 min) -------------------------------------------
# Scans all 2,075 masks. Produces the class weights the losses need,
# and asserts the official split is site-disjoint (no data leakage).
python -m src.explore

# --- sanity checks (~1 min each, no training) ------------------------------
# Batch shapes, forward pass, one optimisation step. Catches wiring bugs
# before you commit hours to training.
python -m src.train_unet --sanity-only
python -m src.train_segformer --sanity-only

# --- YOLO annotation conversion (CPU, ~15-25 min) --------------------------
# Semantic masks -> instance polygons, then validates every label file.
python -m src.annotation_conversion

# --- VERIFY the conversion, then LOOK at the figures -----------------------
python -m src.verify_yolo --n 20
#   open: outputs\visualizations\yolo_annotation_verification\
#   Do not train YOLO until these look right.

python -m src.train_yolo --sanity-only
```

### Training

```powershell
python -m src.train_unet      --epochs 18 --batch-size 4     # ~45 min
python -m src.train_segformer --epochs 18 --batch-size 4     # ~35 min
python -m src.train_yolo      --epochs 30 --batch 8          # ~60 min
```

If you hit a CUDA out-of-memory error, lower the load:

```powershell
python -m src.train_unet --image-size 384 384 --batch-size 2
python -m src.train_yolo --batch 4 --imgsz 512
```

With a big GPU (16 GB+), go the other way:

```powershell
python -m src.train_unet --image-size 512 1024 --batch-size 8 --epochs 40
```

### Evaluation and report

```powershell
python -m src.evaluate --models unet segformer yolo_seg   # reads the test split ONCE
python -m src.benchmark                                   # params, latency, FPS, VRAM
python -m src.qualitative                                 # comparison + error figures
python -m src.report --print                              # final tables + conclusion
```

Final results land in:

```
outputs\comparison\final_comparison.md
outputs\metrics\
outputs\visualizations\
checkpoints\best_unet.pth, best_segformer.pth, best_yolo_seg.pt
```

---

## Run it all in one go

**PowerShell** — stops at the first failure:

```powershell
$ErrorActionPreference = "Stop"
python -m src.explore
python -m src.train_unet --sanity-only
python -m src.train_segformer --sanity-only
python -m src.annotation_conversion
python -m src.verify_yolo --n 20
python -m src.train_unet --epochs 18 --batch-size 4
python -m src.train_segformer --epochs 18 --batch-size 4
python -m src.train_yolo --epochs 30 --batch 8
python -m src.evaluate --models unet segformer yolo_seg
python -m src.benchmark
python -m src.qualitative
python -m src.report --print
```

**Linux/macOS:**

```bash
set -e
python -m src.explore && \
python -m src.train_unet --sanity-only && \
python -m src.train_segformer --sanity-only && \
python -m src.annotation_conversion && \
python -m src.verify_yolo --n 20 && \
python -m src.train_unet --epochs 18 --batch-size 4 && \
python -m src.train_segformer --epochs 18 --batch-size 4 && \
python -m src.train_yolo --epochs 30 --batch 8 && \
python -m src.evaluate --models unet segformer yolo_seg && \
python -m src.benchmark && python -m src.qualitative && python -m src.report --print
```

⚠️ The one-shot version skips the human check on the YOLO polygons. Review
`outputs\visualizations\yolo_annotation_verification\` afterwards regardless — if the
polygons are wrong, the YOLO numbers are meaningless.

---

## The notebook — read the results, not a second way to train

```powershell
python -m pip install jupyter
jupyter notebook notebooks/coralscapes_benchmark.ipynb
```

**Run it after the CLI, not instead of it.** Every evaluation cell checks for cached
results first (`if res_path.exists(): load cached`), so once training and evaluation
have run, the notebook renders the real numbers, per-class tables, qualitative
comparisons and the conclusion in seconds. That is what it is for: the readable
write-up, with the figures inline next to the reasoning that explains them.

Training from the notebook is possible — set `RUN_TRAINING = True` (section 12) and
`RUN_CONVERSION = True` (section 17) — but it is not recommended for the real runs. A
kernel restart, a sleeping laptop or a dropped browser connection loses a 45-minute
run; the CLI scripts checkpoint every improving epoch and survive all three. Use the
flags for a short experiment, the CLI for the actual benchmark.

Nothing in the notebook is required to obtain results. If you only want the numbers,
run the CLI and read `outputs\comparison\final_comparison.md`.

---

## Downloads that happen automatically on first run

Pretrained weights are fetched on demand (not in `requirements.txt`):

| What | Size | Triggered by |
| --- | --- | --- |
| ResNet50 ImageNet weights | ~100 MB | `train_unet` |
| SegFormer `nvidia/mit-b0` | ~15 MB | `train_segformer` |
| `yolo11n-seg.pt` | ~6 MB | `train_yolo` |

They are cached, so this is a one-time cost per machine.

---

## State of the project at handoff — what is tested and what is not

The code was written and partially verified on a different machine, where the package
install never completed over a very slow link. Be precise about what that means.

**Verified by actually running it:**

- dataset indexing and the site-disjointness / leakage assertion (27 train / 3 val /
  5 test sites, no overlap)
- confusion-matrix IoU, Dice, precision, recall — checked against hand-computed values
- group pooling (an intra-group confusion correctly scores as correct)
- all five losses: finite loss and gradients, `ignore_index` respected, an all-ignore
  batch returns 0 rather than NaN, rare classes outweigh common ones
- bootstrap CIs, and the paired test correctly reporting two identical models as
  *not resolvable*
- `src/report.py` rendering `N/A` throughout and refusing to name a winner with no
  data, and producing correct rankings against synthetic metrics
- the full EDA over all 2,075 masks
- every module byte-compiles

**Never executed (needs the packages that failed to install):** the model sanity
checks, the mask→polygon conversion, and all training and evaluation. The pipeline's
last mile is therefore untested end to end.

### Expected failure points, most likely first

All three fail fast — within a minute, not 45 — which is deliberate.

| Suspect | Where it surfaces |
| --- | --- |
| Ultralytics API drift (`val.seg` / `val.box`) | `src/evaluate.py`, after YOLO training. The per-class AP lookup is already hardened against `ap_class_index` moving, but the metric objects themselves were never exercised. |
| albumentations 2.x argument names | first `--sanity-only` run. Written against the 2.x `fill` / `fill_mask` / `mask_interpolation` API, which matches albumentations 2.0.8, but never run. |
| CUDA out of memory | first training epoch. Fix with `--batch-size 2`, then `--image-size 384 384`. |

The sanity checks exist precisely to catch the first two before any long run:

```powershell
python -m src.train_unet --sanity-only
python -m src.train_segformer --sanity-only
```

### Two findings from the EDA worth watching in the results

1. **Algae prevalence shifts across splits** — 6.1% of labelled pixels in train, 1.9%
   in val, **10.3% in test**. This is inherent to site-based splitting (different reefs
   have different composition), not a bug. Consequence: validation will *understate*
   test algae performance, and algae carries outsized weight in the test mIoU.
2. **Bleaching is ~1% of pixels**, spread over four subclasses (the rarest,
   `meandering bleached`, is 0.049% of train). Expect noisy per-subclass IoU; the
   aggregated bleaching group metric is the more stable read. Report both — the
   per-subclass numbers use the original unmodified labels.

Also note: **val is missing two classes** (`seagrass`, `turbinaria`) that exist in
train and test. They are scored `NaN` and excluded from means rather than counted as
zero, but it does mean model selection is blind to them.

---

## Troubleshooting

**`ModuleNotFoundError: No module named 'src'`** — run from the project root
(`coralscapes-segmentation`), and use `python -m src.xxx`, not `python src/xxx.py`.

**`FileNotFoundError` on `classes.json`** — dataset path wrong; see Step 1 and re-run
`python -m src.config`.

**CUDA out of memory** — lower `--batch-size` then `--image-size`, in that order.

**`RuntimeError: no kernel image is available`** — your torch CUDA build doesn't match
your GPU. RTX 50-series needs `cu128` (Step 3).

**DataLoader crashes / hangs on Windows** — add `--num-workers 0`.

**YOLO training refuses to start** — deliberate. It requires
`python -m src.annotation_conversion` and `python -m src.verify_yolo --n 20` to have
run first, so nobody trains on unverified polygons.

# CoralScapes segmentation benchmark - final comparison

All numbers below are read directly from the evaluation artefacts in `outputs/metrics/`. Cells marked N/A were not measured or are not applicable to that architecture; none are estimated.

## Segmentation quality (official test split)

| Metric | U-Net | SegFormer | YOLO-Seg |
| --- | --- | --- | --- |
| mIoU | N/A | N/A | N/A |
| Mean Dice | N/A | N/A | N/A |
| Pixel accuracy | N/A | N/A | N/A |
| Frequency-weighted IoU | N/A | N/A | N/A |
| Algae IoU | N/A | N/A | N/A |
| Bleaching IoU (aggregated) | N/A | N/A | N/A |
| Mean Boundary IoU | N/A | N/A | N/A |
| Mean Boundary F1 | N/A | N/A | N/A |

YOLO-Seg's column is obtained by rasterising its predicted instance masks into a semantic map; see the caveat below.

## Detection / instance performance

| Metric | U-Net | SegFormer | YOLO-Seg |
| --- | --- | --- | --- |
| Precision (pixel, macro) | N/A | N/A | N/A |
| Recall (pixel, macro) | N/A | N/A | N/A |
| Precision (instance) | N/A | N/A | N/A |
| Recall (instance) | N/A | N/A | N/A |
| mAP@50 (mask) | N/A | N/A | N/A |
| mAP@50:95 (mask) | N/A | N/A | N/A |
| mAP@50 (box) | N/A | N/A | N/A |
| mAP@50:95 (box) | N/A | N/A | N/A |

mAP is undefined for U-Net and SegFormer: they emit no instances and no detection scores to rank, so there is nothing to average precision over. The cells are N/A, not zero.

## Computational benchmark

| Model | Parameters | Model Size (MB) | Inference Time (ms) | FPS | Peak GPU Mem (MB) |
| --- | --- | --- | --- | --- | --- |
| U-Net | N/A | N/A | N/A | N/A | N/A |
| SegFormer | N/A | N/A | N/A | N/A | N/A |
| YOLO-Seg | N/A | N/A | N/A | N/A | N/A |


## Algae-specific analysis

**Algae (aggregated group)**

| Metric | U-Net | SegFormer | YOLO-Seg |
| --- | --- | --- | --- |
| Iou (pixel) | N/A | N/A | N/A |
| Dice (pixel) | N/A | N/A | N/A |
| Precision (pixel) | N/A | N/A | N/A |
| Recall (pixel) | N/A | N/A | N/A |
| Mask AP@50 (instance) | N/A | N/A | N/A |

**Algae - original classes**

| Class (original id) | Metric | U-Net | SegFormer | YOLO-Seg |
| --- | --- | --- | --- | --- |
| algae covered substrate (10) | Iou | N/A | N/A | N/A |
| algae covered substrate (10) | Dice | N/A | N/A | N/A |
| algae covered substrate (10) | Precision | N/A | N/A | N/A |
| algae covered substrate (10) | Recall | N/A | N/A | N/A |

## Bleaching-specific analysis

**Bleaching (aggregated group)**

| Metric | U-Net | SegFormer | YOLO-Seg |
| --- | --- | --- | --- |
| Iou (pixel) | N/A | N/A | N/A |
| Dice (pixel) | N/A | N/A | N/A |
| Precision (pixel) | N/A | N/A | N/A |
| Recall (pixel) | N/A | N/A | N/A |
| Mask AP@50 (instance) | N/A | N/A | N/A |

**Bleaching - original classes, unmodified labels**

| Class (original id) | Metric | U-Net | SegFormer | YOLO-Seg |
| --- | --- | --- | --- | --- |
| branching bleached (19) | Iou | N/A | N/A | N/A |
| branching bleached (19) | Dice | N/A | N/A | N/A |
| branching bleached (19) | Precision | N/A | N/A | N/A |
| branching bleached (19) | Recall | N/A | N/A | N/A |
| other coral bleached (4) | Iou | N/A | N/A | N/A |
| other coral bleached (4) | Dice | N/A | N/A | N/A |
| other coral bleached (4) | Precision | N/A | N/A | N/A |
| other coral bleached (4) | Recall | N/A | N/A | N/A |
| massive/meandering bleached (16) | Iou | N/A | N/A | N/A |
| massive/meandering bleached (16) | Dice | N/A | N/A | N/A |
| massive/meandering bleached (16) | Precision | N/A | N/A | N/A |
| massive/meandering bleached (16) | Recall | N/A | N/A | N/A |
| meandering bleached (33) | Iou | N/A | N/A | N/A |
| meandering bleached (33) | Dice | N/A | N/A | N/A |
| meandering bleached (33) | Precision | N/A | N/A | N/A |
| meandering bleached (33) | Recall | N/A | N/A | N/A |

Aggregation rule: the four official bleached-coral classes are pooled one-vs-rest and a confusion between two bleached subclasses counts as correct. The ground truth is never modified; the per-class rows above use the original labels.

## Statistical reliability

No paired-bootstrap comparison found (`outputs/metrics/statistical_comparison.json` missing).

## Final conclusion

## Conclusion

No evaluation results are present in `outputs/metrics/`, so no model can be compared or recommended yet. Train the models and run `python -m src.evaluate` first. This section is generated strictly from measured results and is deliberately left empty rather than populated with expectations.

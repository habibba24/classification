"""CoralScapes semantic/instance segmentation benchmark.

Package layout
--------------
config                 paths, label metadata, hyper-parameters, seeding
dataset                official-split indexing, leakage check, PyTorch Dataset
transforms             synchronised image/mask augmentation
losses                 CE / weighted CE / Dice / Focal / CE+Dice and class weights
metrics                confusion matrix, IoU/Dice/precision/recall, boundary, bootstrap
models                 U-Net (ResNet50) and SegFormer builders
engine                 shared training loop for the two semantic models
sanity                 pre-training invariant checks
explore                exploratory data analysis
annotation_conversion  semantic masks -> YOLO instance polygons
verify_yolo            visual + numeric verification of that conversion
train_unet             U-Net training entry point
train_segformer        SegFormer training entry point
train_yolo             YOLO-Seg training entry point
evaluate               test-split evaluation for all three models
benchmark              parameters, latency, FPS, GPU memory
qualitative            side-by-side comparisons and error analysis
explain                segmentation Grad-CAM, attention, confidence maps
predict                unified predict(image_path, model_name) interface
report                 final comparison tables and conclusion
"""

__version__ = "1.0.0"

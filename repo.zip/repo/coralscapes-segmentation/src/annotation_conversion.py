"""CoralScapes semantic masks -> YOLO instance-segmentation annotations.

WHY THIS IS NOT A LOSSLESS CONVERSION
-------------------------------------
CoralScapes ships *semantic* segmentation: every pixel carries a class id and
nothing distinguishes one coral colony from the one touching it. YOLO-Seg needs
*instances*. The only signal available for splitting a semantic mask into
instances is spatial connectivity, so this module treats each 8-connected
component of a class as one instance. That assumption is sound for some classes
and plainly wrong for others, so every class is tagged:

  thing  -- countable, physically discrete objects (fish, sea urchin, clam,
            human, trash, ...). A connected component really is one object,
            except when two individuals overlap in the image, in which case
            they merge into a single instance.

  colony -- coral classes. A connected component is a *patch* of coral of that
            morphotype, not necessarily one biological colony: adjacent
            colonies of the same class merge into one component, and a single
            colony occluded by a fish splits into two. Counts are therefore not
            biologically meaningful, though the masks themselves are.

  stuff  -- amorphous, uncountable background (sand, water/background, rubble,
            dark, unknown hard substrate, algae covered substrate, seagrass,
            transect line). "One instance of sand" is not a meaningful object;
            these regions have no canonical instance decomposition at all.

Consequences that MUST be carried into the results discussion:
  * For 'stuff' classes the instance decomposition is an artefact of this
    conversion, not a property of the data. Instance metrics (mAP) over those
    classes measure how well the model reproduces our connected-component
    heuristic -- they are not comparable to a biologist's notion of detection.
    Algae ('algae covered substrate') is one of these classes, which is exactly
    why the algae comparison in this project reports mask IoU/Dice alongside AP.
  * Polygons cannot represent holes. A region with an interior hole (a fish in
    front of a coral patch) is exported as its filled outer contour, which
    slightly inflates the instance mask relative to the semantic ground truth.
  * Contour simplification (approxPolyDP) discards sub-pixel boundary detail.

The conversion is therefore run with `policy='all'` by default -- every class
is exported so the three models can be compared on the same classes, including
algae and the bleaching classes -- while the class 'kind' is recorded in the
mapping JSON so the analysis can qualify each number appropriately.

Outputs (under data/yolo_seg/):
    images/{train,val,test}/<stem>.jpg
    labels/{train,val,test}/<stem>.txt        # cls x1 y1 x2 y2 ... (normalised)
    coralscapes_yolo.yaml
    class_mapping.json                        # YOLO index <-> CoralScapes id
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from dataclasses import dataclass
from pathlib import Path

import numpy as np
from PIL import Image
from tqdm import tqdm

from .config import (ID_TO_NAME, IGNORE_INDEX, VALID_CLASS_IDS, YOLO_DATA_DIR)
from .dataset import SPLITS, index_all_splits

# --------------------------------------------------------------------------- #
# Class taxonomy: is a connected component a meaningful instance?
# --------------------------------------------------------------------------- #
CLASS_KIND: dict[str, str] = {
    # amorphous background / substrate -- no canonical instance decomposition
    "background": "stuff",
    "sand": "stuff",
    "rubble": "stuff",
    "unknown hard substrate": "stuff",
    "algae covered substrate": "stuff",
    "dark": "stuff",
    "seagrass": "stuff",
    "transect line": "stuff",
    # countable discrete objects
    "human": "thing",
    "fish": "thing",
    "transect tools": "thing",
    "sea urchin": "thing",
    "sea cucumber": "thing",
    "anemone": "thing",
    "sponge": "thing",
    "clam": "thing",
    "dead clam": "thing",
    "other animal": "thing",
    "trash": "thing",
    "crown of thorn": "thing",
    # coral patches: masks valid, instance counts not biologically meaningful
    "branching bleached": "colony",
    "branching dead": "colony",
    "branching alive": "colony",
    "stylophora alive": "colony",
    "pocillopora alive": "colony",
    "acropora alive": "colony",
    "table acropora alive": "colony",
    "table acropora dead": "colony",
    "millepora": "colony",
    "turbinaria": "colony",
    "other coral bleached": "colony",
    "other coral dead": "colony",
    "other coral alive": "colony",
    "massive/meandering alive": "colony",
    "massive/meandering dead": "colony",
    "massive/meandering bleached": "colony",
    "meandering alive": "colony",
    "meandering dead": "colony",
    "meandering bleached": "colony",
}


def select_class_ids(policy: str = "all") -> list[int]:
    """Which CoralScapes classes to export as YOLO classes."""
    if policy == "all":
        return list(VALID_CLASS_IDS)
    if policy == "things_only":
        return [c for c in VALID_CLASS_IDS if CLASS_KIND[ID_TO_NAME[c]] == "thing"]
    if policy == "things_and_colonies":
        return [c for c in VALID_CLASS_IDS
                if CLASS_KIND[ID_TO_NAME[c]] in ("thing", "colony")]
    raise ValueError(f"unknown policy {policy!r}")


@dataclass
class ConversionConfig:
    policy: str = "all"
    out_size: tuple[int, int] = (1024, 512)   # (W, H) written to disk
    min_area_px: int = 96                     # at out_size; drops annotation specks
    min_area_frac: float = 0.0
    approx_eps_frac: float = 0.0015           # approxPolyDP eps = frac * perimeter
    max_instances_per_image: int = 300
    max_points_per_polygon: int = 200
    jpeg_quality: int = 92


# --------------------------------------------------------------------------- #
# Mask -> polygons
# --------------------------------------------------------------------------- #
def mask_to_polygons(binary: np.ndarray, cfg: ConversionConfig) -> list[np.ndarray]:
    """Connected components of a binary class mask -> simplified polygons.

    Returns a list of (N, 2) float arrays in *pixel* coordinates. Holes are not
    representable in the YOLO polygon format, so only external contours are
    kept (documented limitation above).
    """
    import cv2

    polygons: list[np.ndarray] = []
    n_labels, labels, stats, _ = cv2.connectedComponentsWithStats(
        binary.astype(np.uint8), connectivity=8)

    h, w = binary.shape
    min_area = max(cfg.min_area_px, int(cfg.min_area_frac * h * w))

    for comp in range(1, n_labels):                      # 0 is the background
        area = stats[comp, cv2.CC_STAT_AREA]
        if area < min_area:
            continue
        comp_mask = (labels == comp).astype(np.uint8)
        contours, _ = cv2.findContours(comp_mask, cv2.RETR_EXTERNAL,
                                       cv2.CHAIN_APPROX_SIMPLE)
        for contour in contours:
            if len(contour) < 3:
                continue
            peri = cv2.arcLength(contour, True)
            eps = max(1.0, cfg.approx_eps_frac * peri)
            approx = cv2.approxPolyDP(contour, eps, True).reshape(-1, 2)
            if len(approx) < 3:
                # too aggressive: fall back to the unsimplified contour
                approx = contour.reshape(-1, 2)
                if len(approx) < 3:
                    continue
            if len(approx) > cfg.max_points_per_polygon:
                idx = np.linspace(0, len(approx) - 1, cfg.max_points_per_polygon)
                approx = approx[idx.astype(int)]
            if cv2.contourArea(approx.astype(np.int32)) < min_area * 0.5:
                continue
            polygons.append(approx.astype(np.float64))
    return polygons


def polygons_to_yolo_lines(polygons_by_class: dict[int, list[np.ndarray]],
                           width: int, height: int,
                           coral_to_yolo: dict[int, int],
                           cfg: ConversionConfig) -> list[str]:
    """Normalise to [0,1] and format as `cls x1 y1 x2 y2 ...` lines."""
    entries: list[tuple[float, str]] = []
    for coral_id, polys in polygons_by_class.items():
        yolo_id = coral_to_yolo[coral_id]
        for poly in polys:
            p = poly.astype(np.float64).copy()
            p[:, 0] = np.clip(p[:, 0], 0, width - 1) / width
            p[:, 1] = np.clip(p[:, 1], 0, height - 1) / height
            p = np.clip(p, 0.0, 1.0)
            if len(p) < 3:
                continue
            area = 0.5 * abs(np.dot(p[:, 0], np.roll(p[:, 1], 1))
                             - np.dot(p[:, 1], np.roll(p[:, 0], 1)))
            coords = " ".join(f"{v:.6f}" for v in p.reshape(-1))
            entries.append((area, f"{yolo_id} {coords}"))

    # keep the largest instances if an image exceeds the per-image cap
    entries.sort(key=lambda kv: -kv[0])
    return [line for _, line in entries[: cfg.max_instances_per_image]]


# --------------------------------------------------------------------------- #
# Full-dataset conversion
# --------------------------------------------------------------------------- #
def convert_split(split: str, samples, coral_to_yolo: dict[int, int],
                  cfg: ConversionConfig, out_root: Path,
                  limit: int | None = None, write_images: bool = True) -> dict:
    import cv2

    img_dir = out_root / "images" / split
    lbl_dir = out_root / "labels" / split
    img_dir.mkdir(parents=True, exist_ok=True)
    lbl_dir.mkdir(parents=True, exist_ok=True)

    W, H = cfg.out_size
    stats = {"n_images": 0, "n_instances": 0, "empty_labels": 0,
             "instances_per_class": Counter(), "instances_per_image": []}

    subset = samples[:limit] if limit else samples
    for s in tqdm(subset, desc=f"convert {split}", unit="img"):
        image = np.array(Image.open(s.image_path).convert("RGB"))
        mask = np.array(Image.open(s.mask_path))
        if mask.ndim == 3:
            mask = mask[..., 0]

        img_small = cv2.resize(image, (W, H), interpolation=cv2.INTER_AREA)
        # NEAREST only: resizing labels with interpolation would invent class ids
        mask_small = cv2.resize(mask, (W, H), interpolation=cv2.INTER_NEAREST)

        polygons_by_class: dict[int, list[np.ndarray]] = {}
        for coral_id in coral_to_yolo:
            binary = (mask_small == coral_id)
            if not binary.any():
                continue
            polys = mask_to_polygons(binary, cfg)
            if polys:
                polygons_by_class[coral_id] = polys

        lines = polygons_to_yolo_lines(polygons_by_class, W, H, coral_to_yolo, cfg)

        if write_images:
            Image.fromarray(img_small).save(img_dir / f"{s.stem}.jpg",
                                            quality=cfg.jpeg_quality)
        with open(lbl_dir / f"{s.stem}.txt", "w", encoding="utf-8") as fh:
            fh.write("\n".join(lines) + ("\n" if lines else ""))

        stats["n_images"] += 1
        stats["n_instances"] += len(lines)
        stats["instances_per_image"].append(len(lines))
        if not lines:
            stats["empty_labels"] += 1
        for line in lines:
            stats["instances_per_class"][int(line.split()[0])] += 1

    stats["instances_per_class"] = dict(stats["instances_per_class"])
    ipi = stats["instances_per_image"]
    stats["mean_instances_per_image"] = float(np.mean(ipi)) if ipi else 0.0
    stats["max_instances_per_image"] = int(np.max(ipi)) if ipi else 0
    stats.pop("instances_per_image")
    return stats


def write_dataset_yaml(out_root: Path, yolo_to_coral: dict[int, int]) -> Path:
    names = {i: ID_TO_NAME[c] for i, c in sorted(yolo_to_coral.items())}
    lines = [
        "# CoralScapes converted to YOLO instance-segmentation format.",
        "# Generated by src/annotation_conversion.py -- do not edit by hand.",
        "# Splits are the OFFICIAL CoralScapes splits (site-disjoint).",
        f"path: {out_root.as_posix()}",
        "train: images/train",
        "val: images/val",
        "test: images/test",
        "",
        "names:",
    ]
    lines += [f"  {i}: {n}" for i, n in names.items()]
    path = out_root / "coralscapes_yolo.yaml"
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def convert_dataset(cfg: ConversionConfig = ConversionConfig(),
                    out_root: Path = YOLO_DATA_DIR, limit_per_split: int | None = None,
                    splits=SPLITS, write_images: bool = True) -> dict:
    """Convert the official splits and write the YOLO dataset directory."""
    out_root.mkdir(parents=True, exist_ok=True)
    class_ids = select_class_ids(cfg.policy)
    coral_to_yolo = {c: i for i, c in enumerate(class_ids)}
    yolo_to_coral = {i: c for c, i in coral_to_yolo.items()}

    index = index_all_splits()
    report = {
        "policy": cfg.policy,
        "out_size": list(cfg.out_size),
        "min_area_px": cfg.min_area_px,
        "approx_eps_frac": cfg.approx_eps_frac,
        "n_yolo_classes": len(class_ids),
        "coral_id_to_yolo_index": {str(k): v for k, v in coral_to_yolo.items()},
        "yolo_index_to_coral_id": {str(k): v for k, v in yolo_to_coral.items()},
        "yolo_index_to_name": {str(i): ID_TO_NAME[c] for i, c in yolo_to_coral.items()},
        "class_kind": {ID_TO_NAME[c]: CLASS_KIND[ID_TO_NAME[c]] for c in class_ids},
        "splits": {},
    }
    for split in splits:
        report["splits"][split] = convert_split(
            split, index[split], coral_to_yolo, cfg, out_root,
            limit=limit_per_split, write_images=write_images)

    yaml_path = write_dataset_yaml(out_root, yolo_to_coral)
    report["yaml"] = str(yaml_path)
    with open(out_root / "class_mapping.json", "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    print(f"wrote {yaml_path} and class_mapping.json")
    return report


def load_mapping(out_root: Path = YOLO_DATA_DIR) -> dict:
    with open(out_root / "class_mapping.json", "r", encoding="utf-8") as fh:
        return json.load(fh)


# --------------------------------------------------------------------------- #
# Validation of the written labels
# --------------------------------------------------------------------------- #
def validate_labels(out_root: Path = YOLO_DATA_DIR, splits=SPLITS,
                    n_classes: int | None = None) -> dict:
    """Programmatic checks on every written label file (spec section 8).

    Verifies: coordinates normalised into [0,1], polygons non-empty with >= 3
    points, an even coordinate count, class ids inside range, and that every
    label file has a matching image.
    """
    mapping = load_mapping(out_root)
    n_classes = n_classes or mapping["n_yolo_classes"]
    problems: list[str] = []
    totals = {"files": 0, "instances": 0, "empty_files": 0}

    for split in splits:
        lbl_dir = out_root / "labels" / split
        img_dir = out_root / "images" / split
        if not lbl_dir.is_dir():
            continue
        for lbl in sorted(lbl_dir.glob("*.txt")):
            totals["files"] += 1
            if not (img_dir / f"{lbl.stem}.jpg").exists():
                problems.append(f"{lbl.name}: no matching image")
            lines = [l for l in lbl.read_text(encoding="utf-8").splitlines() if l.strip()]
            if not lines:
                totals["empty_files"] += 1
                continue
            for i, line in enumerate(lines):
                parts = line.split()
                totals["instances"] += 1
                cls = int(parts[0])
                coords = np.array(parts[1:], dtype=np.float64)
                if not (0 <= cls < n_classes):
                    problems.append(f"{lbl.name}:{i} class {cls} out of range")
                if len(coords) % 2 != 0:
                    problems.append(f"{lbl.name}:{i} odd coordinate count")
                if len(coords) < 6:
                    problems.append(f"{lbl.name}:{i} fewer than 3 points")
                if coords.size and (coords.min() < 0.0 or coords.max() > 1.0):
                    problems.append(f"{lbl.name}:{i} coordinates outside [0,1] "
                                    f"[{coords.min():.3f},{coords.max():.3f}]")
    result = {"totals": totals, "n_problems": len(problems),
              "problems": problems[:50], "passed": not problems}
    print(f"validated {totals['files']} label files, {totals['instances']} instances: "
          f"{'PASSED' if result['passed'] else str(len(problems)) + ' PROBLEMS'}")
    if problems:
        for p in problems[:10]:
            print("   ", p)
    return result


# --------------------------------------------------------------------------- #
# Rasterisation back to a semantic mask (for the cross-paradigm comparison)
# --------------------------------------------------------------------------- #
def rasterize_yolo_label(label_path: Path, height: int, width: int,
                         yolo_to_coral: dict[int, int]) -> np.ndarray:
    """Render a YOLO polygon label file back into a semantic id mask.

    Used to quantify how much information the polygon conversion itself loses,
    independently of any model: rasterised-GT vs original-GT IoU is the ceiling
    that YOLO-Seg could ever reach on this dataset.
    """
    import cv2

    canvas = np.zeros((height, width), dtype=np.uint8)
    lines = [l for l in Path(label_path).read_text(encoding="utf-8").splitlines()
             if l.strip()]
    polys: list[tuple[float, int, np.ndarray]] = []
    for line in lines:
        parts = line.split()
        coral_id = yolo_to_coral[int(parts[0])]
        coords = np.array(parts[1:], dtype=np.float64).reshape(-1, 2)
        coords[:, 0] *= width
        coords[:, 1] *= height
        pts = coords.astype(np.int32)
        area = cv2.contourArea(pts)
        polys.append((area, coral_id, pts))

    # paint large regions first so small objects stay visible on top
    for _, coral_id, pts in sorted(polys, key=lambda t: -t[0]):
        cv2.fillPoly(canvas, [pts], int(coral_id))
    return canvas


def main() -> None:
    ap = argparse.ArgumentParser(description="Convert CoralScapes to YOLO-Seg format")
    ap.add_argument("--policy", default="all",
                    choices=["all", "things_only", "things_and_colonies"])
    ap.add_argument("--out-size", type=int, nargs=2, default=[1024, 512],
                    metavar=("W", "H"))
    ap.add_argument("--min-area-px", type=int, default=96)
    ap.add_argument("--eps-frac", type=float, default=0.0015)
    ap.add_argument("--limit-per-split", type=int, default=None,
                    help="convert only the first N images per split (smoke test)")
    ap.add_argument("--splits", nargs="+", default=list(SPLITS))
    ap.add_argument("--out-root", type=str, default=str(YOLO_DATA_DIR))
    ap.add_argument("--no-images", action="store_true",
                    help="write label files only")
    ap.add_argument("--validate", action="store_true",
                    help="validate existing labels instead of converting")
    args = ap.parse_args()

    out_root = Path(args.out_root)
    if args.validate:
        validate_labels(out_root, splits=tuple(args.splits))
        return

    cfg = ConversionConfig(policy=args.policy, out_size=tuple(args.out_size),
                           min_area_px=args.min_area_px, approx_eps_frac=args.eps_frac)
    report = convert_dataset(cfg, out_root, limit_per_split=args.limit_per_split,
                             splits=tuple(args.splits), write_images=not args.no_images)
    for split, st in report["splits"].items():
        print(f"  {split:5s}: {st['n_images']:4d} images, {st['n_instances']:6d} "
              f"instances, {st['mean_instances_per_image']:.1f}/img, "
              f"{st['empty_labels']} empty")
    validate_labels(out_root, splits=tuple(args.splits))


if __name__ == "__main__":
    main()

"""Computational benchmark: parameters, size, latency, FPS, GPU memory.

    python -m src.benchmark

Latency protocol: the GPU is warmed up, every timed run is bracketed by
`torch.cuda.synchronize()` (without it CUDA's asynchrony reports the launch
time, not the compute time), and the median over many runs is reported
alongside the mean, since the first runs after a memory allocation are slower.

All three models are timed at their own native inference resolution, which is
what a deployment would actually use; the resolutions are printed with the
numbers so the comparison is not read as resolution-free.
"""
from __future__ import annotations

import argparse
import json
import time
from pathlib import Path

import numpy as np
import torch

from .config import CFG, CHECKPOINT_DIR, NUM_CLASSES, OUTPUT_DIR, Config, get_device
from .models import build_model, count_parameters


def _sync(device) -> None:
    if device.type == "cuda":
        torch.cuda.synchronize()


@torch.no_grad()
def time_semantic_model(model, cfg: Config, device, image_size: tuple[int, int],
                        n_warmup: int = 10, n_runs: int = 50,
                        batch_size: int = 1, amp: bool = True) -> dict:
    model.eval().to(device)
    h, w = image_size
    x = torch.randn(batch_size, 3, h, w, device=device)

    for _ in range(n_warmup):
        with torch.autocast(device_type=device.type, dtype=torch.float16,
                            enabled=amp and device.type == "cuda"):
            model(x)
    _sync(device)

    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()

    times = []
    for _ in range(n_runs):
        _sync(device)
        t0 = time.perf_counter()
        with torch.autocast(device_type=device.type, dtype=torch.float16,
                            enabled=amp and device.type == "cuda"):
            model(x)
        _sync(device)
        times.append((time.perf_counter() - t0) * 1000.0)

    times = np.asarray(times)
    peak_mb = (torch.cuda.max_memory_allocated() / 1024 ** 2
               if device.type == "cuda" else float("nan"))
    return {
        "input_size": [h, w],
        "batch_size": batch_size,
        "amp": bool(amp and device.type == "cuda"),
        "latency_ms_mean": float(times.mean()),
        "latency_ms_median": float(np.median(times)),
        "latency_ms_std": float(times.std()),
        "latency_ms_p95": float(np.percentile(times, 95)),
        "fps": float(1000.0 * batch_size / np.median(times)),
        "peak_gpu_memory_mb": float(peak_mb),
        "n_runs": n_runs,
    }


def benchmark_yolo(weights: Path, cfg: Config, device, n_warmup: int = 10,
                   n_runs: int = 50) -> dict:
    """Time YOLO-Seg end to end, including its NMS and mask assembly.

    Ultralytics' own `speed` dict separates preprocess / inference / postprocess;
    postprocessing is a real cost for an instance model (the semantic models
    have no equivalent stage), so the total is reported as well as the raw
    forward pass.
    """
    from ultralytics import YOLO

    model = YOLO(str(weights))
    imgsz = cfg.yolo_image_size
    dummy = np.random.randint(0, 255, (imgsz, imgsz, 3), dtype=np.uint8)

    for _ in range(n_warmup):
        model.predict(dummy, imgsz=imgsz, verbose=False, device=device.type)
    _sync(device)

    if device.type == "cuda":
        torch.cuda.reset_peak_memory_stats()

    times, speeds = [], []
    for _ in range(n_runs):
        _sync(device)
        t0 = time.perf_counter()
        res = model.predict(dummy, imgsz=imgsz, verbose=False, device=device.type)
        _sync(device)
        times.append((time.perf_counter() - t0) * 1000.0)
        speeds.append(res[0].speed)

    times = np.asarray(times)
    n_params = sum(p.numel() for p in model.model.parameters())
    size_mb = sum(p.numel() * p.element_size() for p in model.model.parameters()) / 1024 ** 2
    peak_mb = (torch.cuda.max_memory_allocated() / 1024 ** 2
               if device.type == "cuda" else float("nan"))
    return {
        "input_size": [imgsz, imgsz],
        "batch_size": 1,
        "total_parameters": int(n_params),
        "parameter_size_mb": round(size_mb, 2),
        "checkpoint_size_mb": round(Path(weights).stat().st_size / 1024 ** 2, 2),
        "latency_ms_mean": float(times.mean()),
        "latency_ms_median": float(np.median(times)),
        "latency_ms_std": float(times.std()),
        "latency_ms_p95": float(np.percentile(times, 95)),
        "fps": float(1000.0 / np.median(times)),
        "peak_gpu_memory_mb": float(peak_mb),
        "ultralytics_speed_ms": {
            k: float(np.median([s[k] for s in speeds])) for k in speeds[0]},
        "n_runs": n_runs,
        "note": "latency includes NMS and mask assembly, which the semantic models "
                "do not have",
    }


def run(models=("unet", "segformer", "yolo_seg"), cfg: Config = CFG,
        n_runs: int = 50, batch_size: int = 1, save: bool = True) -> dict:
    device = get_device(cfg)
    results: dict[str, dict] = {"device": str(device), "amp": cfg.amp}
    if device.type == "cuda":
        p = torch.cuda.get_device_properties(0)
        results["gpu"] = {"name": p.name,
                          "memory_gb": round(p.total_memory / 1024 ** 3, 2)}

    for name in models:
        if name in ("unet", "segformer"):
            model = build_model(name, cfg, pretrained=False)
            ckpt = CHECKPOINT_DIR / f"best_{name}.pth"
            entry = count_parameters(model)
            if ckpt.exists():
                state = torch.load(ckpt, map_location="cpu", weights_only=False)
                model.load_state_dict(state["model_state_dict"])
                entry["checkpoint_size_mb"] = round(ckpt.stat().st_size / 1024 ** 2, 2)
                entry["trained"] = True
            else:
                entry["trained"] = False
                print(f"[{name}] no checkpoint; timing the untrained architecture "
                      "(identical compute cost)")
            entry.update(time_semantic_model(model, cfg, device, cfg.eval_image_size,
                                             n_runs=n_runs, batch_size=batch_size,
                                             amp=cfg.amp))
            results[name] = entry
            del model
            if device.type == "cuda":
                torch.cuda.empty_cache()
        elif name == "yolo_seg":
            w = CHECKPOINT_DIR / "best_yolo_seg.pt"
            if not w.exists():
                print("[yolo_seg] no checkpoint; skipping (train it first)")
                continue
            results["yolo_seg"] = benchmark_yolo(w, cfg, device, n_runs=n_runs)

    _print_table(results)
    if save:
        out = OUTPUT_DIR / "metrics" / "computational_benchmark.json"
        out.parent.mkdir(parents=True, exist_ok=True)
        with open(out, "w", encoding="utf-8") as fh:
            json.dump(results, fh, indent=2, default=float)
        print(f"\nwrote {out}")
    return results


def _print_table(results: dict) -> None:
    print(f"\n{'Model':<12}{'Params':>14}{'Size (MB)':>12}"
          f"{'Latency (ms)':>15}{'FPS':>9}{'GPU mem (MB)':>15}")
    print("-" * 77)
    for name in ("unet", "segformer", "yolo_seg"):
        r = results.get(name)
        if not r:
            continue
        params = r.get("total_parameters", 0)
        size = r.get("model_size_mb", r.get("parameter_size_mb", float("nan")))
        print(f"{name:<12}{params:>14,}{size:>12.2f}"
              f"{r['latency_ms_median']:>15.2f}{r['fps']:>9.1f}"
              f"{r['peak_gpu_memory_mb']:>15.1f}")


def main() -> None:
    ap = argparse.ArgumentParser(description="Computational benchmark")
    ap.add_argument("--models", nargs="+", default=["unet", "segformer", "yolo_seg"])
    ap.add_argument("--n-runs", type=int, default=50)
    ap.add_argument("--batch-size", type=int, default=1)
    args = ap.parse_args()
    run(models=tuple(args.models), n_runs=args.n_runs, batch_size=args.batch_size)


if __name__ == "__main__":
    main()

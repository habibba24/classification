"""Centralised configuration for the CoralScapes segmentation benchmark.

Everything that a user may want to tune (paths, resolution, optimisation
hyper-parameters, hardware) lives here so that no magic numbers are buried in
the training scripts.
"""
from __future__ import annotations

import json
import os
import random
from dataclasses import dataclass, field, asdict
from pathlib import Path

import numpy as np

# --------------------------------------------------------------------------- #
# Paths
# --------------------------------------------------------------------------- #
PROJECT_ROOT = Path(__file__).resolve().parents[1]
REPO_ROOT = PROJECT_ROOT.parent

# The official CoralScapes release ships in a Cityscapes-style layout:
#   <root>/leftImg8bit/{train,val,test}/<site>/*_leftImg8bit.png
#   <root>/gtFine/{train,val,test}/<site>/*_gtFine.png
DATA_ROOT = Path(os.environ.get("CORALSCAPES_ROOT", REPO_ROOT / "coralscapes" / "coralscapes"))

IMAGE_DIR_NAME = "leftImg8bit"
MASK_DIR_NAME = "gtFine"
IMAGE_SUFFIX = "_leftImg8bit.png"
MASK_SUFFIX = "_gtFine.png"

CHECKPOINT_DIR = PROJECT_ROOT / "checkpoints"
OUTPUT_DIR = PROJECT_ROOT / "outputs"
YOLO_DATA_DIR = PROJECT_ROOT / "data" / "yolo_seg"

for _d in (
    CHECKPOINT_DIR,
    OUTPUT_DIR,
    OUTPUT_DIR / "unet",
    OUTPUT_DIR / "segformer",
    OUTPUT_DIR / "yolo_seg",
    OUTPUT_DIR / "visualizations",
    OUTPUT_DIR / "metrics",
    OUTPUT_DIR / "comparison",
):
    _d.mkdir(parents=True, exist_ok=True)

# --------------------------------------------------------------------------- #
# Label space  (read from the official metadata -- never hard-coded)
# --------------------------------------------------------------------------- #
IGNORE_INDEX = 0  # pixel value 0 is absent from classes.json => unlabelled/void


def _load_json(name: str) -> dict:
    with open(DATA_ROOT / name, "r", encoding="utf-8") as fh:
        return json.load(fh)


def load_label_metadata() -> tuple[dict[int, str], dict[int, tuple[int, int, int]]]:
    """Return (id -> name) and (id -> RGB colour) from the official JSON files.

    Class id 0 does not appear in ``classes.json``; it is the unlabelled/void
    region and is added explicitly so that index i of any array corresponds to
    class id i.
    """
    name_to_id = _load_json("classes.json")
    name_to_color = _load_json("colors.json")

    id_to_name = {0: "unlabeled"}
    id_to_color = {0: (0, 0, 0)}
    for name, cid in name_to_id.items():
        id_to_name[int(cid)] = name
        id_to_color[int(cid)] = tuple(name_to_color[name])
    return dict(sorted(id_to_name.items())), dict(sorted(id_to_color.items()))


ID_TO_NAME, ID_TO_COLOR = load_label_metadata()
CLASS_IDS = sorted(ID_TO_NAME)                       # 0 .. 39
VALID_CLASS_IDS = [c for c in CLASS_IDS if c != IGNORE_INDEX]   # 1 .. 39
NUM_CLASSES = max(CLASS_IDS) + 1                     # 40 logits; channel i == class id i
NUM_VALID_CLASSES = len(VALID_CLASS_IDS)             # 39 evaluated classes

# --- semantic groupings used for the targeted algae / bleaching analyses ----- #
# These groups are ONLY used for reporting aggregates. The ground truth itself
# is never modified (see the project rules).
ALGAE_CLASS_NAMES = ["algae covered substrate"]
BLEACHING_CLASS_NAMES = [
    "branching bleached",
    "other coral bleached",
    "massive/meandering bleached",
    "meandering bleached",
]

_NAME_TO_ID = {v: k for k, v in ID_TO_NAME.items()}
ALGAE_CLASS_IDS = [_NAME_TO_ID[n] for n in ALGAE_CLASS_NAMES]
BLEACHING_CLASS_IDS = [_NAME_TO_ID[n] for n in BLEACHING_CLASS_NAMES]

CORAL_ALIVE_CLASS_NAMES = [
    "branching alive", "stylophora alive", "pocillopora alive", "acropora alive",
    "table acropora alive", "millepora", "turbinaria", "other coral alive",
    "massive/meandering alive", "meandering alive",
]
CORAL_DEAD_CLASS_NAMES = [
    "branching dead", "table acropora dead", "other coral dead",
    "massive/meandering dead", "meandering dead",
]
CORAL_ALIVE_CLASS_IDS = [_NAME_TO_ID[n] for n in CORAL_ALIVE_CLASS_NAMES]
CORAL_DEAD_CLASS_IDS = [_NAME_TO_ID[n] for n in CORAL_DEAD_CLASS_NAMES]
BACKGROUND_CLASS_IDS = [_NAME_TO_ID[n] for n in ["background", "sand", "dark"]]


# --------------------------------------------------------------------------- #
# Experiment configuration
# --------------------------------------------------------------------------- #
@dataclass
class Config:
    seed: int = 42

    # data / resolution
    image_size: tuple[int, int] = (512, 512)      # (H, W) fed to the networks
    eval_image_size: tuple[int, int] = (512, 1024)  # keeps the 2:1 native aspect
    batch_size: int = 4
    eval_batch_size: int = 2
    num_workers: int = 4

    # optimisation
    epochs: int = 18
    learning_rate: float = 3e-4
    encoder_learning_rate: float = 3e-5            # smaller LR for pretrained encoder
    weight_decay: float = 1e-2
    warmup_epochs: int = 1
    freeze_encoder_epochs: int = 2                 # decoder-only warm-up, then fine-tune
    grad_clip: float = 1.0
    early_stopping_patience: int = 6

    # hardware
    device: str = "cuda"
    amp: bool = True

    # models
    unet_encoder: str = "resnet50"
    segformer_checkpoint: str = "nvidia/mit-b0"
    yolo_checkpoint: str = "yolo11n-seg.pt"
    yolo_image_size: int = 640
    yolo_epochs: int = 30

    # loss
    loss_name: str = "ce_dice"                     # see src/losses.py
    dice_weight: float = 0.5
    use_class_weights: bool = True

    def to_dict(self) -> dict:
        d = asdict(self)
        d["image_size"] = list(self.image_size)
        d["eval_image_size"] = list(self.eval_image_size)
        return d


CFG = Config()

# --------------------------------------------------------------------------- #
# Reproducibility
# --------------------------------------------------------------------------- #
def set_seed(seed: int = CFG.seed, deterministic: bool = False) -> None:
    """Seed Python, NumPy, PyTorch (CPU + CUDA)."""
    import torch

    random.seed(seed)
    np.random.seed(seed)
    os.environ["PYTHONHASHSEED"] = str(seed)
    torch.manual_seed(seed)
    torch.cuda.manual_seed_all(seed)
    if deterministic:
        torch.backends.cudnn.deterministic = True
        torch.backends.cudnn.benchmark = False
    else:
        torch.backends.cudnn.benchmark = True


def get_device(cfg: Config = CFG):
    import torch

    if cfg.device == "cuda" and torch.cuda.is_available():
        return torch.device("cuda")
    return torch.device("cpu")


def describe_hardware() -> dict:
    """Print and return the hardware / library fingerprint of this run."""
    import torch

    info = {
        "torch_version": torch.__version__,
        "cuda_version": torch.version.cuda,
        "cuda_available": torch.cuda.is_available(),
        "device": str(get_device()),
    }
    if torch.cuda.is_available():
        props = torch.cuda.get_device_properties(0)
        info.update(
            gpu_name=props.name,
            gpu_memory_gb=round(props.total_memory / 1024 ** 3, 2),
            gpu_capability=f"sm_{props.major}{props.minor}",
        )
    for k, v in info.items():
        print(f"{k:>18}: {v}")
    return info


def record_environment(cfg: Config = CFG, extra: dict | None = None,
                       filename: str = "run_environment.json") -> dict:
    """Persist the full reproducibility fingerprint of a run (spec section 27).

    Captures library versions, hardware, hyper-parameters and a fingerprint of
    the dataset's label metadata, so a later dataset revision that changed the
    class space is detectable after the fact.
    """
    import hashlib
    import importlib
    import platform
    from datetime import datetime, timezone

    libs = {}
    for name in ("torch", "torchvision", "transformers", "segmentation_models_pytorch",
                 "ultralytics", "albumentations", "cv2", "numpy", "sklearn", "PIL"):
        try:
            libs[name] = getattr(importlib.import_module(name), "__version__", "unknown")
        except Exception:
            libs[name] = "not installed"

    label_fingerprint = hashlib.sha256(
        json.dumps({str(k): v for k, v in sorted(ID_TO_NAME.items())},
                   sort_keys=True).encode()).hexdigest()[:16]

    info = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "platform": platform.platform(),
        "python": platform.python_version(),
        "libraries": libs,
        "hardware": describe_hardware(),
        "hyperparameters": cfg.to_dict(),
        "dataset": {
            "root": str(DATA_ROOT),
            "num_classes": NUM_CLASSES,
            "num_evaluated_classes": NUM_VALID_CLASSES,
            "ignore_index": IGNORE_INDEX,
            "label_metadata_sha256_16": label_fingerprint,
        },
    }
    if extra:
        info.update(extra)

    out = OUTPUT_DIR / "metrics" / filename
    out.parent.mkdir(parents=True, exist_ok=True)
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(info, fh, indent=2, default=str)
    print(f"recorded run environment -> {out}")
    return info


if __name__ == "__main__":
    print(f"DATA_ROOT      : {DATA_ROOT}  (exists={DATA_ROOT.exists()})")
    print(f"NUM_CLASSES    : {NUM_CLASSES} logits, {NUM_VALID_CLASSES} evaluated classes")
    print(f"IGNORE_INDEX   : {IGNORE_INDEX} ({ID_TO_NAME[IGNORE_INDEX]})")
    print(f"algae ids      : {ALGAE_CLASS_IDS}")
    print(f"bleaching ids  : {BLEACHING_CLASS_IDS}")
    describe_hardware()

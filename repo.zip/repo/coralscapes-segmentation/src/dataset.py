"""CoralScapes dataset: file indexing, split handling and the PyTorch Dataset.

The official release uses a Cityscapes-style directory layout in which every
image lives under a *site* folder:

    leftImg8bit/<split>/<site>/<site>_<seq>_<frame>_leftImg8bit.png
    gtFine/<split>/<site>/<site>_<seq>_<frame>_gtFine.png

The site folders are what makes the official split leakage-free: a dive site
appears in exactly one split (verified by ``assert_no_site_leakage``).
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import numpy as np
import torch
from PIL import Image
from torch.utils.data import DataLoader, Dataset

from .config import (CFG, DATA_ROOT, IMAGE_DIR_NAME, IMAGE_SUFFIX, MASK_DIR_NAME,
                     MASK_SUFFIX, Config)

# NOTE: src.transforms is imported lazily inside CoralScapesDataset so that
# indexing, the leakage check and the EDA can run without albumentations
# installed.

SPLITS = ("train", "val", "test")


@dataclass(frozen=True)
class Sample:
    image_path: Path
    mask_path: Path
    site: str
    stem: str          # e.g. site10_000001_012400


def index_split(split: str, root: Path = DATA_ROOT) -> list[Sample]:
    """Enumerate every (image, mask) pair of a split, sorted for determinism."""
    img_root = root / IMAGE_DIR_NAME / split
    mask_root = root / MASK_DIR_NAME / split
    if not img_root.is_dir():
        raise FileNotFoundError(f"missing image directory: {img_root}")

    samples: list[Sample] = []
    for img_path in sorted(img_root.rglob(f"*{IMAGE_SUFFIX}")):
        stem = img_path.name[: -len(IMAGE_SUFFIX)]
        site = img_path.parent.name
        mask_path = mask_root / site / f"{stem}{MASK_SUFFIX}"
        if not mask_path.exists():
            raise FileNotFoundError(f"image without matching mask: {img_path}")
        samples.append(Sample(img_path, mask_path, site, stem))
    return samples


def index_all_splits(root: Path = DATA_ROOT) -> dict[str, list[Sample]]:
    return {s: index_split(s, root) for s in SPLITS}


def sites_per_split(index: dict[str, list[Sample]]) -> dict[str, set[str]]:
    return {split: {s.site for s in samples} for split, samples in index.items()}


def assert_no_site_leakage(index: dict[str, list[Sample]]) -> dict[str, set[str]]:
    """Fail loudly if any dive site appears in more than one split.

    Images from one site are strongly correlated (same reef, same dive, often
    consecutive frames), so a shared site would leak information across splits
    even though no individual file is duplicated.
    """
    sites = sites_per_split(index)
    for a in SPLITS:
        for b in SPLITS:
            if a < b:
                shared = sites[a] & sites[b]
                if shared:
                    raise AssertionError(
                        f"site leakage between {a!r} and {b!r}: {sorted(shared)}")
    stems = {sp: {s.stem for s in ss} for sp, ss in index.items()}
    for a in SPLITS:
        for b in SPLITS:
            if a < b and (stems[a] & stems[b]):
                raise AssertionError(f"duplicate image stems in {a}/{b}")
    return sites


class CoralScapesDataset(Dataset):
    """Returns ``(image, segmentation_mask)``.

    image : float32 tensor ``(3, H, W)``, ImageNet-normalised RGB
    mask  : int64 tensor ``(H, W)`` holding **raw CoralScapes class ids**
            (0 = unlabelled/ignore, 1..39 = the official classes). The mask is
            never scaled or normalised.
    """

    def __init__(self, split: str, cfg: Config = CFG, root: Path = DATA_ROOT,
                 augment: bool | None = None, transform=None,
                 samples: list[Sample] | None = None,
                 return_meta: bool = False):
        if split not in SPLITS:
            raise ValueError(f"split must be one of {SPLITS}, got {split!r}")
        self.split = split
        self.cfg = cfg
        self.samples = samples if samples is not None else index_split(split, root)
        self.return_meta = return_meta

        if augment is None:
            augment = split == "train"
        self.augment = augment

        if transform is not None:
            self.transform = transform
        else:
            from .transforms import eval_transform, train_transform
            if augment:
                h, w = cfg.image_size
                self.transform = train_transform(h, w)
            else:
                h, w = cfg.eval_image_size
                self.transform = eval_transform(h, w)

    def __len__(self) -> int:
        return len(self.samples)

    def load_raw(self, idx: int) -> tuple[np.ndarray, np.ndarray]:
        """Full-resolution image (HWC uint8 RGB) and mask (HW uint8 ids)."""
        s = self.samples[idx]
        image = np.array(Image.open(s.image_path).convert("RGB"))
        mask = np.array(Image.open(s.mask_path))
        if mask.ndim == 3:            # defensive: some tools save a palette copy
            mask = mask[..., 0]
        return image, mask

    def __getitem__(self, idx: int):
        image, mask = self.load_raw(idx)
        out = self.transform(image=image, mask=mask)
        img_t = out["image"].float()
        mask_t = out["mask"].long()          # stays integer class ids
        if self.return_meta:
            s = self.samples[idx]
            return img_t, mask_t, {"stem": s.stem, "site": s.site,
                                   "image_path": str(s.image_path)}
        return img_t, mask_t


def build_dataloaders(cfg: Config = CFG, root: Path = DATA_ROOT,
                      splits=("train", "val")) -> dict[str, DataLoader]:
    """DataLoaders with a seeded generator so shuffling is reproducible."""
    loaders: dict[str, DataLoader] = {}
    for split in splits:
        train_mode = split == "train"
        ds = CoralScapesDataset(split, cfg=cfg, root=root)
        g = torch.Generator()
        g.manual_seed(cfg.seed)
        loaders[split] = DataLoader(
            ds,
            batch_size=cfg.batch_size if train_mode else cfg.eval_batch_size,
            shuffle=train_mode,
            num_workers=cfg.num_workers,
            pin_memory=True,
            drop_last=train_mode,
            persistent_workers=cfg.num_workers > 0,
            generator=g if train_mode else None,
        )
    return loaders

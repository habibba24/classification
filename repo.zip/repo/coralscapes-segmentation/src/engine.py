"""Shared training / validation engine for the two semantic models.

U-Net and SegFormer are trained by exactly the same code path -- same loss,
same optimiser family, same schedule, same augmentation, same resolution, same
seed. That is what makes the final comparison an architecture comparison
rather than a comparison of training recipes.

Model selection uses validation mIoU only; the test split is never touched
here.
"""
from __future__ import annotations

import json
import time
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import DataLoader
from tqdm import tqdm

from .config import CFG, CHECKPOINT_DIR, NUM_CLASSES, Config, get_device
from .metrics import ConfusionMatrix
from .models import logits_to_prediction, param_groups, set_encoder_trainable


def build_optimizer(model: nn.Module, cfg: Config) -> torch.optim.Optimizer:
    """AdamW with decoupled weight decay and no decay on norm/bias terms."""
    groups = param_groups(model, cfg.learning_rate, cfg.encoder_learning_rate)
    decay, no_decay = [], []
    named = dict(model.named_parameters())
    id_to_name = {id(p): n for n, p in named.items()}
    out_groups = []
    for g in groups:
        d, nd = [], []
        for p in g["params"]:
            name = id_to_name.get(id(p), "")
            if p.ndim <= 1 or name.endswith(".bias") or "norm" in name.lower():
                nd.append(p)
            else:
                d.append(p)
        if d:
            out_groups.append({"params": d, "lr": g["lr"],
                               "weight_decay": cfg.weight_decay,
                               "name": g["name"] + "_decay"})
        if nd:
            out_groups.append({"params": nd, "lr": g["lr"], "weight_decay": 0.0,
                               "name": g["name"] + "_nodecay"})
    return torch.optim.AdamW(out_groups, lr=cfg.learning_rate,
                             weight_decay=cfg.weight_decay)


def build_scheduler(optimizer, cfg: Config, steps_per_epoch: int):
    """Linear warm-up followed by cosine decay, stepped per iteration."""
    total_steps = max(1, cfg.epochs * steps_per_epoch)
    warmup_steps = max(1, cfg.warmup_epochs * steps_per_epoch)

    def lr_lambda(step: int) -> float:
        if step < warmup_steps:
            return (step + 1) / warmup_steps
        progress = (step - warmup_steps) / max(1, total_steps - warmup_steps)
        progress = min(1.0, progress)
        return 0.5 * (1.0 + np.cos(np.pi * progress))

    return torch.optim.lr_scheduler.LambdaLR(optimizer, lr_lambda)


def train_one_epoch(model, loader: DataLoader, criterion, optimizer, scheduler,
                    scaler, device, cfg: Config, epoch: int) -> float:
    model.train()
    running, n_batches = 0.0, 0
    pbar = tqdm(loader, desc=f"epoch {epoch:>3} train", leave=False)
    for images, masks in pbar:
        images = images.to(device, non_blocking=True)
        masks = masks.to(device, non_blocking=True)

        optimizer.zero_grad(set_to_none=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16,
                            enabled=cfg.amp and device.type == "cuda"):
            logits = model(images)
            loss = criterion(logits, masks)

        if scaler is not None and scaler.is_enabled():
            scaler.scale(loss).backward()
            if cfg.grad_clip:
                scaler.unscale_(optimizer)
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            scaler.step(optimizer)
            scaler.update()
        else:
            loss.backward()
            if cfg.grad_clip:
                torch.nn.utils.clip_grad_norm_(model.parameters(), cfg.grad_clip)
            optimizer.step()
        if scheduler is not None:
            scheduler.step()

        running += float(loss.detach())
        n_batches += 1
        pbar.set_postfix(loss=f"{running / n_batches:.4f}",
                         lr=f"{optimizer.param_groups[0]['lr']:.2e}")
    return running / max(1, n_batches)


@torch.no_grad()
def evaluate(model, loader: DataLoader, criterion, device, cfg: Config,
             desc: str = "val") -> tuple[dict, ConfusionMatrix, float]:
    """Returns (summary metrics, confusion matrix, mean loss)."""
    model.eval()
    cm = ConfusionMatrix(num_classes=NUM_CLASSES)
    running, n_batches = 0.0, 0
    for images, masks in tqdm(loader, desc=desc, leave=False):
        images = images.to(device, non_blocking=True)
        masks = masks.to(device, non_blocking=True)
        with torch.autocast(device_type=device.type, dtype=torch.float16,
                            enabled=cfg.amp and device.type == "cuda"):
            logits = model(images)
            if criterion is not None:
                running += float(criterion(logits.float(), masks))
                n_batches += 1
        pred = logits_to_prediction(logits.float())
        cm.update(masks, pred)
    return cm.summary(), cm, running / max(1, n_batches)


def fit(model: nn.Module, loaders: dict[str, DataLoader], criterion,
        cfg: Config = CFG, model_name: str = "model",
        checkpoint_path: Path | None = None, history_path: Path | None = None) -> dict:
    """Full training loop with encoder freezing, early stopping and checkpointing."""
    device = get_device(cfg)
    model.to(device)
    checkpoint_path = Path(checkpoint_path or CHECKPOINT_DIR / f"best_{model_name}.pth")
    history_path = Path(history_path or CHECKPOINT_DIR / f"history_{model_name}.json")

    # phase 1: train the randomly initialised decoder on top of a frozen encoder
    if cfg.freeze_encoder_epochs > 0:
        set_encoder_trainable(model, False)
        print(f"[{model_name}] encoder frozen for the first "
              f"{cfg.freeze_encoder_epochs} epoch(s)")

    optimizer = build_optimizer(model, cfg)
    scheduler = build_scheduler(optimizer, cfg, len(loaders["train"]))
    scaler = torch.amp.GradScaler("cuda", enabled=cfg.amp and device.type == "cuda")

    history = {"epoch": [], "train_loss": [], "val_loss": [], "val_miou": [],
               "val_pixel_acc": [], "val_mean_dice": [], "lr": [], "epoch_time_s": []}
    best_miou, best_epoch, epochs_without_improvement = -1.0, -1, 0
    train_start = time.time()

    for epoch in range(1, cfg.epochs + 1):
        # phase 2: unfreeze and fine-tune the whole network end to end
        if cfg.freeze_encoder_epochs and epoch == cfg.freeze_encoder_epochs + 1:
            set_encoder_trainable(model, True)
            optimizer = build_optimizer(model, cfg)
            remaining = cfg.epochs - cfg.freeze_encoder_epochs
            sched_cfg = Config(**{**cfg.to_dict(), "epochs": remaining,
                                  "image_size": tuple(cfg.image_size),
                                  "eval_image_size": tuple(cfg.eval_image_size)})
            scheduler = build_scheduler(optimizer, sched_cfg, len(loaders["train"]))
            print(f"[{model_name}] encoder unfrozen at epoch {epoch}")

        t0 = time.time()
        train_loss = train_one_epoch(model, loaders["train"], criterion, optimizer,
                                     scheduler, scaler, device, cfg, epoch)
        val_metrics, _, val_loss = evaluate(model, loaders["val"], criterion,
                                            device, cfg, desc=f"epoch {epoch:>3} val")
        dt = time.time() - t0

        history["epoch"].append(epoch)
        history["train_loss"].append(train_loss)
        history["val_loss"].append(val_loss)
        history["val_miou"].append(val_metrics["mean_iou"])
        history["val_pixel_acc"].append(val_metrics["pixel_accuracy"])
        history["val_mean_dice"].append(val_metrics["mean_dice"])
        history["lr"].append(optimizer.param_groups[0]["lr"])
        history["epoch_time_s"].append(dt)

        print(f"[{model_name}] epoch {epoch:>3}/{cfg.epochs} "
              f"train_loss={train_loss:.4f} val_loss={val_loss:.4f} "
              f"val_mIoU={val_metrics['mean_iou']:.4f} "
              f"val_acc={val_metrics['pixel_accuracy']:.4f} ({dt:.0f}s)")

        if val_metrics["mean_iou"] > best_miou:
            best_miou, best_epoch = val_metrics["mean_iou"], epoch
            epochs_without_improvement = 0
            torch.save({
                "model_state_dict": model.state_dict(),
                "epoch": epoch,
                "val_metrics": val_metrics,
                "config": cfg.to_dict(),
                "model_name": model_name,
                "num_classes": NUM_CLASSES,
            }, checkpoint_path)
            print(f"    new best val mIoU -> saved {checkpoint_path.name}")
        else:
            epochs_without_improvement += 1
            if epochs_without_improvement >= cfg.early_stopping_patience:
                print(f"[{model_name}] early stopping at epoch {epoch} "
                      f"(no val improvement for {cfg.early_stopping_patience} epochs)")
                break

        with open(history_path, "w", encoding="utf-8") as fh:
            json.dump(history, fh, indent=2)

    total_time = time.time() - train_start
    history["total_training_time_s"] = total_time
    history["best_val_miou"] = best_miou
    history["best_epoch"] = best_epoch
    if torch.cuda.is_available():
        history["peak_gpu_memory_mb"] = torch.cuda.max_memory_allocated() / 1024 ** 2
    with open(history_path, "w", encoding="utf-8") as fh:
        json.dump(history, fh, indent=2)

    print(f"[{model_name}] done in {total_time / 60:.1f} min; "
          f"best val mIoU {best_miou:.4f} at epoch {best_epoch}")
    return history


def load_checkpoint(model: nn.Module, path: Path, device=None) -> dict:
    device = device or get_device()
    ckpt = torch.load(path, map_location=device, weights_only=False)
    model.load_state_dict(ckpt["model_state_dict"])
    model.to(device).eval()
    return ckpt

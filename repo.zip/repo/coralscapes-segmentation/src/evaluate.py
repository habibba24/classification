"""Final evaluation on the official CoralScapes test split.

    python -m src.evaluate --models unet segformer yolo_seg

This is the ONLY place the test split is read. Nothing here tunes anything:
checkpoints were selected on val, thresholds are framework defaults, and the
script simply measures.

What it produces per semantic model (outputs/metrics/):
  <model>_test_metrics.json   summary + per-class IoU/Dice/precision/recall
  <model>_per_class.csv       the same table in spreadsheet form
  <model>_confusion.npy       full 40x40 confusion matrix
  <model>_per_image_stats.npy per-image TP/FP/FN, used for the bootstrap CIs

For YOLO-Seg it additionally records Ultralytics' instance metrics (mAP@50,
mAP@50:95, precision, recall) AND rasterises the predicted instance masks into
a semantic map so that IoU/Dice can be compared with the other two models on
the same pixels. Those two families of numbers are reported side by side and
never blended into one score: mAP scores ranked instance detections, mIoU
scores pixel labelling, and no monotone relation connects them.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from tqdm import tqdm

from .config import (ALGAE_CLASS_IDS, BLEACHING_CLASS_IDS, CFG, CHECKPOINT_DIR,
                     CORAL_ALIVE_CLASS_IDS, CORAL_DEAD_CLASS_IDS, ID_TO_NAME,
                     IGNORE_INDEX, NUM_CLASSES, OUTPUT_DIR, VALID_CLASS_IDS,
                     Config, get_device, set_seed)
from .dataset import CoralScapesDataset
from .metrics import (ConfusionMatrix, boundary_f1, boundary_f1_from_totals,
                      boundary_iou, bootstrap_ci, class_iou_from_stats,
                      dice_from_stats, group_iou_from_stats, group_metrics,
                      miou_from_stats, paired_bootstrap_diff, per_image_tpfpfn)
from .models import build_model, logits_to_prediction

METRICS_DIR = OUTPUT_DIR / "metrics"
BOUNDARY_CLASS_IDS = sorted(set(ALGAE_CLASS_IDS + BLEACHING_CLASS_IDS
                                + CORAL_ALIVE_CLASS_IDS[:4] + CORAL_DEAD_CLASS_IDS[:2]))


# --------------------------------------------------------------------------- #
# Semantic models
# --------------------------------------------------------------------------- #
@torch.no_grad()
def predict_semantic(model, dataset, cfg: Config, device, indices=None):
    """Yield (index, ground-truth mask, predicted mask) at evaluation resolution."""
    model.eval()
    idxs = range(len(dataset)) if indices is None else indices
    for i in tqdm(list(idxs), desc="predicting", unit="img"):
        image, mask = dataset[i]
        x = image.unsqueeze(0).to(device)
        with torch.autocast(device_type=device.type, dtype=torch.float16,
                            enabled=cfg.amp and device.type == "cuda"):
            logits = model(x)
        pred = logits_to_prediction(logits.float())[0].cpu().numpy().astype(np.uint8)
        yield i, mask.numpy().astype(np.uint8), pred


def evaluate_semantic(model_name: str, checkpoint: Path, cfg: Config = CFG,
                      split: str = "test", boundary: bool = True,
                      n_boot: int = 1000, save: bool = True) -> dict:
    """Full pixel-level evaluation of U-Net or SegFormer."""
    device = get_device(cfg)
    model = build_model(model_name, cfg, pretrained=False)
    ckpt = torch.load(checkpoint, map_location=device, weights_only=False)
    model.load_state_dict(ckpt["model_state_dict"])
    model.to(device).eval()
    print(f"[{model_name}] loaded {checkpoint.name} "
          f"(epoch {ckpt.get('epoch')}, val mIoU "
          f"{ckpt.get('val_metrics', {}).get('mean_iou', float('nan')):.4f})")

    dataset = CoralScapesDataset(split, cfg=cfg, augment=False)
    cm = ConfusionMatrix(num_classes=NUM_CLASSES)
    per_image_stats = []
    b_iou_totals = {c: [0.0, 0.0] for c in BOUNDARY_CLASS_IDS}
    b_f1_totals = {c: np.zeros(4) for c in BOUNDARY_CLASS_IDS}

    for _, gt, pred in predict_semantic(model, dataset, cfg, device):
        cm.update(torch.from_numpy(gt), torch.from_numpy(pred))
        per_image_stats.append(per_image_tpfpfn(gt, pred))
        if boundary:
            for c, (inter, union) in boundary_iou(gt, pred, BOUNDARY_CLASS_IDS).items():
                b_iou_totals[c][0] += inter
                b_iou_totals[c][1] += union
            for c, t in boundary_f1(gt, pred, BOUNDARY_CLASS_IDS).items():
                b_f1_totals[c] += np.asarray(t, dtype=np.float64)

    per_image_stats = np.stack(per_image_stats)
    result = assemble_semantic_report(model_name, split, cm, per_image_stats,
                                      b_iou_totals if boundary else None,
                                      b_f1_totals if boundary else None, n_boot)
    if save:
        save_semantic_report(model_name, result, cm, per_image_stats)
    return result


def assemble_semantic_report(model_name: str, split: str, cm: ConfusionMatrix,
                             per_image_stats: np.ndarray, b_iou_totals=None,
                             b_f1_totals=None, n_boot: int = 1000) -> dict:
    pc = cm.per_class()
    summary = cm.summary()
    idx_of = {c: i for i, c in enumerate(VALID_CLASS_IDS)}

    # bootstrap over images, resampling whole images rather than pixels
    miou_pt, miou_lo, miou_hi = bootstrap_ci(per_image_stats, miou_from_stats, n_boot)
    dice_pt, dice_lo, dice_hi = bootstrap_ci(per_image_stats, dice_from_stats, n_boot)
    algae_idx = [idx_of[c] for c in ALGAE_CLASS_IDS]
    bleach_idx = [idx_of[c] for c in BLEACHING_CLASS_IDS]
    alg_pt, alg_lo, alg_hi = bootstrap_ci(
        per_image_stats, lambda s: group_iou_from_stats(s, algae_idx), n_boot)
    ble_pt, ble_lo, ble_hi = bootstrap_ci(
        per_image_stats, lambda s: group_iou_from_stats(s, bleach_idx), n_boot)

    report = {
        "model": model_name,
        "split": split,
        "n_images": int(len(per_image_stats)),
        "summary": summary,
        "confidence_intervals_95": {
            "mean_iou": {"point": miou_pt, "low": miou_lo, "high": miou_hi},
            "mean_dice": {"point": dice_pt, "low": dice_lo, "high": dice_hi},
            "algae_iou": {"point": alg_pt, "low": alg_lo, "high": alg_hi},
            "bleaching_iou_aggregated": {"point": ble_pt, "low": ble_lo, "high": ble_hi},
            "method": ("percentile bootstrap, 1000 resamples of whole images; "
                       "pixels within an image are correlated so images, not "
                       "pixels, are the resampling unit"),
        },
        "per_class": {
            ID_TO_NAME[c]: {
                "class_id": int(c),
                "iou": _f(pc["iou"][i]), "dice": _f(pc["dice"][i]),
                "precision": _f(pc["precision"][i]), "recall": _f(pc["recall"][i]),
                "support_pixels": int(pc["support"][i]),
            } for i, c in enumerate(pc["class_ids"])
        },
        "algae": {
            "per_class": {ID_TO_NAME[c]: {
                "iou": _f(pc["iou"][idx_of[c]]), "dice": _f(pc["dice"][idx_of[c]]),
                "precision": _f(pc["precision"][idx_of[c]]),
                "recall": _f(pc["recall"][idx_of[c]]),
                "support_pixels": int(pc["support"][idx_of[c]])} for c in ALGAE_CLASS_IDS},
            "aggregated": group_metrics(cm, ALGAE_CLASS_IDS),
        },
        "bleaching": {
            "per_class": {ID_TO_NAME[c]: {
                "iou": _f(pc["iou"][idx_of[c]]), "dice": _f(pc["dice"][idx_of[c]]),
                "precision": _f(pc["precision"][idx_of[c]]),
                "recall": _f(pc["recall"][idx_of[c]]),
                "support_pixels": int(pc["support"][idx_of[c]])}
                for c in BLEACHING_CLASS_IDS},
            "aggregated": group_metrics(cm, BLEACHING_CLASS_IDS),
            "aggregation_rule": (
                "the four official bleached-coral classes "
                f"({', '.join(ID_TO_NAME[c] for c in BLEACHING_CLASS_IDS)}) are "
                "pooled one-vs-rest; a confusion BETWEEN two bleached classes "
                "counts as correct. The ground truth itself is not modified -- "
                "the per-class numbers above use the original labels."),
        },
        "coral_groups": {
            "alive_aggregated": group_metrics(cm, CORAL_ALIVE_CLASS_IDS),
            "dead_aggregated": group_metrics(cm, CORAL_DEAD_CLASS_IDS),
        },
    }

    if b_iou_totals:
        report["boundary"] = {
            "boundary_iou": {ID_TO_NAME[c]: (v[0] / v[1] if v[1] > 0 else float("nan"))
                             for c, v in b_iou_totals.items()},
            "boundary_f1": {ID_TO_NAME[c]: v for c, v in
                            boundary_f1_from_totals(b_f1_totals).items()},
            "note": ("Boundary IoU uses a 1% image-diagonal band around each class "
                     "border (Cheng et al. 2021); Boundary F1 matches contour pixels "
                     "within 3 px. Both are accumulated over the split before "
                     "dividing, so large regions do not dominate small ones."),
        }
        bi = [v for v in report["boundary"]["boundary_iou"].values() if np.isfinite(v)]
        bf = [v for v in report["boundary"]["boundary_f1"].values() if np.isfinite(v)]
        report["boundary"]["mean_boundary_iou"] = float(np.mean(bi)) if bi else float("nan")
        report["boundary"]["mean_boundary_f1"] = float(np.mean(bf)) if bf else float("nan")
    return report


def _f(x) -> float:
    x = float(x)
    return x if np.isfinite(x) else float("nan")


def save_semantic_report(model_name: str, report: dict, cm: ConfusionMatrix,
                         per_image_stats: np.ndarray) -> None:
    METRICS_DIR.mkdir(parents=True, exist_ok=True)
    with open(METRICS_DIR / f"{model_name}_test_metrics.json", "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, default=float)
    np.save(METRICS_DIR / f"{model_name}_confusion.npy", cm.numpy())
    np.save(METRICS_DIR / f"{model_name}_per_image_stats.npy", per_image_stats)

    rows = ["class_id,class_name,iou,dice,precision,recall,support_pixels"]
    for name, d in report["per_class"].items():
        rows.append(f"{d['class_id']},\"{name}\",{d['iou']:.6f},{d['dice']:.6f},"
                    f"{d['precision']:.6f},{d['recall']:.6f},{d['support_pixels']}")
    (METRICS_DIR / f"{model_name}_per_class.csv").write_text("\n".join(rows) + "\n",
                                                             encoding="utf-8")
    print(f"[{model_name}] wrote metrics to {METRICS_DIR}")


# --------------------------------------------------------------------------- #
# YOLO-Seg
# --------------------------------------------------------------------------- #
def evaluate_yolo(weights: Path, cfg: Config = CFG, split: str = "test",
                  conf: float = 0.25, iou: float = 0.7, save: bool = True,
                  rasterize: bool = True, n_boot: int = 1000) -> dict:
    """Instance metrics from Ultralytics + a rasterised semantic comparison."""
    from ultralytics import YOLO

    from .annotation_conversion import load_mapping
    from .config import YOLO_DATA_DIR

    mapping = load_mapping(YOLO_DATA_DIR)
    yolo_to_coral = {int(k): int(v) for k, v in mapping["yolo_index_to_coral_id"].items()}
    model = YOLO(str(weights))

    # --- 1. native instance-segmentation metrics ---------------------------- #
    val = model.val(data=str(YOLO_DATA_DIR / "coralscapes_yolo.yaml"), split=split,
                    imgsz=cfg.yolo_image_size, conf=0.001, iou=iou, plots=True,
                    project=str(OUTPUT_DIR / "yolo_seg"), name=f"val_{split}",
                    exist_ok=True)
    seg = val.seg
    box = val.box
    instance_metrics = {
        "mask_mAP50": float(seg.map50), "mask_mAP50_95": float(seg.map),
        "mask_precision": float(seg.mp), "mask_recall": float(seg.mr),
        "box_mAP50": float(box.map50), "box_mAP50_95": float(box.map),
        "box_precision": float(box.mp), "box_recall": float(box.mr),
        "per_class_mask_ap50": {},
        "note": ("Ultralytics mask metrics: AP is computed over ranked instance "
                 "detections at mask-IoU thresholds. These are NOT comparable to "
                 "the pixel mIoU of the semantic models."),
    }
    # `ap_class_index` has lived on both the metrics object and the per-task
    # Metric across Ultralytics releases; try both rather than lose the table.
    class_index = getattr(val, "ap_class_index", None)
    if class_index is None:
        class_index = getattr(seg, "ap_class_index", None)
    try:
        ap50 = np.asarray(seg.ap50).reshape(-1)
        if class_index is None:
            raise AttributeError("ap_class_index not exposed by this "
                                 "ultralytics version")
        for i, ap in zip(np.asarray(class_index).reshape(-1), ap50):
            coral_id = yolo_to_coral[int(i)]
            instance_metrics["per_class_mask_ap50"][ID_TO_NAME[coral_id]] = float(ap)
    except Exception as exc:                                  # pragma: no cover
        instance_metrics["per_class_error"] = str(exc)
        print(f"[yolo_seg] per-class AP unavailable: {exc}")

    report = {"model": "yolo_seg", "split": split, "conf": conf, "iou": iou,
              "instance_metrics": instance_metrics}

    # --- 2. rasterised predictions vs the original semantic masks ----------- #
    if rasterize:
        report["semantic_from_instances"] = rasterized_semantic_eval(
            model, yolo_to_coral, cfg, split, conf, n_boot, save=save)
    if save:
        METRICS_DIR.mkdir(parents=True, exist_ok=True)
        with open(METRICS_DIR / "yolo_seg_test_metrics.json", "w", encoding="utf-8") as fh:
            json.dump(report, fh, indent=2, default=float)
        print(f"[yolo_seg] wrote metrics to {METRICS_DIR}")
    return report


def rasterized_semantic_eval(model, yolo_to_coral: dict[int, int], cfg: Config,
                             split: str, conf: float, n_boot: int = 1000,
                             save: bool = True) -> dict:
    """Paint YOLO instance masks into a semantic map and score it like the others.

    Instances are painted largest-area-first so small objects stay on top.
    Pixels that no instance covers are left as 'unclaimed' and counted as
    errors against the ground truth -- YOLO-Seg has no notion of an exhaustive
    labelling, which is precisely the structural difference this measures.
    """
    import cv2
    from PIL import Image

    from .config import DATA_ROOT, MASK_DIR_NAME, MASK_SUFFIX, YOLO_DATA_DIR

    img_dir = YOLO_DATA_DIR / "images" / split
    stems = sorted(p.stem for p in img_dir.glob("*.jpg"))
    cm = ConfusionMatrix(num_classes=NUM_CLASSES)
    per_image_stats, unclaimed_fracs = [], []

    for stem in tqdm(stems, desc="yolo rasterise", unit="img"):
        img_path = img_dir / f"{stem}.jpg"
        res = model.predict(str(img_path), imgsz=cfg.yolo_image_size, conf=conf,
                            verbose=False)[0]
        h, w = res.orig_shape
        canvas = np.zeros((h, w), dtype=np.uint8)

        if res.masks is not None and len(res.masks) > 0:
            polys = res.masks.xy
            classes = res.boxes.cls.cpu().numpy().astype(int)
            confs = res.boxes.conf.cpu().numpy()
            areas = [cv2.contourArea(p.astype(np.int32)) if len(p) >= 3 else 0.0
                     for p in polys]
            order = np.argsort(-np.asarray(areas))
            for i in order:
                if len(polys[i]) < 3:
                    continue
                cv2.fillPoly(canvas, [polys[i].astype(np.int32)],
                             int(yolo_to_coral[int(classes[i])]))

        site = stem.split("_")[0]
        gt_full = np.array(Image.open(
            DATA_ROOT / MASK_DIR_NAME / split / site / f"{stem}{MASK_SUFFIX}"))
        if gt_full.ndim == 3:
            gt_full = gt_full[..., 0]
        gt = cv2.resize(gt_full, (w, h), interpolation=cv2.INTER_NEAREST)

        valid = gt != IGNORE_INDEX
        unclaimed_fracs.append(float(((canvas == 0) & valid).sum() / max(1, valid.sum())))
        cm.update(torch.from_numpy(gt), torch.from_numpy(canvas))
        per_image_stats.append(per_image_tpfpfn(gt, canvas))

    per_image_stats = np.stack(per_image_stats)
    idx_of = {c: i for i, c in enumerate(VALID_CLASS_IDS)}
    miou_pt, miou_lo, miou_hi = bootstrap_ci(per_image_stats, miou_from_stats, n_boot)

    out = {
        "summary": cm.summary(),
        "confidence_intervals_95": {
            "mean_iou": {"point": miou_pt, "low": miou_lo, "high": miou_hi}},
        "algae": {"aggregated": group_metrics(cm, ALGAE_CLASS_IDS)},
        "bleaching": {"aggregated": group_metrics(cm, BLEACHING_CLASS_IDS),
                      "per_class": {}},
        "mean_unclaimed_pixel_fraction": float(np.mean(unclaimed_fracs)),
        "note": ("Instance masks rasterised into a semantic map so that IoU/Dice "
                 "can be placed next to U-Net and SegFormer. Pixels covered by no "
                 "detection stay unlabelled and count as false negatives; that is "
                 "a real property of an instance model applied to an exhaustive "
                 "labelling task, not a scoring artefact. Compare against the "
                 "conversion ceiling in yolo_conversion_verification.json."),
    }
    pc = cm.per_class()
    for c in BLEACHING_CLASS_IDS:
        i = idx_of[c]
        out["bleaching"]["per_class"][ID_TO_NAME[c]] = {
            "iou": _f(pc["iou"][i]), "dice": _f(pc["dice"][i]),
            "precision": _f(pc["precision"][i]), "recall": _f(pc["recall"][i])}
    out["per_class"] = {ID_TO_NAME[c]: {
        "class_id": int(c), "iou": _f(pc["iou"][i]), "dice": _f(pc["dice"][i]),
        "precision": _f(pc["precision"][i]), "recall": _f(pc["recall"][i]),
        "support_pixels": int(pc["support"][i])} for i, c in enumerate(pc["class_ids"])}

    if save:
        METRICS_DIR.mkdir(parents=True, exist_ok=True)
        np.save(METRICS_DIR / "yolo_seg_confusion.npy", cm.numpy())
        np.save(METRICS_DIR / "yolo_seg_per_image_stats.npy", per_image_stats)
    return out


# --------------------------------------------------------------------------- #
# Statistical comparison between models
# --------------------------------------------------------------------------- #
def compare_models(model_names: list[str], n_boot: int = 1000) -> dict:
    """Paired bootstrap on the per-image statistics of every model pair."""
    stats = {}
    for m in model_names:
        p = METRICS_DIR / f"{m}_per_image_stats.npy"
        if p.exists():
            stats[m] = np.load(p)
    idx_of = {c: i for i, c in enumerate(VALID_CLASS_IDS)}
    algae_idx = [idx_of[c] for c in ALGAE_CLASS_IDS]
    bleach_idx = [idx_of[c] for c in BLEACHING_CLASS_IDS]

    out = {"note": ("paired bootstrap over the same test images; a 95% CI for the "
                    "difference that contains 0 means the gap is not resolvable "
                    "with this test set")}
    names = list(stats)
    for i, a in enumerate(names):
        for b in names[i + 1:]:
            if len(stats[a]) != len(stats[b]):
                out[f"{a}_vs_{b}"] = {"error": "different image counts; not paired"}
                continue
            out[f"{a}_vs_{b}"] = {
                "mean_iou": paired_bootstrap_diff(stats[a], stats[b],
                                                  miou_from_stats, n_boot),
                "mean_dice": paired_bootstrap_diff(stats[a], stats[b],
                                                   dice_from_stats, n_boot),
                "algae_iou": paired_bootstrap_diff(
                    stats[a], stats[b], lambda s: group_iou_from_stats(s, algae_idx),
                    n_boot),
                "bleaching_iou": paired_bootstrap_diff(
                    stats[a], stats[b], lambda s: group_iou_from_stats(s, bleach_idx),
                    n_boot),
            }
    with open(METRICS_DIR / "statistical_comparison.json", "w", encoding="utf-8") as fh:
        json.dump(out, fh, indent=2, default=float)
    print(f"wrote {METRICS_DIR / 'statistical_comparison.json'}")
    return out


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description="Evaluate on the CoralScapes test split")
    ap.add_argument("--models", nargs="+", default=["unet", "segformer", "yolo_seg"])
    ap.add_argument("--split", default="test", choices=["val", "test"])
    ap.add_argument("--no-boundary", action="store_true")
    ap.add_argument("--n-boot", type=int, default=1000)
    ap.add_argument("--conf", type=float, default=0.25)
    args = ap.parse_args(argv)

    set_seed(CFG.seed)
    done = []
    for name in args.models:
        if name in ("unet", "segformer"):
            ckpt = CHECKPOINT_DIR / f"best_{name}.pth"
            if not ckpt.exists():
                print(f"skipping {name}: {ckpt} not found (train it first)")
                continue
            evaluate_semantic(name, ckpt, CFG, args.split,
                              boundary=not args.no_boundary, n_boot=args.n_boot)
            done.append(name)
        elif name == "yolo_seg":
            w = CHECKPOINT_DIR / "best_yolo_seg.pt"
            if not w.exists():
                print(f"skipping yolo_seg: {w} not found (train it first)")
                continue
            evaluate_yolo(w, CFG, args.split, conf=args.conf, n_boot=args.n_boot)
            done.append(name)
    if len(done) > 1:
        compare_models(done, args.n_boot)


if __name__ == "__main__":
    main()

"""Explainability adapted to *segmentation* (spec section 20).

Classification Grad-CAM differentiates a single class logit. A segmentation
network emits one logit per pixel, so the question has to be restated before
the method transfers:

    "which input regions raised the score of class c **inside region R**?"

`seg_grad_cam` therefore differentiates the summed logit of class c over a
chosen spatial region (by default all pixels the model assigned to c) with
respect to a chosen feature map, then applies the usual channel weighting.
Differentiating the whole image at once would blur every instance of the class
together, which is the mistake the spec warns about.

Also provided:
  * `segformer_attention_maps` -- the transformer's own attention, which needs
    no gradient surrogate at all;
  * `prediction_confidence` -- softmax margin per pixel, the cheapest and most
    honest uncertainty signal for a segmentation model;
  * `yolo_confidence_visualization` -- per-instance mask confidence for YOLO.
"""
from __future__ import annotations

from pathlib import Path

import numpy as np
import torch
import torch.nn.functional as F

from .config import ID_TO_NAME, IGNORE_INDEX, get_device
from .models import logits_to_prediction


# --------------------------------------------------------------------------- #
# Grad-CAM for segmentation
# --------------------------------------------------------------------------- #
class _Hook:
    def __init__(self, module):
        self.activations = None
        self.gradients = None
        self.f = module.register_forward_hook(self._forward)
        self.b = module.register_full_backward_hook(self._backward)

    def _forward(self, _m, _i, output):
        self.activations = output[0] if isinstance(output, tuple) else output
        self.activations.retain_grad()

    def _backward(self, _m, _gi, grad_output):
        self.gradients = grad_output[0]

    def close(self):
        self.f.remove()
        self.b.remove()


def find_target_layer(model, model_name: str):
    """Deepest encoder feature map -- the standard Grad-CAM target."""
    if model_name == "unet":
        encoder = model.encoder
        for attr in ("layer4", "blocks"):
            if hasattr(encoder, attr):
                return getattr(encoder, attr)
        return list(encoder.children())[-1]
    if model_name == "segformer":
        return model.model.segformer.encoder.layer_norm[-1]
    raise ValueError(f"no known Grad-CAM target for {model_name!r}")


def seg_grad_cam(model, image: torch.Tensor, class_id: int, model_name: str,
                 region: torch.Tensor | None = None, target_layer=None,
                 normalize: bool = True) -> np.ndarray:
    """Grad-CAM for one class, restricted to a spatial region.

    image    : (3, H, W) normalised tensor
    class_id : CoralScapes class id to explain
    region   : optional (H, W) bool mask limiting where the class score is summed;
               defaults to the pixels the model predicted as `class_id`.
    Returns a (H, W) heat map in [0, 1].
    """
    device = get_device()
    model.to(device).eval()
    x = image.unsqueeze(0).to(device).requires_grad_(True)

    layer = target_layer or find_target_layer(model, model_name)
    hook = _Hook(layer)
    try:
        logits = model(x)                                   # (1, C, H, W)
        if region is None:
            with torch.no_grad():
                region = (logits_to_prediction(logits)[0] == class_id)
        region = region.to(device)
        if region.sum() == 0:
            hook.close()
            return np.zeros(image.shape[-2:], dtype=np.float32)

        score = (logits[0, class_id] * region.float()).sum() / region.float().sum()
        model.zero_grad(set_to_none=True)
        score.backward()

        acts = hook.activations
        grads = hook.gradients
        if acts is None or grads is None:
            raise RuntimeError("hook captured no activations/gradients")
        if acts.ndim == 3:              # transformer tokens (B, N, C) -> (B, C, h, w)
            acts, grads = _tokens_to_map(acts), _tokens_to_map(grads)

        weights = grads.mean(dim=(2, 3), keepdim=True)      # global-average-pooled
        cam = F.relu((weights * acts).sum(dim=1, keepdim=True))
        cam = F.interpolate(cam, size=image.shape[-2:], mode="bilinear",
                            align_corners=False)[0, 0]
        cam = cam.detach().cpu().numpy()
    finally:
        hook.close()

    if normalize and cam.max() > cam.min():
        cam = (cam - cam.min()) / (cam.max() - cam.min())
    return cam.astype(np.float32)


def _tokens_to_map(t: torch.Tensor) -> torch.Tensor:
    """(B, N, C) token sequence -> (B, C, h, w), assuming a square-ish grid."""
    b, n, c = t.shape
    h = int(round(float(np.sqrt(n))))
    while n % h != 0 and h > 1:
        h -= 1
    w = n // h
    return t.transpose(1, 2).reshape(b, c, h, w)


# --------------------------------------------------------------------------- #
# SegFormer attention
# --------------------------------------------------------------------------- #
@torch.no_grad()
def segformer_attention_maps(model, image: torch.Tensor,
                             stage: int = -1) -> np.ndarray | None:
    """Mean attention of the last transformer stage, as a spatial map.

    SegFormer uses sequence-reduced attention, so the map is over reduced keys;
    it is averaged over heads and queries and reshaped to the stage's grid,
    giving "where this stage attends on average".
    """
    device = get_device()
    model.to(device).eval()
    out = model(image.unsqueeze(0).to(device), output_attentions=True)
    if not isinstance(out, tuple):
        return None
    _, attentions = out
    if not attentions:
        return None
    att = attentions[stage]                     # (B, heads, queries, keys)
    a = att[0].mean(0).mean(0)                  # average heads, then queries
    n = a.shape[-1]
    h = int(round(float(np.sqrt(n))))
    while n % h != 0 and h > 1:
        h -= 1
    a = a.reshape(h, n // h)
    a = (a - a.min()) / (a.max() - a.min() + 1e-8)
    return a.detach().cpu().numpy()


# --------------------------------------------------------------------------- #
# Confidence
# --------------------------------------------------------------------------- #
@torch.no_grad()
def prediction_confidence(model, image: torch.Tensor,
                          ignore_index: int = IGNORE_INDEX) -> dict:
    """Per-pixel max probability and top-2 margin over the valid classes."""
    device = get_device()
    model.to(device).eval()
    logits = model(image.unsqueeze(0).to(device)).float()
    logits[:, ignore_index] = torch.finfo(logits.dtype).min
    probs = F.softmax(logits, dim=1)[0]
    top2 = probs.topk(2, dim=0)
    return {
        "prediction": top2.indices[0].cpu().numpy().astype(np.uint8),
        "confidence": top2.values[0].cpu().numpy(),
        "margin": (top2.values[0] - top2.values[1]).cpu().numpy(),
        "entropy": (-(probs * probs.clamp_min(1e-8).log()).sum(0)).cpu().numpy(),
    }


def yolo_confidence_visualization(result) -> dict:
    """Per-instance confidence, class and mask area from an Ultralytics result."""
    if result.masks is None or len(result.masks) == 0:
        return {"n_instances": 0, "instances": []}
    from .annotation_conversion import load_mapping
    from .config import YOLO_DATA_DIR

    mapping = load_mapping(YOLO_DATA_DIR)
    y2c = {int(k): int(v) for k, v in mapping["yolo_index_to_coral_id"].items()}
    confs = result.boxes.conf.cpu().numpy()
    classes = result.boxes.cls.cpu().numpy().astype(int)
    boxes = result.boxes.xyxy.cpu().numpy()
    masks = result.masks.data.cpu().numpy()
    order = np.argsort(-confs)
    return {
        "n_instances": int(len(confs)),
        "instances": [{
            "confidence": float(confs[i]),
            "yolo_class": int(classes[i]),
            "coralscapes_id": y2c[int(classes[i])],
            "class_name": ID_TO_NAME[y2c[int(classes[i])]],
            "box_xyxy": boxes[i].tolist(),
            "mask_area_px": float(masks[i].sum()),
        } for i in order],
    }


# --------------------------------------------------------------------------- #
# Figures
# --------------------------------------------------------------------------- #
def plot_gradcam(image_rgb: np.ndarray, cam: np.ndarray, class_id: int,
                 title: str = "", save_path: Path | None = None):
    import matplotlib.pyplot as plt

    fig, axes = plt.subplots(1, 3, figsize=(17, 5))
    axes[0].imshow(image_rgb); axes[0].set_title("Image")
    axes[1].imshow(cam, cmap="jet"); axes[1].set_title("Seg-Grad-CAM")
    axes[2].imshow(image_rgb)
    axes[2].imshow(cam, cmap="jet", alpha=0.5)
    axes[2].set_title("Overlay")
    for ax in axes:
        ax.axis("off")
    fig.suptitle(title or f"Grad-CAM for class {class_id}: {ID_TO_NAME[class_id]}")
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig


def plot_confidence(image_rgb: np.ndarray, conf: dict, save_path: Path | None = None):
    import matplotlib.pyplot as plt

    from .visualization import colorize_mask

    fig, axes = plt.subplots(1, 4, figsize=(22, 5))
    axes[0].imshow(image_rgb); axes[0].set_title("Image")
    axes[1].imshow(colorize_mask(conf["prediction"])); axes[1].set_title("Prediction")
    im2 = axes[2].imshow(conf["confidence"], cmap="viridis", vmin=0, vmax=1)
    axes[2].set_title("Max class probability")
    fig.colorbar(im2, ax=axes[2], fraction=0.046)
    im3 = axes[3].imshow(conf["entropy"], cmap="magma")
    axes[3].set_title("Predictive entropy")
    fig.colorbar(im3, ax=axes[3], fraction=0.046)
    for ax in axes:
        ax.axis("off")
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig

"""Exploratory data analysis over the official CoralScapes splits.

Produces (into outputs/metrics and outputs/visualizations):
  * dataset_stats.json  -- per-split image counts, sites, resolutions and the
                           per-class pixel counts that the class weights and
                           the class-imbalance discussion are built from
  * class distribution figures, the palette legend and qualitative samples

Run:  python -m src.explore  [--max-images-per-split N]
"""
from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import numpy as np
from PIL import Image
from tqdm import tqdm

from .config import (ALGAE_CLASS_IDS, BLEACHING_CLASS_IDS, CORAL_ALIVE_CLASS_IDS,
                     CORAL_DEAD_CLASS_IDS, ID_TO_NAME, IGNORE_INDEX, NUM_CLASSES,
                     OUTPUT_DIR, VALID_CLASS_IDS)
from .dataset import SPLITS, assert_no_site_leakage, index_all_splits

METRICS_DIR = OUTPUT_DIR / "metrics"
VIS_DIR = OUTPUT_DIR / "visualizations"


def split_statistics(samples, max_images: int | None = None,
                     desc: str = "") -> dict:
    """Pixel counts per class, resolutions and per-image class presence."""
    pixel_counts = np.zeros(NUM_CLASSES, dtype=np.int64)
    image_presence = np.zeros(NUM_CLASSES, dtype=np.int64)  # #images containing class
    resolutions: Counter = Counter()
    per_site: Counter = Counter()

    subset = samples[:max_images] if max_images else samples
    for s in tqdm(subset, desc=desc or "scanning", unit="img"):
        mask = np.array(Image.open(s.mask_path))
        if mask.ndim == 3:
            mask = mask[..., 0]
        ids, counts = np.unique(mask, return_counts=True)
        pixel_counts[ids] += counts
        image_presence[ids] += 1
        resolutions[f"{mask.shape[1]}x{mask.shape[0]}"] += 1
        per_site[s.site] += 1

    labelled = int(pixel_counts[VALID_CLASS_IDS].sum())
    pct = {int(c): (100.0 * pixel_counts[c] / labelled if labelled else 0.0)
           for c in VALID_CLASS_IDS}
    return {
        "n_images": len(subset),
        "n_sites": len(per_site),
        "sites": sorted(per_site),
        "images_per_site": dict(sorted(per_site.items())),
        "resolutions": dict(resolutions),
        "total_pixels": int(pixel_counts.sum()),
        "labelled_pixels": labelled,
        "unlabelled_pixels": int(pixel_counts[IGNORE_INDEX]),
        "unlabelled_fraction": float(pixel_counts[IGNORE_INDEX] / max(1, pixel_counts.sum())),
        "pixel_counts": {int(c): int(pixel_counts[c]) for c in range(NUM_CLASSES)},
        "pixel_percent": pct,
        "image_presence": {int(c): int(image_presence[c]) for c in range(NUM_CLASSES)},
    }


def imbalance_report(stats: dict) -> dict:
    """Quantify the long tail -- this is what motivates the loss choice."""
    pct = {int(k): v for k, v in stats["pixel_percent"].items() if v > 0}
    if not pct:
        return {}
    ordered = sorted(pct.items(), key=lambda kv: -kv[1])
    values = np.array([v for _, v in ordered])
    return {
        "n_classes_present": len(ordered),
        "most_frequent": [{"id": c, "name": ID_TO_NAME[c], "pct": round(v, 4)}
                          for c, v in ordered[:5]],
        "least_frequent": [{"id": c, "name": ID_TO_NAME[c], "pct": round(v, 5)}
                           for c, v in ordered[-5:]],
        "max_over_min_ratio": float(values[0] / values[-1]),
        "top1_share_pct": float(values[0]),
        "top5_share_pct": float(values[:5].sum()),
        "classes_below_0p1pct": int((values < 0.1).sum()),
        "classes_below_0p01pct": int((values < 0.01).sum()),
    }


def group_shares(stats: dict) -> dict:
    """Pixel share of the analysis groups used later (algae / bleaching / coral)."""
    pct = {int(k): v for k, v in stats["pixel_percent"].items()}
    def total(ids):
        return round(float(sum(pct.get(c, 0.0) for c in ids)), 4)
    return {
        "algae_pct": total(ALGAE_CLASS_IDS),
        "bleaching_pct": total(BLEACHING_CLASS_IDS),
        "coral_alive_pct": total(CORAL_ALIVE_CLASS_IDS),
        "coral_dead_pct": total(CORAL_DEAD_CLASS_IDS),
        "bleaching_per_class_pct": {ID_TO_NAME[c]: round(pct.get(c, 0.0), 5)
                                    for c in BLEACHING_CLASS_IDS},
    }


def run(max_images: int | None = None, make_figures: bool = True) -> dict:
    index = index_all_splits()
    sites = assert_no_site_leakage(index)
    print("site-disjointness verified: no dive site appears in two splits")

    report = {
        "splits": {s: {"n_images": len(index[s]), "sites": sorted(sites[s])}
                   for s in SPLITS},
        "class_mapping": {str(c): ID_TO_NAME[c] for c in sorted(ID_TO_NAME)},
        "num_classes_total": NUM_CLASSES,
        "num_classes_evaluated": len(VALID_CLASS_IDS),
        "ignore_index": IGNORE_INDEX,
    }
    for split in SPLITS:
        st = split_statistics(index[split], max_images, desc=f"{split:5s}")
        st["imbalance"] = imbalance_report(st)
        st["groups"] = group_shares(st)
        report[split] = st

    METRICS_DIR.mkdir(parents=True, exist_ok=True)
    out = METRICS_DIR / "dataset_stats.json"
    with open(out, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2)
    print(f"wrote {out}")

    if make_figures:
        make_eda_figures(report)
    return report


def make_eda_figures(report: dict) -> None:
    import matplotlib
    matplotlib.use("Agg")
    from .visualization import plot_class_distribution, save_palette_legend

    VIS_DIR.mkdir(parents=True, exist_ok=True)
    save_palette_legend(VIS_DIR / "class_palette_legend.png")
    for split in SPLITS:
        counts = {int(k): v for k, v in report[split]["pixel_percent"].items()}
        plot_class_distribution(
            counts, f"CoralScapes {split}: pixel share per class "
                    f"({report[split]['n_images']} images)",
            save_path=VIS_DIR / f"class_distribution_{split}.png")
    print(f"wrote EDA figures to {VIS_DIR}")


def main() -> None:
    ap = argparse.ArgumentParser(description="CoralScapes EDA")
    ap.add_argument("--max-images-per-split", type=int, default=None,
                    help="limit images per split (quick smoke run)")
    ap.add_argument("--no-figures", action="store_true")
    args = ap.parse_args()
    run(max_images=args.max_images_per_split, make_figures=not args.no_figures)


if __name__ == "__main__":
    main()

"""Segmentation losses for the U-Net and SegFormer experiments.

Why these losses (spec section 10)
----------------------------------
CoralScapes is severely long-tailed: a handful of substrate classes cover most
pixels while several coral classes cover well under 0.1% each. Three
consequences drive the choice below.

1. Plain cross entropy is dominated by the head classes; the tail can be
   ignored at almost no cost to the loss.
2. Dice operates on set overlap per class, so a rare class contributes on the
   same scale as a frequent one. It directly optimises the overlap that mIoU
   measures, but it is noisy when a class is absent from a crop.
3. Focal loss down-weights easy pixels, which helps hard boundaries, but on
   very noisy underwater labels it can over-focus on annotation noise.

The default is therefore **CE + Dice** with mildly rebalanced CE weights: CE
supplies stable, well-conditioned gradients, Dice supplies the class-balanced
overlap term, and the weights are capped so that a class with a handful of
pixels cannot destabilise training. Every alternative remains available via
`build_loss` so the choice can be re-run and compared rather than asserted.

All losses ignore IGNORE_INDEX (0 = unlabelled) pixels.
"""
from __future__ import annotations

import json
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import IGNORE_INDEX, NUM_CLASSES, VALID_CLASS_IDS


# --------------------------------------------------------------------------- #
# Class weights
# --------------------------------------------------------------------------- #
def compute_class_weights(pixel_counts: np.ndarray, scheme: str = "sqrt_inv",
                          clip: tuple[float, float] = (0.25, 6.0),
                          ignore_index: int = IGNORE_INDEX) -> torch.Tensor:
    """Turn per-class pixel counts into a CE weight vector.

    'sqrt_inv' (default) uses 1/sqrt(freq), normalised to mean 1 and clipped.
    Full inverse frequency was rejected: with a >10^4 frequency ratio it makes
    the rarest classes dominate the gradient and training diverges.
    """
    counts = np.asarray(pixel_counts, dtype=np.float64).copy()
    weights = np.zeros(len(counts), dtype=np.float64)
    present = np.zeros(len(counts), dtype=bool)
    for c in VALID_CLASS_IDS:
        present[c] = counts[c] > 0

    freq = np.zeros_like(counts)
    total = counts[present].sum()
    freq[present] = counts[present] / total

    if scheme == "sqrt_inv":
        w = 1.0 / np.sqrt(freq[present])
    elif scheme == "inv":
        w = 1.0 / freq[present]
    elif scheme == "log_inv":                       # ENet-style
        w = 1.0 / np.log(1.02 + freq[present])
    elif scheme == "none":
        w = np.ones(present.sum())
    else:
        raise ValueError(f"unknown weighting scheme {scheme!r}")

    w = w / w.mean()
    w = np.clip(w, clip[0], clip[1])
    weights[present] = w
    weights[ignore_index] = 0.0        # never contributes anyway
    # classes absent from the training split get weight 1 so that, if they do
    # appear, they are not silently free
    weights[(~present) & (np.arange(len(counts)) != ignore_index)] = 1.0
    return torch.tensor(weights, dtype=torch.float32)


def load_class_weights(path: Path, scheme: str = "sqrt_inv") -> torch.Tensor:
    """Load class weights from the EDA pixel-count JSON produced by explore.py."""
    with open(path, "r", encoding="utf-8") as fh:
        stats = json.load(fh)
    counts = np.zeros(NUM_CLASSES, dtype=np.float64)
    for k, v in stats["train"]["pixel_counts"].items():
        counts[int(k)] = v
    return compute_class_weights(counts, scheme=scheme)


# --------------------------------------------------------------------------- #
# Losses
# --------------------------------------------------------------------------- #
class DiceLoss(nn.Module):
    """Soft multi-class Dice, averaged over the classes present in the batch.

    Classes absent from both prediction and target within a batch are skipped
    rather than scored as perfect (which would dilute the loss towards 0).
    """

    def __init__(self, num_classes: int = NUM_CLASSES,
                 ignore_index: int = IGNORE_INDEX, smooth: float = 1.0):
        super().__init__()
        self.num_classes = num_classes
        self.ignore_index = ignore_index
        self.smooth = smooth

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        probs = F.softmax(logits, dim=1)
        valid = (target != self.ignore_index)
        target_clamped = target.clone()
        target_clamped[~valid] = 0
        onehot = F.one_hot(target_clamped, self.num_classes).permute(0, 3, 1, 2).float()

        vmask = valid.unsqueeze(1).float()
        probs = probs * vmask
        onehot = onehot * vmask

        dims = (0, 2, 3)
        inter = (probs * onehot).sum(dims)
        denom = probs.sum(dims) + onehot.sum(dims)

        keep = torch.ones(self.num_classes, dtype=torch.bool, device=logits.device)
        keep[self.ignore_index] = False
        present = (denom > 0) & keep
        if present.sum() == 0:
            return logits.sum() * 0.0
        dice = (2 * inter[present] + self.smooth) / (denom[present] + self.smooth)
        return 1.0 - dice.mean()


class FocalLoss(nn.Module):
    """Multi-class focal loss, optionally with the same class weights as CE."""

    def __init__(self, gamma: float = 2.0, weight: torch.Tensor | None = None,
                 ignore_index: int = IGNORE_INDEX):
        super().__init__()
        self.gamma = gamma
        self.register_buffer("weight", weight if weight is not None else None)
        self.ignore_index = ignore_index

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        ce = F.cross_entropy(logits, target, weight=self.weight,
                             ignore_index=self.ignore_index, reduction="none")
        with torch.no_grad():
            logp = -F.cross_entropy(logits, target, ignore_index=self.ignore_index,
                                    reduction="none")
            pt = torch.exp(logp)
        loss = ((1 - pt) ** self.gamma) * ce
        valid = target != self.ignore_index
        return loss[valid].mean() if valid.any() else logits.sum() * 0.0


class CombinedLoss(nn.Module):
    """`(1 - w) * CE  +  w * Dice` -- the default for this benchmark."""

    def __init__(self, weight: torch.Tensor | None = None, dice_weight: float = 0.5,
                 num_classes: int = NUM_CLASSES, ignore_index: int = IGNORE_INDEX,
                 label_smoothing: float = 0.0):
        super().__init__()
        self.ce = nn.CrossEntropyLoss(weight=weight, ignore_index=ignore_index,
                                      label_smoothing=label_smoothing)
        self.dice = DiceLoss(num_classes=num_classes, ignore_index=ignore_index)
        self.dice_weight = dice_weight

    def forward(self, logits: torch.Tensor, target: torch.Tensor) -> torch.Tensor:
        return ((1 - self.dice_weight) * self.ce(logits, target)
                + self.dice_weight * self.dice(logits, target))


def build_loss(name: str, class_weights: torch.Tensor | None = None,
               dice_weight: float = 0.5, num_classes: int = NUM_CLASSES,
               ignore_index: int = IGNORE_INDEX) -> nn.Module:
    """Factory so every experiment can switch loss from the config alone."""
    name = name.lower()
    if name == "ce":
        return nn.CrossEntropyLoss(ignore_index=ignore_index)
    if name == "weighted_ce":
        return nn.CrossEntropyLoss(weight=class_weights, ignore_index=ignore_index)
    if name == "dice":
        return DiceLoss(num_classes=num_classes, ignore_index=ignore_index)
    if name == "focal":
        return FocalLoss(gamma=2.0, weight=class_weights, ignore_index=ignore_index)
    if name in ("ce_dice", "combined"):
        return CombinedLoss(weight=class_weights, dice_weight=dice_weight,
                            num_classes=num_classes, ignore_index=ignore_index)
    raise ValueError(f"unknown loss {name!r}")

"""Pixel-level segmentation metrics, boundary metrics and bootstrap CIs.

All semantic metrics are derived from a single NxN confusion matrix that is
accumulated over a whole split, where N = NUM_CLASSES (40). Pixels whose
ground-truth id is IGNORE_INDEX (0 = unlabelled) are dropped before the matrix
is updated, so void regions can never inflate or deflate a score.

From the confusion matrix, for class c:
    TP = M[c, c]      FP = M[:, c].sum() - TP      FN = M[c, :].sum() - TP
    IoU  = TP / (TP + FP + FN)
    Dice = 2TP / (2TP + FP + FN)
    Precision = TP / (TP + FP)      Recall = TP / (TP + FN)

A class that is absent from the ground truth of a split AND never predicted is
reported as NaN and excluded from the means, rather than being counted as 0,
which would silently punish models for classes the split does not contain.
"""
from __future__ import annotations

import numpy as np
import torch

from .config import ID_TO_NAME, IGNORE_INDEX, NUM_CLASSES, VALID_CLASS_IDS


# --------------------------------------------------------------------------- #
# Confusion matrix
# --------------------------------------------------------------------------- #
class ConfusionMatrix:
    """Accumulates a (num_classes x num_classes) matrix: rows = GT, cols = pred."""

    def __init__(self, num_classes: int = NUM_CLASSES,
                 ignore_index: int = IGNORE_INDEX):
        self.num_classes = num_classes
        self.ignore_index = ignore_index
        self.mat = torch.zeros(num_classes, num_classes, dtype=torch.int64)

    def reset(self) -> None:
        self.mat.zero_()

    @torch.no_grad()
    def update(self, target: torch.Tensor, pred: torch.Tensor) -> None:
        """target/pred: integer tensors of identical shape holding class ids."""
        t = target.reshape(-1).to(torch.int64)
        p = pred.reshape(-1).to(torch.int64)
        keep = t != self.ignore_index
        t, p = t[keep], p[keep]
        if t.numel() == 0:
            return
        idx = t * self.num_classes + p
        binc = torch.bincount(idx.cpu(), minlength=self.num_classes ** 2)
        self.mat += binc.reshape(self.num_classes, self.num_classes)

    # -- derived quantities -------------------------------------------------- #
    def numpy(self) -> np.ndarray:
        return self.mat.numpy().astype(np.int64)

    def per_class(self, class_ids=None) -> dict:
        """Per-class IoU / Dice / precision / recall (NaN where undefined)."""
        class_ids = list(VALID_CLASS_IDS if class_ids is None else class_ids)
        m = self.numpy().astype(np.float64)
        tp = np.diag(m)
        fp = m.sum(0) - tp
        fn = m.sum(1) - tp

        def safe(num, den):
            out = np.full(self.num_classes, np.nan)
            ok = den > 0
            out[ok] = num[ok] / den[ok]
            return out

        iou = safe(tp, tp + fp + fn)
        dice = safe(2 * tp, 2 * tp + fp + fn)
        prec = safe(tp, tp + fp)
        rec = safe(tp, tp + fn)
        support = m.sum(1)                       # GT pixel count per class
        return {
            "class_ids": class_ids,
            "class_names": [ID_TO_NAME[c] for c in class_ids],
            "iou": iou[class_ids],
            "dice": dice[class_ids],
            "precision": prec[class_ids],
            "recall": rec[class_ids],
            "support": support[class_ids],
            "tp": tp[class_ids], "fp": fp[class_ids], "fn": fn[class_ids],
        }

    def summary(self, class_ids=None) -> dict:
        pc = self.per_class(class_ids)
        m = self.numpy().astype(np.float64)
        valid = np.array(list(VALID_CLASS_IDS if class_ids is None else class_ids))
        total = m[valid, :].sum()
        pixel_acc = np.diag(m)[valid].sum() / total if total > 0 else np.nan
        # frequency-weighted IoU: weights each class by its GT prevalence
        sup = pc["support"]
        w_ok = ~np.isnan(pc["iou"]) & (sup > 0)
        fw_iou = (float(np.sum(sup[w_ok] * pc["iou"][w_ok]) / np.sum(sup[w_ok]))
                  if w_ok.any() else np.nan)
        return {
            "pixel_accuracy": float(pixel_acc),
            "mean_iou": float(np.nanmean(pc["iou"])),
            "mean_dice": float(np.nanmean(pc["dice"])),
            "mean_precision": float(np.nanmean(pc["precision"])),
            "mean_recall": float(np.nanmean(pc["recall"])),
            "frequency_weighted_iou": fw_iou,
            "n_classes_present": int(np.sum(pc["support"] > 0)),
            "n_classes_scored": int(np.sum(~np.isnan(pc["iou"]))),
        }


# --------------------------------------------------------------------------- #
# Group metrics (algae / bleaching aggregates)
# --------------------------------------------------------------------------- #
def group_metrics(cm: ConfusionMatrix, class_ids: list[int]) -> dict:
    """Binary one-vs-rest metrics for a *group* of classes treated as one.

    Confusions *inside* the group count as correct, which is exactly the
    'aggregated bleaching' question: was the pixel recognised as bleached at
    all, regardless of which bleached-coral subclass was chosen.
    """
    m = cm.numpy().astype(np.float64)
    valid = list(VALID_CLASS_IDS)
    g = sorted(set(class_ids))
    others = [c for c in valid if c not in set(g)]

    tp = m[np.ix_(g, g)].sum()
    fn = m[np.ix_(g, others)].sum()
    fp = m[np.ix_(others, g)].sum()
    iou = tp / (tp + fp + fn) if (tp + fp + fn) > 0 else np.nan
    dice = 2 * tp / (2 * tp + fp + fn) if (2 * tp + fp + fn) > 0 else np.nan
    prec = tp / (tp + fp) if (tp + fp) > 0 else np.nan
    rec = tp / (tp + fn) if (tp + fn) > 0 else np.nan
    return {
        "class_ids": g,
        "class_names": [ID_TO_NAME[c] for c in g],
        "iou": float(iou), "dice": float(dice),
        "precision": float(prec), "recall": float(rec),
        "support_pixels": float(m[g, :].sum()),
        "tp": float(tp), "fp": float(fp), "fn": float(fn),
    }


# --------------------------------------------------------------------------- #
# Boundary metrics
# --------------------------------------------------------------------------- #
def _boundary_region(mask: np.ndarray, class_id: int, dilation: int) -> np.ndarray:
    """Pixels of `class_id` that lie within `dilation` px of the class border."""
    import cv2

    binary = (mask == class_id).astype(np.uint8)
    if binary.sum() == 0:
        return binary.astype(bool)
    k = 2 * dilation + 1
    kernel = np.ones((k, k), np.uint8)
    eroded = cv2.erode(binary, kernel, iterations=1,
                       borderType=cv2.BORDER_CONSTANT, borderValue=0)
    return (binary - eroded).astype(bool)


def boundary_iou(gt: np.ndarray, pred: np.ndarray, class_ids: list[int],
                 dilation_ratio: float = 0.01,
                 ignore_index: int = IGNORE_INDEX) -> dict[int, tuple[float, float]]:
    """Boundary IoU (Cheng et al., 2021) accumulated per class.

    Returns {class_id: (intersection, union)} so callers can accumulate over a
    dataset before dividing -- averaging per-image ratios would over-weight
    images that contain only a few boundary pixels.
    """
    h, w = gt.shape
    d = max(1, int(round(dilation_ratio * float(np.sqrt(h * h + w * w)))))
    valid = gt != ignore_index
    out: dict[int, tuple[float, float]] = {}
    for c in class_ids:
        gb = _boundary_region(gt, c, d) & valid
        pb = _boundary_region(pred, c, d) & valid
        inter = float(np.logical_and(gb, pb).sum())
        union = float(np.logical_or(gb, pb).sum())
        out[c] = (inter, union)
    return out


def boundary_f1(gt: np.ndarray, pred: np.ndarray, class_ids: list[int],
                tolerance: int = 3,
                ignore_index: int = IGNORE_INDEX) -> dict[int, tuple]:
    """Boundary F1 contour matching.

    Returns {class: (matched_pred, n_pred_contour, n_gt_contour, matched_gt)}.
    A predicted contour pixel counts as matched if a GT contour pixel of the
    same class lies within `tolerance` px (computed with a distance transform).
    """
    import cv2

    valid = (gt != ignore_index).astype(np.uint8)
    out: dict[int, tuple] = {}
    for c in class_ids:
        g = ((gt == c).astype(np.uint8)) * valid
        p = ((pred == c).astype(np.uint8)) * valid
        gc = cv2.Canny(g * 255, 100, 200) > 0
        pc = cv2.Canny(p * 255, 100, 200) > 0
        if gc.sum() == 0 or pc.sum() == 0:
            out[c] = (0.0, float(pc.sum()), float(gc.sum()), 0.0)
            continue
        # distance to nearest GT / pred contour pixel
        dt_g = cv2.distanceTransform((~gc).astype(np.uint8), cv2.DIST_L2, 3)
        dt_p = cv2.distanceTransform((~pc).astype(np.uint8), cv2.DIST_L2, 3)
        matched_pred = float((dt_g[pc] <= tolerance).sum())
        matched_gt = float((dt_p[gc] <= tolerance).sum())
        out[c] = (matched_pred, float(pc.sum()), float(gc.sum()), matched_gt)
    return out


def boundary_f1_from_totals(totals: dict[int, np.ndarray]) -> dict[int, float]:
    """Aggregate the tuples returned by `boundary_f1` into an F1 per class."""
    out = {}
    for c, t in totals.items():
        matched_pred, n_pred, n_gt, matched_gt = t
        precision = matched_pred / n_pred if n_pred > 0 else np.nan
        recall = matched_gt / n_gt if n_gt > 0 else np.nan
        if np.isnan(precision) or np.isnan(recall) or (precision + recall) == 0:
            out[c] = np.nan
        else:
            out[c] = float(2 * precision * recall / (precision + recall))
    return out


# --------------------------------------------------------------------------- #
# Uncertainty
# --------------------------------------------------------------------------- #
def per_image_tpfpfn(gt: np.ndarray, pred: np.ndarray, class_ids=None,
                     ignore_index: int = IGNORE_INDEX) -> np.ndarray:
    """(n_classes, 3) array of per-image TP/FP/FN, used for bootstrapping."""
    class_ids = list(VALID_CLASS_IDS if class_ids is None else class_ids)
    valid = gt != ignore_index
    g, p = gt[valid], pred[valid]
    out = np.zeros((len(class_ids), 3), dtype=np.float64)
    for i, c in enumerate(class_ids):
        gc, pc = g == c, p == c
        out[i, 0] = np.logical_and(gc, pc).sum()
        out[i, 1] = np.logical_and(~gc, pc).sum()
        out[i, 2] = np.logical_and(gc, ~pc).sum()
    return out


def miou_from_stats(stats: np.ndarray) -> float:
    """stats: (n_images, n_classes, 3) holding per-image (TP, FP, FN)."""
    s = stats.sum(axis=0)
    tp, fp, fn = s[:, 0], s[:, 1], s[:, 2]
    den = tp + fp + fn
    iou = np.divide(tp, den, out=np.full_like(tp, np.nan, dtype=np.float64),
                    where=den > 0)
    return float(np.nanmean(iou))


def dice_from_stats(stats: np.ndarray) -> float:
    s = stats.sum(axis=0)
    tp, fp, fn = s[:, 0], s[:, 1], s[:, 2]
    den = 2 * tp + fp + fn
    d = np.divide(2 * tp, den, out=np.full_like(tp, np.nan, dtype=np.float64),
                  where=den > 0)
    return float(np.nanmean(d))


def class_iou_from_stats(stats: np.ndarray, class_index: int) -> float:
    """IoU of a single class (index into the class_ids axis)."""
    s = stats[:, class_index, :].sum(axis=0)
    den = s[0] + s[1] + s[2]
    return float(s[0] / den) if den > 0 else float("nan")


def group_iou_from_stats(stats: np.ndarray, class_indices: list[int]) -> float:
    """Pooled IoU over several classes (micro-average, for group analyses)."""
    s = stats[:, class_indices, :].sum(axis=(0, 1))
    den = s[0] + s[1] + s[2]
    return float(s[0] / den) if den > 0 else float("nan")


def bootstrap_ci(per_image_stats: np.ndarray, statistic, n_boot: int = 1000,
                 alpha: float = 0.05, seed: int = 42) -> tuple[float, float, float]:
    """Percentile bootstrap over *images*.

    `per_image_stats` is (n_images, ...) of sufficient statistics; `statistic`
    maps a resampled block to a scalar. Resampling whole images (not pixels)
    respects the fact that pixels within an image are highly correlated.
    """
    rng = np.random.default_rng(seed)
    n = len(per_image_stats)
    point = float(statistic(per_image_stats))
    if n < 2:
        return point, float("nan"), float("nan")
    boots = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, size=n)
        boots[i] = statistic(per_image_stats[idx])
    lo, hi = np.nanpercentile(boots, [100 * alpha / 2, 100 * (1 - alpha / 2)])
    return point, float(lo), float(hi)


def paired_bootstrap_diff(stats_a: np.ndarray, stats_b: np.ndarray,
                          statistic=miou_from_stats, n_boot: int = 1000,
                          seed: int = 42) -> dict:
    """Paired bootstrap of (A - B) over the same images.

    Pairing removes image difficulty as a nuisance factor, which is what makes
    it possible to say whether a small gap between two models is meaningful.
    """
    rng = np.random.default_rng(seed)
    n = len(stats_a)
    assert n == len(stats_b), "paired bootstrap needs the same images"
    point = float(statistic(stats_a) - statistic(stats_b))
    diffs = np.empty(n_boot)
    for i in range(n_boot):
        idx = rng.integers(0, n, size=n)
        diffs[i] = statistic(stats_a[idx]) - statistic(stats_b[idx])
    lo, hi = np.nanpercentile(diffs, [2.5, 97.5])
    p_two_sided = 2 * min(float((diffs <= 0).mean()), float((diffs >= 0).mean()))
    return {"diff": point, "ci_low": float(lo), "ci_high": float(hi),
            "p_value_approx": float(min(1.0, p_two_sided)),
            "significant_at_95": bool(lo > 0 or hi < 0)}

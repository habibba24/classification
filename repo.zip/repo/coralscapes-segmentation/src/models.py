"""Model builders for the two semantic-segmentation architectures.

Both expose the same contract so the training and evaluation code is shared:

    model(images) -> logits of shape (B, NUM_CLASSES, H, W)

with H, W equal to the *input* resolution. SegFormer natively predicts at
stride 4, so `SegFormerWrapper` upsamples the logits back to the input size,
which keeps the loss and every metric identical between the two models.

Channel i of the output always corresponds to CoralScapes class id i, with
channel 0 = 'unlabeled'. That channel is never supervised (it is the loss
ignore_index) and is masked out at prediction time by `logits_to_prediction`,
so a model can never emit the void label.
"""
from __future__ import annotations

import torch
import torch.nn as nn
import torch.nn.functional as F

from .config import CFG, IGNORE_INDEX, NUM_CLASSES, Config


# --------------------------------------------------------------------------- #
# U-Net (CNN baseline)
# --------------------------------------------------------------------------- #
def build_unet(num_classes: int = NUM_CLASSES, encoder: str = "resnet50",
               encoder_weights: str | None = "imagenet") -> nn.Module:
    """U-Net with an ImageNet-pretrained ResNet50 encoder.

    segmentation_models_pytorch gives the canonical U-Net topology: the encoder
    produces five feature scales, each of which is passed to the matching
    decoder stage through a skip connection, and a 1x1 head maps the final
    decoder features to `num_classes` at full input resolution.
    """
    import segmentation_models_pytorch as smp

    return smp.Unet(
        encoder_name=encoder,
        encoder_weights=encoder_weights,
        in_channels=3,
        classes=num_classes,
    )


def set_encoder_trainable(model: nn.Module, trainable: bool) -> None:
    """Freeze/unfreeze the pretrained encoder (transfer-learning schedule).

    Works for both architectures: smp models expose `.encoder`, the SegFormer
    wrapper exposes `.encoder_module`.
    """
    encoder = getattr(model, "encoder", None)
    if encoder is None:
        encoder = getattr(model, "encoder_module", None)
    if encoder is None:
        raise AttributeError("model exposes no encoder to freeze")
    for p in encoder.parameters():
        p.requires_grad = trainable


def param_groups(model: nn.Module, base_lr: float, encoder_lr: float):
    """Discriminative learning rates: small LR for pretrained encoder weights.

    A freshly initialised decoder needs a much larger step than a pretrained
    backbone, which would otherwise be destroyed in the first few hundred
    iterations.
    """
    # `is not None` rather than `or`: a container module with __len__ == 0 is
    # falsy, which would silently skip the encoder and give it the decoder LR.
    encoder = getattr(model, "encoder", None)
    if encoder is None:
        encoder = getattr(model, "encoder_module", None)
    enc_ids = {id(p) for p in encoder.parameters()} if encoder is not None else set()
    enc_params = [p for p in model.parameters() if id(p) in enc_ids and p.requires_grad]
    dec_params = [p for p in model.parameters() if id(p) not in enc_ids and p.requires_grad]
    groups = []
    if enc_params:
        groups.append({"params": enc_params, "lr": encoder_lr, "name": "encoder"})
    if dec_params:
        groups.append({"params": dec_params, "lr": base_lr, "name": "decoder"})
    return groups


# --------------------------------------------------------------------------- #
# SegFormer (transformer)
# --------------------------------------------------------------------------- #
class SegFormerWrapper(nn.Module):
    """SegFormer that behaves like any other (B, C, H, W) segmentation model.

    The pretrained checkpoint's classification head is discarded and rebuilt for
    the exact CoralScapes class count -- the pretrained label space (ImageNet or
    ADE20K/Cityscapes) has nothing to do with CoralScapes ids, so reusing it
    would silently mis-map every class.
    """

    def __init__(self, num_classes: int = NUM_CLASSES,
                 checkpoint: str = "nvidia/mit-b0"):
        super().__init__()
        from transformers import SegformerConfig, SegformerForSemanticSegmentation

        cfg = SegformerConfig.from_pretrained(checkpoint)
        cfg.num_labels = num_classes
        # `ignore_mismatched_sizes` lets us load the pretrained encoder while the
        # head is re-initialised at the new class count.
        self.model = SegformerForSemanticSegmentation.from_pretrained(
            checkpoint, config=cfg, ignore_mismatched_sizes=True)
        self.num_classes = num_classes

    @property
    def encoder_module(self) -> nn.Module:
        return self.model.segformer

    def forward(self, pixel_values: torch.Tensor,
                output_attentions: bool = False) -> torch.Tensor:
        out = self.model(pixel_values=pixel_values,
                         output_attentions=output_attentions)
        logits = out.logits                       # (B, C, H/4, W/4)
        logits = F.interpolate(logits, size=pixel_values.shape[-2:],
                               mode="bilinear", align_corners=False)
        if output_attentions:
            return logits, out.attentions
        return logits


def build_segformer(num_classes: int = NUM_CLASSES,
                    checkpoint: str = "nvidia/mit-b0") -> nn.Module:
    return SegFormerWrapper(num_classes=num_classes, checkpoint=checkpoint)


def build_model(name: str, cfg: Config = CFG, num_classes: int = NUM_CLASSES,
                pretrained: bool = True) -> nn.Module:
    name = name.lower()
    if name == "unet":
        return build_unet(num_classes, cfg.unet_encoder,
                          "imagenet" if pretrained else None)
    if name == "segformer":
        return build_segformer(num_classes, cfg.segformer_checkpoint)
    raise ValueError(f"unknown model {name!r} (expected 'unet' or 'segformer')")


# --------------------------------------------------------------------------- #
# Prediction helper
# --------------------------------------------------------------------------- #
def logits_to_prediction(logits: torch.Tensor,
                         ignore_index: int = IGNORE_INDEX) -> torch.Tensor:
    """Argmax over the *valid* classes only.

    Channel `ignore_index` is never trained, so leaving it in the argmax would
    let an untrained channel win on ambiguous pixels and emit the void label,
    which is not a legal prediction.
    """
    masked = logits.clone()
    masked[:, ignore_index] = torch.finfo(masked.dtype).min
    return masked.argmax(dim=1)


def count_parameters(model: nn.Module) -> dict:
    total = sum(p.numel() for p in model.parameters())
    trainable = sum(p.numel() for p in model.parameters() if p.requires_grad)
    size_mb = sum(p.numel() * p.element_size() for p in model.parameters()) / 1024 ** 2
    buf_mb = sum(b.numel() * b.element_size() for b in model.buffers()) / 1024 ** 2
    return {
        "total_parameters": int(total),
        "trainable_parameters": int(trainable),
        "parameter_size_mb": round(size_mb, 2),
        "buffer_size_mb": round(buf_mb, 3),
        "model_size_mb": round(size_mb + buf_mb, 2),
    }

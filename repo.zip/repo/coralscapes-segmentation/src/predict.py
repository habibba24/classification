"""Unified inference interface across the three models (spec section 25).

    from src.predict import predict
    result = predict("some_reef_photo.jpg", "unet")       # or "segformer" / "yolo_seg"

or from the command line:

    python -m src.predict path/to/image.jpg --model segformer --show

`predict` returns a dict with a consistent shape for every model:

    {
      "model": str,
      "image": HxWx3 uint8,
      "mask": HxW uint8 of CoralScapes class ids,   # yolo_seg: rasterised instances
      "classes": [{"id", "name", "pixel_fraction", ...}],
      "instances": [...] | None,                   # yolo_seg only
      "inference_time_ms": float,
    }

so downstream code does not branch on the model. YOLO-Seg additionally reports
per-instance boxes, masks, classes and confidences, which the semantic models
structurally cannot provide.
"""
from __future__ import annotations

import argparse
import time
from pathlib import Path

import numpy as np
import torch
from PIL import Image

from .config import (CFG, CHECKPOINT_DIR, ID_TO_COLOR, ID_TO_NAME, IGNORE_INDEX,
                     OUTPUT_DIR, YOLO_DATA_DIR, Config, get_device)
from .models import build_model, logits_to_prediction
from .transforms import eval_transform
from .visualization import colorize_mask, legend_handles, overlay_mask

MODEL_NAMES = ("unet", "segformer", "yolo_seg")
_CACHE: dict[str, object] = {}


def load_model(model_name: str, cfg: Config = CFG, checkpoint: Path | None = None):
    """Load (and cache) a trained model by name."""
    if model_name in _CACHE and checkpoint is None:
        return _CACHE[model_name]

    if model_name in ("unet", "segformer"):
        ckpt = Path(checkpoint or CHECKPOINT_DIR / f"best_{model_name}.pth")
        if not ckpt.exists():
            raise FileNotFoundError(
                f"{ckpt} not found -- train the model first "
                f"(python -m src.train_{model_name})")
        model = build_model(model_name, cfg, pretrained=False)
        state = torch.load(ckpt, map_location="cpu", weights_only=False)
        model.load_state_dict(state["model_state_dict"])
        model.to(get_device(cfg)).eval()
    elif model_name == "yolo_seg":
        from ultralytics import YOLO

        ckpt = Path(checkpoint or CHECKPOINT_DIR / "best_yolo_seg.pt")
        if not ckpt.exists():
            raise FileNotFoundError(
                f"{ckpt} not found -- train YOLO-Seg first (python -m src.train_yolo)")
        model = YOLO(str(ckpt))
    else:
        raise ValueError(f"model_name must be one of {MODEL_NAMES}, got {model_name!r}")

    _CACHE[model_name] = model
    return model


def _class_summary(mask: np.ndarray) -> list[dict]:
    ids, counts = np.unique(mask, return_counts=True)
    total = int(counts.sum())
    out = []
    for c, n in sorted(zip(ids.tolist(), counts.tolist()), key=lambda kv: -kv[1]):
        if c == IGNORE_INDEX:
            continue
        out.append({"id": int(c), "name": ID_TO_NAME[int(c)],
                    "pixels": int(n), "pixel_fraction": round(n / total, 5)})
    return out


def predict(image_path: str | Path, model_name: str = "unet", cfg: Config = CFG,
            checkpoint: Path | None = None, conf: float = 0.25,
            keep_native_size: bool = True) -> dict:
    """Run one image through one of the three models."""
    if model_name not in MODEL_NAMES:
        raise ValueError(f"model_name must be one of {MODEL_NAMES}, got {model_name!r}")

    image = np.array(Image.open(image_path).convert("RGB"))
    H, W = image.shape[:2]
    model = load_model(model_name, cfg, checkpoint)
    device = get_device(cfg)

    if model_name in ("unet", "segformer"):
        h, w = cfg.eval_image_size
        tf = eval_transform(h, w)
        x = tf(image=image, mask=np.zeros((H, W), np.uint8))["image"].unsqueeze(0)

        t0 = time.perf_counter()
        with torch.no_grad():
            logits = model(x.to(device))
            if device.type == "cuda":
                torch.cuda.synchronize()
        dt = (time.perf_counter() - t0) * 1000

        mask = logits_to_prediction(logits.float())[0].cpu().numpy().astype(np.uint8)
        if keep_native_size and mask.shape != (H, W):
            mask = np.array(Image.fromarray(mask).resize((W, H), Image.NEAREST))
        return {"model": model_name, "image": image, "mask": mask,
                "classes": _class_summary(mask), "instances": None,
                "inference_time_ms": dt}

    # --- YOLO-Seg ---------------------------------------------------------- #
    import cv2

    from .annotation_conversion import load_mapping

    mapping = load_mapping(YOLO_DATA_DIR)
    y2c = {int(k): int(v) for k, v in mapping["yolo_index_to_coral_id"].items()}

    t0 = time.perf_counter()
    res = model.predict(str(image_path), imgsz=cfg.yolo_image_size, conf=conf,
                        verbose=False)[0]
    dt = (time.perf_counter() - t0) * 1000

    mask = np.zeros((H, W), dtype=np.uint8)
    instances: list[dict] = []
    if res.masks is not None and len(res.masks) > 0:
        polys = res.masks.xy
        classes = res.boxes.cls.cpu().numpy().astype(int)
        confs = res.boxes.conf.cpu().numpy()
        boxes = res.boxes.xyxy.cpu().numpy()
        sx, sy = W / res.orig_shape[1], H / res.orig_shape[0]
        areas = [cv2.contourArea(p.astype(np.int32)) if len(p) >= 3 else 0.0
                 for p in polys]
        for i in np.argsort(-np.asarray(areas)):        # large first, small on top
            if len(polys[i]) < 3:
                continue
            pts = polys[i].copy()
            pts[:, 0] *= sx
            pts[:, 1] *= sy
            coral_id = y2c[int(classes[i])]
            cv2.fillPoly(mask, [pts.astype(np.int32)], int(coral_id))
            instances.append({
                "coralscapes_id": coral_id, "class_name": ID_TO_NAME[coral_id],
                "confidence": float(confs[i]),
                "box_xyxy": [float(boxes[i][0] * sx), float(boxes[i][1] * sy),
                             float(boxes[i][2] * sx), float(boxes[i][3] * sy)],
                "polygon": pts.tolist(), "area_px": float(areas[i]),
            })
        instances.sort(key=lambda d: -d["confidence"])

    return {"model": model_name, "image": image, "mask": mask,
            "classes": _class_summary(mask), "instances": instances,
            "inference_time_ms": dt}


def visualize_prediction(result: dict, save_path: Path | None = None,
                         max_legend: int = 12, show_boxes: bool = True):
    """Image | predicted mask | overlay (+ instance boxes for YOLO-Seg)."""
    import matplotlib.pyplot as plt
    from matplotlib.patches import Rectangle

    image, mask = result["image"], result["mask"]
    n_panels = 4 if result.get("instances") else 3
    fig, axes = plt.subplots(1, n_panels, figsize=(5.6 * n_panels, 5.4))

    axes[0].imshow(image); axes[0].set_title("Input image")
    axes[1].imshow(colorize_mask(mask))
    axes[1].set_title(f"{result['model']} prediction")
    axes[2].imshow(overlay_mask(image, mask)); axes[2].set_title("Overlay")

    if result.get("instances"):
        axes[3].imshow(image)
        for inst in result["instances"][:40]:
            x1, y1, x2, y2 = inst["box_xyxy"]
            color = np.array(ID_TO_COLOR[inst["coralscapes_id"]]) / 255.0
            if show_boxes:
                axes[3].add_patch(Rectangle((x1, y1), x2 - x1, y2 - y1, fill=False,
                                            edgecolor=color, linewidth=1.6))
                axes[3].text(x1, max(0, y1 - 4),
                             f"{inst['class_name']} {inst['confidence']:.2f}",
                             fontsize=6, color="white",
                             bbox=dict(facecolor=color, alpha=0.85, pad=0.7,
                                       edgecolor="none"))
        axes[3].set_title(f"Instances ({len(result['instances'])}) "
                          "with class + confidence")

    for ax in axes:
        ax.axis("off")

    present = [c["id"] for c in result["classes"][:max_legend]]
    if present:
        fig.legend(handles=legend_handles(present), loc="lower center",
                   ncol=min(6, len(present)), fontsize=8, frameon=False,
                   bbox_to_anchor=(0.5, -0.09))
    fig.suptitle(f"{result['model']} - {result['inference_time_ms']:.1f} ms",
                 fontsize=12)
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig


def print_prediction_summary(result: dict, top_k: int = 10) -> None:
    print(f"\nmodel              : {result['model']}")
    print(f"inference time     : {result['inference_time_ms']:.1f} ms")
    print(f"classes predicted  : {len(result['classes'])}")
    print(f"\n{'class id':>9}  {'name':<32}{'pixel share':>12}")
    for c in result["classes"][:top_k]:
        print(f"{c['id']:>9}  {c['name']:<32}{100 * c['pixel_fraction']:>11.2f}%")
    if result.get("instances"):
        print(f"\ninstances detected : {len(result['instances'])}")
        print(f"{'conf':>6}  {'class':<32}{'area px':>10}")
        for inst in result["instances"][:top_k]:
            print(f"{inst['confidence']:>6.2f}  {inst['class_name']:<32}"
                  f"{inst['area_px']:>10.0f}")


def main() -> None:
    import matplotlib
    matplotlib.use("Agg")

    ap = argparse.ArgumentParser(description="Run inference on one image")
    ap.add_argument("image")
    ap.add_argument("--model", default="unet", choices=list(MODEL_NAMES))
    ap.add_argument("--conf", type=float, default=0.25)
    ap.add_argument("--save", default=None)
    args = ap.parse_args()

    result = predict(args.image, args.model, conf=args.conf)
    print_prediction_summary(result)
    out = Path(args.save) if args.save else (
        OUTPUT_DIR / "visualizations" / "demo" /
        f"{Path(args.image).stem}_{args.model}.png")
    visualize_prediction(result, save_path=out)
    print(f"\nsaved visualisation to {out}")


if __name__ == "__main__":
    main()

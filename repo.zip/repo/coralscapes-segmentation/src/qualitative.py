"""Qualitative comparison and error analysis (spec sections 17 and 19).

Builds side-by-side figures on the SAME test images for all three models, with
scenes chosen deliberately rather than at random:

  easy            -- few classes, large regions
  difficult       -- many classes in one frame
  algae           -- images with a substantial 'algae covered substrate' area
  bleaching       -- images containing any bleached-coral class
  small_regions   -- images dominated by small connected components
  boundary_heavy  -- images with a high border-pixel to area ratio
  low_contrast    -- visually flat, turbid/deep frames (low pixel std)

Error analysis then mines the confusion matrix for the largest systematic
confusions and renders examples of each.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import torch
from tqdm import tqdm

from .config import (ALGAE_CLASS_IDS, BLEACHING_CLASS_IDS, CFG, CHECKPOINT_DIR,
                     ID_TO_NAME, IGNORE_INDEX, OUTPUT_DIR, VALID_CLASS_IDS,
                     Config, get_device)
from .dataset import CoralScapesDataset
from .models import build_model, logits_to_prediction
from .visualization import comparison_row, colorize_mask, overlay_mask

VIS_DIR = OUTPUT_DIR / "visualizations"


# --------------------------------------------------------------------------- #
# Scene selection
# --------------------------------------------------------------------------- #
def characterise_split(split: str = "test", cfg: Config = CFG,
                       max_images: int | None = None) -> list[dict]:
    """Cheap per-image descriptors used to pick representative scenes."""
    import cv2

    ds = get_dataset(split, cfg)
    n = len(ds) if max_images is None else min(max_images, len(ds))
    records = []
    for i in tqdm(range(n), desc=f"characterising {split}", unit="img"):
        image, mask = ds.load_raw(i)
        s = ds.samples[i]
        valid = mask != IGNORE_INDEX
        n_valid = int(valid.sum())
        if n_valid == 0:
            continue
        ids, counts = np.unique(mask[valid], return_counts=True)

        # boundary density: fraction of valid pixels that sit on a class border
        grad_x = np.abs(np.diff(mask.astype(np.int16), axis=1, prepend=0))
        grad_y = np.abs(np.diff(mask.astype(np.int16), axis=0, prepend=0))
        border = ((grad_x > 0) | (grad_y > 0)) & valid

        small = 0
        for c in ids:
            nlab, _, st, _ = cv2.connectedComponentsWithStats(
                (mask == c).astype(np.uint8), connectivity=8)
            if nlab > 1:
                small += int((st[1:, cv2.CC_STAT_AREA] < 0.002 * n_valid).sum())

        gray = cv2.cvtColor(image, cv2.COLOR_RGB2GRAY)
        records.append({
            "index": i, "stem": s.stem, "site": s.site,
            "n_classes": int(len(ids)),
            "dominant_class": int(ids[np.argmax(counts)]),
            "dominant_share": float(counts.max() / n_valid),
            "algae_frac": float(sum((mask == c).sum() for c in ALGAE_CLASS_IDS) / n_valid),
            "bleach_frac": float(sum((mask == c).sum() for c in BLEACHING_CLASS_IDS) / n_valid),
            "border_density": float(border.sum() / n_valid),
            "n_small_components": small,
            "contrast_std": float(gray.std()),
            "mean_intensity": float(gray.mean()),
        })
    return records


def select_scenes(records: list[dict], per_category: int = 3) -> dict[str, list[dict]]:
    """Pick the most extreme images for each qualitative category."""
    def top(key, reverse=True, condition=None):
        pool = [r for r in records if condition(r)] if condition else list(records)
        pool.sort(key=lambda r: r[key], reverse=reverse)
        return pool[:per_category]

    return {
        "easy": top("dominant_share", True, lambda r: r["n_classes"] <= 4),
        "difficult": top("n_classes", True),
        "algae": top("algae_frac", True, lambda r: r["algae_frac"] > 0),
        "bleaching": top("bleach_frac", True, lambda r: r["bleach_frac"] > 0),
        "small_regions": top("n_small_components", True),
        "boundary_heavy": top("border_density", True),
        "low_contrast": top("contrast_std", False),
    }


# --------------------------------------------------------------------------- #
# Prediction gathering
# --------------------------------------------------------------------------- #
def load_semantic_models(cfg: Config = CFG) -> dict:
    models = {}
    for name in ("unet", "segformer"):
        ckpt = CHECKPOINT_DIR / f"best_{name}.pth"
        if not ckpt.exists():
            print(f"  {name}: no checkpoint, skipping")
            continue
        m = build_model(name, cfg, pretrained=False)
        state = torch.load(ckpt, map_location="cpu", weights_only=False)
        m.load_state_dict(state["model_state_dict"])
        models[name] = m.to(get_device(cfg)).eval()
    return models


_DATASET_CACHE: dict[tuple, CoralScapesDataset] = {}


def get_dataset(split: str, cfg: Config = CFG) -> CoralScapesDataset:
    """Cached dataset: constructing one re-globs the split, which is expensive
    when called once per image over a few hundred images."""
    key = (split, tuple(cfg.eval_image_size))
    if key not in _DATASET_CACHE:
        _DATASET_CACHE[key] = CoralScapesDataset(split, cfg=cfg, augment=False)
    return _DATASET_CACHE[key]


@torch.no_grad()
def predict_all(index: int, split: str, semantic_models: dict, yolo=None,
                cfg: Config = CFG) -> tuple[np.ndarray, np.ndarray, dict]:
    """Same image through every available model, at the same resolution."""
    ds = get_dataset(split, cfg)
    image_t, mask_t = ds[index]
    gt = mask_t.numpy().astype(np.uint8)
    from .transforms import denormalize
    image = denormalize(image_t)
    device = get_device(cfg)

    preds: dict[str, np.ndarray] = {}
    for name, model in semantic_models.items():
        logits = model(image_t.unsqueeze(0).to(device))
        preds[name] = logits_to_prediction(
            logits.float())[0].cpu().numpy().astype(np.uint8)

    if yolo is not None:
        preds["yolo_seg"] = _yolo_semantic(yolo, ds.samples[index].image_path,
                                           gt.shape, cfg)
    return image, gt, preds


def _yolo_semantic(yolo, image_path, out_shape, cfg: Config) -> np.ndarray:
    """YOLO instance predictions rasterised to a semantic map at `out_shape`."""
    import cv2

    from .annotation_conversion import load_mapping
    from .config import YOLO_DATA_DIR

    mapping = load_mapping(YOLO_DATA_DIR)
    y2c = {int(k): int(v) for k, v in mapping["yolo_index_to_coral_id"].items()}
    res = yolo.predict(str(image_path), imgsz=cfg.yolo_image_size, conf=0.25,
                       verbose=False)[0]
    H, W = out_shape
    canvas = np.zeros((H, W), dtype=np.uint8)
    if res.masks is None or len(res.masks) == 0:
        return canvas
    sx, sy = W / res.orig_shape[1], H / res.orig_shape[0]
    polys, classes = res.masks.xy, res.boxes.cls.cpu().numpy().astype(int)
    areas = [cv2.contourArea(p.astype(np.int32)) if len(p) >= 3 else 0.0 for p in polys]
    for i in np.argsort(-np.asarray(areas)):
        if len(polys[i]) < 3:
            continue
        p = polys[i].copy()
        p[:, 0] *= sx
        p[:, 1] *= sy
        cv2.fillPoly(canvas, [p.astype(np.int32)], int(y2c[int(classes[i])]))
    return canvas


# --------------------------------------------------------------------------- #
# Figures
# --------------------------------------------------------------------------- #
def qualitative_comparison(split: str = "test", per_category: int = 2,
                           cfg: Config = CFG, max_images: int | None = None,
                           use_yolo: bool = True) -> dict:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    records = characterise_split(split, cfg, max_images)
    scenes = select_scenes(records, per_category)
    models = load_semantic_models(cfg)

    yolo = None
    if use_yolo and (CHECKPOINT_DIR / "best_yolo_seg.pt").exists():
        from ultralytics import YOLO
        yolo = YOLO(str(CHECKPOINT_DIR / "best_yolo_seg.pt"))

    out_dir = VIS_DIR / "qualitative_comparison"
    out_dir.mkdir(parents=True, exist_ok=True)
    manifest = {}
    for category, items in scenes.items():
        manifest[category] = []
        for rec in items:
            image, gt, preds = predict_all(rec["index"], split, models, yolo, cfg)
            title = (f"[{category}] {rec['stem']} | {rec['n_classes']} classes, "
                     f"algae {100 * rec['algae_frac']:.1f}%, "
                     f"bleached {100 * rec['bleach_frac']:.1f}%, "
                     f"border density {rec['border_density']:.3f}")
            fig = comparison_row(image, gt, preds, title=title,
                                 save_path=out_dir / f"{category}_{rec['stem']}.png")
            plt.close(fig)
            manifest[category].append({"stem": rec["stem"], **rec})

    path = OUTPUT_DIR / "metrics" / "qualitative_scenes.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(manifest, fh, indent=2, default=float)
    print(f"wrote qualitative figures to {out_dir}")
    return manifest


# --------------------------------------------------------------------------- #
# Error analysis
# --------------------------------------------------------------------------- #
def top_confusions(model_name: str, top_k: int = 12) -> list[dict]:
    """Largest off-diagonal confusions from a saved confusion matrix."""
    path = OUTPUT_DIR / "metrics" / f"{model_name}_confusion.npy"
    if not path.exists():
        return []
    cm = np.load(path).astype(np.float64)
    rows = cm.sum(axis=1, keepdims=True)
    frac = np.divide(cm, rows, out=np.zeros_like(cm), where=rows > 0)

    out = []
    for gt_id in VALID_CLASS_IDS:
        for pred_id in VALID_CLASS_IDS:
            if gt_id == pred_id or cm[gt_id, pred_id] == 0:
                continue
            out.append({
                "gt_id": int(gt_id), "gt_name": ID_TO_NAME[gt_id],
                "pred_id": int(pred_id), "pred_name": ID_TO_NAME[pred_id],
                "pixels": int(cm[gt_id, pred_id]),
                "share_of_gt_class": float(frac[gt_id, pred_id]),
            })
    out.sort(key=lambda d: -d["pixels"])
    return out[:top_k]


def error_analysis(split: str = "test", cfg: Config = CFG, n_examples: int = 6,
                   max_images: int | None = None, use_yolo: bool = True) -> dict:
    """Rank systematic confusions and render an example of the worst ones."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    models = load_semantic_models(cfg)
    yolo = None
    if use_yolo and (CHECKPOINT_DIR / "best_yolo_seg.pt").exists():
        from ultralytics import YOLO
        yolo = YOLO(str(CHECKPOINT_DIR / "best_yolo_seg.pt"))

    report = {"confusions": {m: top_confusions(m) for m in
                             list(models) + (["yolo_seg"] if yolo else [])}}

    # find, per model, the images where that model does worst
    ds = get_dataset(split, cfg)
    n = len(ds) if max_images is None else min(max_images, len(ds))
    out_dir = VIS_DIR / "error_analysis"
    out_dir.mkdir(parents=True, exist_ok=True)

    per_image_scores = []
    for i in tqdm(range(n), desc="scoring for error analysis", unit="img"):
        image, gt, preds = predict_all(i, split, models, yolo, cfg)
        if not preds:
            break
        valid = gt != IGNORE_INDEX
        acc = {k: float((p[valid] == gt[valid]).mean()) for k, p in preds.items()}
        per_image_scores.append({"index": i, "stem": ds.samples[i].stem,
                                 "accuracy": acc,
                                 "mean_accuracy": float(np.mean(list(acc.values())))})

    per_image_scores.sort(key=lambda d: d["mean_accuracy"])
    worst = per_image_scores[:n_examples]
    for rec in worst:
        image, gt, preds = predict_all(rec["index"], split, models, yolo, cfg)
        accs = ", ".join(f"{k} {100 * v:.1f}%" for k, v in rec["accuracy"].items())
        fig = comparison_row(image, gt, preds,
                             title=f"failure case {rec['stem']} | pixel accuracy: {accs}",
                             save_path=out_dir / f"failure_{rec['stem']}.png")
        plt.close(fig)

    report["worst_images"] = worst
    report["note"] = ("confusions are ranked by absolute mis-assigned pixel count; "
                      "'share_of_gt_class' shows how much of the true class was lost "
                      "to that particular wrong label")
    path = OUTPUT_DIR / "metrics" / "error_analysis.json"
    with open(path, "w", encoding="utf-8") as fh:
        json.dump(report, fh, indent=2, default=float)
    print(f"wrote error analysis to {path} and figures to {out_dir}")
    return report


def main() -> None:
    ap = argparse.ArgumentParser(description="Qualitative comparison + error analysis")
    ap.add_argument("--split", default="test")
    ap.add_argument("--per-category", type=int, default=2)
    ap.add_argument("--n-failures", type=int, default=6)
    ap.add_argument("--max-images", type=int, default=None)
    ap.add_argument("--no-yolo", action="store_true")
    ap.add_argument("--skip-errors", action="store_true")
    args = ap.parse_args()

    qualitative_comparison(args.split, args.per_category, max_images=args.max_images,
                           use_yolo=not args.no_yolo)
    if not args.skip_errors:
        error_analysis(args.split, n_examples=args.n_failures,
                       max_images=args.max_images, use_yolo=not args.no_yolo)


if __name__ == "__main__":
    main()

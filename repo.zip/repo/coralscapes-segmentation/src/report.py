"""Assemble the final comparison tables and the scientific conclusion.

    python -m src.report

Every number here is read from the JSON files written by src/evaluate.py and
src/benchmark.py. Nothing is estimated, interpolated or filled in from
expectation: if a result file is missing, the cell is rendered "N/A" and the
conclusion states plainly that the experiment has not been run. The ranking
statements are generated from the measured values and from the paired-bootstrap
comparison, and a gap whose 95% CI contains zero is reported as not resolvable
rather than as a win.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np

from .config import BLEACHING_CLASS_IDS, ID_TO_NAME, OUTPUT_DIR

METRICS_DIR = OUTPUT_DIR / "metrics"
COMPARISON_DIR = OUTPUT_DIR / "comparison"
NA = "N/A"
SEMANTIC_MODELS = ("unet", "segformer")
ALL_MODELS = ("unet", "segformer", "yolo_seg")
PRETTY = {"unet": "U-Net", "segformer": "SegFormer", "yolo_seg": "YOLO-Seg"}


def _load(path: Path):
    if not path.exists():
        return None
    with open(path, "r", encoding="utf-8") as fh:
        return json.load(fh)


def load_all() -> dict:
    data = {"metrics": {}, "benchmark": _load(METRICS_DIR / "computational_benchmark.json"),
            "statistics": _load(METRICS_DIR / "statistical_comparison.json"),
            "conversion": _load(METRICS_DIR / "yolo_conversion_verification.json"),
            "dataset": _load(METRICS_DIR / "dataset_stats.json"),
            "history": {}}
    for m in ALL_MODELS:
        data["metrics"][m] = _load(METRICS_DIR / f"{m}_test_metrics.json")
        h = _load(OUTPUT_DIR / m / "history.json")
        if h is None and m == "yolo_seg":
            h = _load(OUTPUT_DIR / "yolo_seg" / "training_meta.json")
        data["history"][m] = h
    return data


def _fmt(x, nd: int = 4) -> str:
    if x is None:
        return NA
    try:
        x = float(x)
    except (TypeError, ValueError):
        return NA
    return NA if not np.isfinite(x) else f"{x:.{nd}f}"


def _get(d, *keys, default=None):
    for k in keys:
        if d is None:
            return default
        d = d.get(k) if isinstance(d, dict) else None
    return default if d is None else d


# --------------------------------------------------------------------------- #
# Tables
# --------------------------------------------------------------------------- #
def _semantic_source(data: dict, model: str):
    """Where a model's pixel-level numbers live (YOLO's come from rasterisation)."""
    m = data["metrics"].get(model)
    if m is None:
        return None
    return m.get("semantic_from_instances") if model == "yolo_seg" else m


def segmentation_quality_table(data: dict) -> str:
    rows = [
        ("mIoU", lambda s: _get(s, "summary", "mean_iou")),
        ("Mean Dice", lambda s: _get(s, "summary", "mean_dice")),
        ("Pixel accuracy", lambda s: _get(s, "summary", "pixel_accuracy")),
        ("Frequency-weighted IoU", lambda s: _get(s, "summary", "frequency_weighted_iou")),
        ("Algae IoU", lambda s: _get(s, "algae", "aggregated", "iou")),
        ("Bleaching IoU (aggregated)", lambda s: _get(s, "bleaching", "aggregated", "iou")),
        ("Mean Boundary IoU", lambda s: _get(s, "boundary", "mean_boundary_iou")),
        ("Mean Boundary F1", lambda s: _get(s, "boundary", "mean_boundary_f1")),
    ]
    src = {m: _semantic_source(data, m) for m in ALL_MODELS}
    lines = ["| Metric | U-Net | SegFormer | YOLO-Seg |",
             "| --- | --- | --- | --- |"]
    for label, fn in rows:
        cells = [_fmt(fn(src[m])) if src[m] else NA for m in ALL_MODELS]
        lines.append(f"| {label} | {cells[0]} | {cells[1]} | {cells[2]} |")
    lines.append("")
    lines.append("YOLO-Seg's column is obtained by rasterising its predicted instance "
                 "masks into a semantic map; see the caveat below.")
    return "\n".join(lines)


def detection_table(data: dict) -> str:
    inst = _get(data["metrics"].get("yolo_seg"), "instance_metrics", default={})
    src = {m: _semantic_source(data, m) for m in ALL_MODELS}
    lines = ["| Metric | U-Net | SegFormer | YOLO-Seg |",
             "| --- | --- | --- | --- |"]
    lines.append(f"| Precision (pixel, macro) | "
                 f"{_fmt(_get(src['unet'], 'summary', 'mean_precision'))} | "
                 f"{_fmt(_get(src['segformer'], 'summary', 'mean_precision'))} | "
                 f"{_fmt(_get(src['yolo_seg'], 'summary', 'mean_precision'))} |")
    lines.append(f"| Recall (pixel, macro) | "
                 f"{_fmt(_get(src['unet'], 'summary', 'mean_recall'))} | "
                 f"{_fmt(_get(src['segformer'], 'summary', 'mean_recall'))} | "
                 f"{_fmt(_get(src['yolo_seg'], 'summary', 'mean_recall'))} |")
    lines.append(f"| Precision (instance) | {NA} | {NA} | "
                 f"{_fmt(inst.get('mask_precision'))} |")
    lines.append(f"| Recall (instance) | {NA} | {NA} | "
                 f"{_fmt(inst.get('mask_recall'))} |")
    lines.append(f"| mAP@50 (mask) | {NA} | {NA} | {_fmt(inst.get('mask_mAP50'))} |")
    lines.append(f"| mAP@50:95 (mask) | {NA} | {NA} | {_fmt(inst.get('mask_mAP50_95'))} |")
    lines.append(f"| mAP@50 (box) | {NA} | {NA} | {_fmt(inst.get('box_mAP50'))} |")
    lines.append(f"| mAP@50:95 (box) | {NA} | {NA} | {_fmt(inst.get('box_mAP50_95'))} |")
    lines.append("")
    lines.append("mAP is undefined for U-Net and SegFormer: they emit no instances and "
                 "no detection scores to rank, so there is nothing to average precision "
                 "over. The cells are N/A, not zero.")
    return "\n".join(lines)


def computational_table(data: dict) -> str:
    b = data["benchmark"] or {}
    lines = ["| Model | Parameters | Model Size (MB) | Inference Time (ms) | FPS | Peak GPU Mem (MB) |",
             "| --- | --- | --- | --- | --- | --- |"]
    for m in ALL_MODELS:
        r = b.get(m)
        if not r:
            lines.append(f"| {PRETTY[m]} | {NA} | {NA} | {NA} | {NA} | {NA} |")
            continue
        params = r.get("total_parameters")
        size = r.get("model_size_mb", r.get("parameter_size_mb"))
        lines.append(
            f"| {PRETTY[m]} | {params:,} | {_fmt(size, 2)} | "
            f"{_fmt(r.get('latency_ms_median'), 2)} | {_fmt(r.get('fps'), 1)} | "
            f"{_fmt(r.get('peak_gpu_memory_mb'), 1)} |")
    lines.append("")
    res = {m: _get(b.get(m), "input_size") for m in ALL_MODELS if b.get(m)}
    if res:
        lines.append("Measured at each model's native inference resolution: "
                     + ", ".join(f"{PRETTY[m]} {v[0]}x{v[1]}" for m, v in res.items())
                     + ". YOLO-Seg's latency includes NMS and mask assembly.")
    return "\n".join(lines)


def per_class_table(data: dict, class_ids: list[int], title: str) -> str:
    src = {m: _semantic_source(data, m) for m in ALL_MODELS}
    lines = [f"**{title}**", "",
             "| Class (original id) | Metric | U-Net | SegFormer | YOLO-Seg |",
             "| --- | --- | --- | --- | --- |"]
    for cid in class_ids:
        name = ID_TO_NAME[cid]
        for metric in ("iou", "dice", "precision", "recall"):
            cells = []
            for m in ALL_MODELS:
                s = src[m]
                v = _get(s, "per_class", name, metric)
                cells.append(_fmt(v))
            lines.append(f"| {name} ({cid}) | {metric.capitalize()} | "
                         f"{cells[0]} | {cells[1]} | {cells[2]} |")
    return "\n".join(lines)


def group_table(data: dict, group: str, title: str) -> str:
    src = {m: _semantic_source(data, m) for m in ALL_MODELS}
    inst = _get(data["metrics"].get("yolo_seg"), "instance_metrics", default={})
    lines = [f"**{title}**", "",
             "| Metric | U-Net | SegFormer | YOLO-Seg |", "| --- | --- | --- | --- |"]
    for metric in ("iou", "dice", "precision", "recall"):
        cells = [_fmt(_get(src[m], group, "aggregated", metric)) for m in ALL_MODELS]
        lines.append(f"| {metric.capitalize()} (pixel) | {cells[0]} | {cells[1]} | {cells[2]} |")

    ap = inst.get("per_class_mask_ap50", {})
    names = ({ID_TO_NAME[c] for c in BLEACHING_CLASS_IDS} if group == "bleaching"
             else {"algae covered substrate"})
    vals = [v for k, v in ap.items() if k in names]
    lines.append(f"| Mask AP@50 (instance) | {NA} | {NA} | "
                 f"{_fmt(np.mean(vals)) if vals else NA} |")
    return "\n".join(lines)


def statistics_section(data: dict) -> str:
    st = data["statistics"]
    if not st:
        return ("No paired-bootstrap comparison found "
                "(`outputs/metrics/statistical_comparison.json` missing).")
    lines = ["| Comparison | Metric | Difference | 95% CI | Resolvable at 95%? |",
             "| --- | --- | --- | --- | --- |"]
    for pair, d in st.items():
        if not isinstance(d, dict) or "error" in d:
            continue
        for metric, r in d.items():
            if not isinstance(r, dict):
                continue
            a, b = pair.split("_vs_")
            lines.append(
                f"| {PRETTY.get(a, a)} - {PRETTY.get(b, b)} | {metric} | "
                f"{_fmt(r['diff'])} | [{_fmt(r['ci_low'])}, {_fmt(r['ci_high'])}] | "
                f"{'yes' if r['significant_at_95'] else 'no - treat as a tie'} |")
    return "\n".join(lines)


# --------------------------------------------------------------------------- #
# Conclusion
# --------------------------------------------------------------------------- #
def _rank(data: dict, getter, models=ALL_MODELS, higher_is_better=True):
    vals = {}
    for m in models:
        s = _semantic_source(data, m)
        v = getter(s) if s else None
        try:
            v = float(v)
        except (TypeError, ValueError):
            continue
        if np.isfinite(v):
            vals[m] = v
    if not vals:
        return None, vals
    best = max(vals, key=vals.get) if higher_is_better else min(vals, key=vals.get)
    return best, vals


def _tie_note(data: dict, a: str, b: str, metric: str = "mean_iou") -> str:
    st = _get(data["statistics"], f"{a}_vs_{b}", metric) or \
         _get(data["statistics"], f"{b}_vs_{a}", metric)
    if not st:
        return ""
    if not st.get("significant_at_95"):
        return (f" The {PRETTY[a]}-{PRETTY[b]} gap on {metric} has a 95% CI of "
                f"[{_fmt(st['ci_low'])}, {_fmt(st['ci_high'])}], which contains zero: "
                "on this test set the difference is not resolvable, so the two should "
                "be treated as tied on that metric.")
    return (f" The gap is statistically resolvable (95% CI "
            f"[{_fmt(st['ci_low'])}, {_fmt(st['ci_high'])}], excludes zero).")


def conclusion(data: dict) -> str:
    trained = [m for m in ALL_MODELS if data["metrics"].get(m)]
    missing = [m for m in ALL_MODELS if m not in trained]
    out: list[str] = []

    if not trained:
        return ("## Conclusion\n\nNo evaluation results are present in "
                "`outputs/metrics/`, so no model can be compared or recommended "
                "yet. Train the models and run `python -m src.evaluate` first. "
                "This section is generated strictly from measured results and is "
                "deliberately left empty rather than populated with expectations.")
    if missing:
        out.append(f"> Incomplete benchmark: no results for "
                   f"{', '.join(PRETTY[m] for m in missing)}. Every statement below "
                   f"is restricted to {', '.join(PRETTY[m] for m in trained)}.\n")

    best_miou, miou_vals = _rank(data, lambda s: _get(s, "summary", "mean_iou"))
    best_dice, _ = _rank(data, lambda s: _get(s, "summary", "mean_dice"))
    best_algae, algae_vals = _rank(data, lambda s: _get(s, "algae", "aggregated", "iou"))
    best_bleach, bleach_vals = _rank(
        data, lambda s: _get(s, "bleaching", "aggregated", "iou"))
    best_bound, bound_vals = _rank(
        data, lambda s: _get(s, "boundary", "mean_boundary_iou"))

    b = data["benchmark"] or {}
    fps = {m: _get(b.get(m), "fps") for m in ALL_MODELS if b.get(m)}
    fps = {k: float(v) for k, v in fps.items() if v}
    params = {m: _get(b.get(m), "total_parameters") for m in ALL_MODELS if b.get(m)}
    params = {k: int(v) for k, v in params.items() if v}

    out.append("### 1. Best semantic segmentation performance\n")
    if best_miou:
        ranking = ", ".join(f"{PRETTY[m]} {v:.4f}" for m, v in
                            sorted(miou_vals.items(), key=lambda kv: -kv[1]))
        out.append(f"{PRETTY[best_miou]} achieved the highest test mIoU. "
                   f"Measured mIoU: {ranking}.")
        semantic_pair = [m for m in ("unet", "segformer") if m in miou_vals]
        if len(semantic_pair) == 2:
            out.append(_tie_note(data, *semantic_pair).strip())
    else:
        out.append("Not measured.")

    out.append("\n### 2. Best on algae\n")
    out.append(f"{PRETTY[best_algae]} (algae IoU "
               f"{', '.join(f'{PRETTY[m]} {v:.4f}' for m, v in sorted(algae_vals.items(), key=lambda kv: -kv[1]))})."
               if best_algae else "Not measured.")

    out.append("\n### 3. Best on bleaching\n")
    out.append(f"{PRETTY[best_bleach]} on the aggregated bleaching group "
               f"({', '.join(f'{PRETTY[m]} {v:.4f}' for m, v in sorted(bleach_vals.items(), key=lambda kv: -kv[1]))}). "
               "Per-subclass numbers on the original labels are in the bleaching table."
               if best_bleach else "Not measured.")

    out.append("\n### 4. Best boundaries\n")
    out.append(f"{PRETTY[best_bound]} on mean Boundary IoU "
               f"({', '.join(f'{PRETTY[m]} {v:.4f}' for m, v in sorted(bound_vals.items(), key=lambda kv: -kv[1]))})."
               if best_bound else "Not measured (run evaluate.py without --no-boundary).")

    out.append("\n### 5. Fastest model\n")
    if fps:
        out.append(", ".join(f"{PRETTY[m]} {v:.1f} FPS" for m, v in
                             sorted(fps.items(), key=lambda kv: -kv[1]))
                   + f". Fastest: {PRETTY[max(fps, key=fps.get)]}.")
    else:
        out.append("Not measured (run `python -m src.benchmark`).")

    out.append("\n### 6. Lowest computational cost\n")
    if params:
        out.append(", ".join(f"{PRETTY[m]} {v:,} parameters" for m, v in
                             sorted(params.items(), key=lambda kv: kv[1]))
                   + f". Smallest: {PRETTY[min(params, key=params.get)]}.")
    else:
        out.append("Not measured.")

    out.append("\n### 7-9. Architecture trade-offs\n")
    out.append(_tradeoffs(data, miou_vals, fps, params))

    out.append("\n### 10. Recommendation\n")
    out.append(_recommendation(data, miou_vals, algae_vals, bleach_vals, fps, params))

    out.append("\n### Practical vs statistical significance\n")
    out.append(_practical_significance(data, miou_vals))
    return "## Final scientific conclusion\n\n" + "\n".join(out)


def _tradeoffs(data: dict, miou_vals, fps, params) -> str:
    lines = []
    conv = data["conversion"]
    for m in ALL_MODELS:
        s = _semantic_source(data, m)
        if s is None:
            lines.append(f"**{PRETTY[m]}** - not evaluated.\n")
            continue
        miou = _fmt(_get(s, "summary", "mean_iou"))
        rec = _fmt(_get(s, "summary", "mean_recall"))
        prec = _fmt(_get(s, "summary", "mean_precision"))
        speed = f"{fps[m]:.1f} FPS" if m in fps else "speed not measured"
        size = f"{params[m]:,} parameters" if m in params else "size not measured"
        if m == "unet":
            lines.append(
                f"**U-Net (ResNet50)** - mIoU {miou}, macro precision {prec}, recall "
                f"{rec}, {size}, {speed}. Advantages: a mature, easily trained CNN "
                "whose skip connections carry full-resolution detail straight to the "
                "decoder, and an ImageNet encoder that transfers well to a small "
                "dataset. Disadvantages: a limited receptive field means class "
                "decisions rest on local texture and colour, which is exactly what is "
                "ambiguous underwater, and it is the heaviest of the three in "
                "parameters.\n")
        elif m == "segformer":
            lines.append(
                f"**SegFormer-B0** - mIoU {miou}, macro precision {prec}, recall "
                f"{rec}, {size}, {speed}. Advantages: global self-attention gives it "
                "scene-level context that helps separate visually similar benthic "
                "classes, and the hierarchical MiT encoder delivers this at a very "
                "small parameter count. Disadvantages: it decodes at stride 4 and is "
                "upsampled, so fine boundaries and thin structures can be blurred, and "
                "transformers are typically more data-hungry than CNNs.\n")
        else:
            note = ""
            if conv:
                note = (f" Its ceiling is capped by the annotation conversion itself, "
                        f"which reproduces the semantic ground truth at only "
                        f"{conv['mean_weighted_class_iou']:.3f} weighted class IoU "
                        f"({conv['mean_pixel_agreement']:.3f} pixel agreement).")
            unclaimed = _get(data["metrics"].get("yolo_seg"),
                             "semantic_from_instances", "mean_unclaimed_pixel_fraction")
            unc = (f" On average {100 * float(unclaimed):.1f}% of labelled pixels are "
                   "covered by no detection at all and therefore count as errors in "
                   "the pixel comparison." if unclaimed is not None else "")
            lines.append(
                f"**YOLO-Seg** - rasterised mIoU {miou}, {size}, {speed}. Advantages: "
                "it is the only model that separates individual objects, gives a "
                "confidence per instance and supports counting; it is also built for "
                "real-time inference. Disadvantages: CoralScapes has no instance "
                "annotations, so its targets come from a connected-component heuristic "
                "that is not meaningful for the amorphous 'stuff' classes, and an "
                "instance model does not produce an exhaustive labelling."
                + note + unc + "\n")
    return "\n".join(lines)


def _recommendation(data: dict, miou_vals, algae_vals, bleach_vals, fps, params) -> str:
    if not miou_vals:
        return "Insufficient measurements to recommend a model."
    best = max(miou_vals, key=miou_vals.get)
    parts = [
        f"**Best segmentation model:** {PRETTY[best]} (highest measured mIoU "
        f"{miou_vals[best]:.4f}).",
    ]
    if data["metrics"].get("yolo_seg"):
        inst = _get(data["metrics"]["yolo_seg"], "instance_metrics", default={})
        parts.append(
            f"**Best localisation / instance model:** YOLO-Seg by default - it is the "
            f"only candidate that produces instances (mask mAP@50 "
            f"{_fmt(inst.get('mask_mAP50'))}, mAP@50:95 {_fmt(inst.get('mask_mAP50_95'))}). "
            "This is a statement about capability, not about superiority: the other "
            "two cannot be scored on this task at all.")
    else:
        parts.append("**Best localisation / instance model:** not determined "
                     "(YOLO-Seg not evaluated).")

    if params and fps:
        eff = {m: miou_vals[m] / (params[m] / 1e6) for m in miou_vals if m in params}
        if eff:
            light = max(eff, key=eff.get)
            parts.append(
                f"**Best lightweight model:** {PRETTY[light]}, on mIoU per million "
                f"parameters ("
                + ", ".join(f"{PRETTY[m]} {v:.4f}" for m, v in
                            sorted(eff.items(), key=lambda kv: -kv[1])) + ").")
    parts.append(
        f"**Overall recommendation:** for producing exhaustive benthic cover maps - "
        f"the task CoralScapes actually annotates - {PRETTY[best]} is the model to "
        "deploy, on the measured evidence above. Choose YOLO-Seg instead only when the "
        "application genuinely needs discrete objects (counting fish, urchins or "
        "individual colonies), accepting the conversion caveats. The choice should "
        "also weigh the speed and size figures in the computational table, since on "
        "this hardware they differ by more than the accuracy gaps do.")
    return "\n\n".join(parts)


def _practical_significance(data: dict, miou_vals) -> str:
    if len(miou_vals) < 2:
        return "Fewer than two models evaluated; no difference to assess."
    ordered = sorted(miou_vals.items(), key=lambda kv: -kv[1])
    (m1, v1), (m2, v2) = ordered[0], ordered[1]
    gap = v1 - v2
    st = (_get(data["statistics"], f"{m1}_vs_{m2}", "mean_iou")
          or _get(data["statistics"], f"{m2}_vs_{m1}", "mean_iou"))
    txt = (f"The top two models differ by {gap:.4f} mIoU "
           f"({PRETTY[m1]} {v1:.4f} vs {PRETTY[m2]} {v2:.4f}). ")
    if st:
        if st["significant_at_95"]:
            txt += (f"The paired bootstrap resolves this difference (95% CI "
                    f"[{_fmt(st['ci_low'])}, {_fmt(st['ci_high'])}]). ")
        else:
            txt += (f"The paired bootstrap does NOT resolve it (95% CI "
                    f"[{_fmt(st['ci_low'])}, {_fmt(st['ci_high'])}] contains zero), so "
                    "the two models should be reported as statistically tied. ")
    if abs(gap) < 0.02:
        txt += ("A gap of this size is also below what matters practically: for "
                "benthic cover estimation it is small next to the disagreement "
                "between human annotators, so the decision should be made on speed, "
                "memory and maintenance cost rather than on accuracy.")
    else:
        txt += ("Whether this is practically significant depends on use: for coarse "
                "percentage-cover reporting the operational difference is modest, "
                "while for per-class monitoring of rare bleaching classes the "
                "per-class tables matter more than the mean.")
    return txt


# --------------------------------------------------------------------------- #
def build(save: bool = True) -> str:
    from .config import ALGAE_CLASS_IDS

    data = load_all()
    parts = [
        "# CoralScapes segmentation benchmark - final comparison",
        "",
        "All numbers below are read directly from the evaluation artefacts in "
        "`outputs/metrics/`. Cells marked N/A were not measured or are not "
        "applicable to that architecture; none are estimated.",
        "",
        "## Segmentation quality (official test split)", "",
        segmentation_quality_table(data), "",
        "## Detection / instance performance", "",
        detection_table(data), "",
        "## Computational benchmark", "",
        computational_table(data), "",
        "## Algae-specific analysis", "",
        group_table(data, "algae", "Algae (aggregated group)"), "",
        per_class_table(data, ALGAE_CLASS_IDS, "Algae - original classes"), "",
        "## Bleaching-specific analysis", "",
        group_table(data, "bleaching", "Bleaching (aggregated group)"), "",
        per_class_table(data, BLEACHING_CLASS_IDS,
                        "Bleaching - original classes, unmodified labels"), "",
        "Aggregation rule: the four official bleached-coral classes are pooled "
        "one-vs-rest and a confusion between two bleached subclasses counts as "
        "correct. The ground truth is never modified; the per-class rows above use "
        "the original labels.", "",
        "## Statistical reliability", "",
        statistics_section(data), "",
        "## Final conclusion", "",
        conclusion(data), "",
    ]
    md = "\n".join(parts)
    if save:
        COMPARISON_DIR.mkdir(parents=True, exist_ok=True)
        (COMPARISON_DIR / "final_comparison.md").write_text(md, encoding="utf-8")
        with open(COMPARISON_DIR / "final_comparison_data.json", "w",
                  encoding="utf-8") as fh:
            json.dump(data, fh, indent=2, default=float)
        print(f"wrote {COMPARISON_DIR / 'final_comparison.md'}")
    return md


def main() -> None:
    ap = argparse.ArgumentParser(description="Build the final comparison report")
    ap.add_argument("--print", action="store_true")
    args = ap.parse_args()
    md = build()
    if args.print:
        print(md)


if __name__ == "__main__":
    main()

"""Pre-training sanity checks (spec section 31).

These are deliberately cheap and run before any long job: they catch the
mistakes that otherwise only show up after hours of training -- a mask that
got normalised, a channel/class mismatch, a model whose output resolution does
not match the labels, or a loss that cannot actually reduce.
"""
from __future__ import annotations

import numpy as np
import torch

from .config import CFG, ID_TO_NAME, IGNORE_INDEX, NUM_CLASSES, Config, get_device
from .models import logits_to_prediction


class SanityCheckError(AssertionError):
    """Raised when a pre-training invariant is violated."""


def check_batch(images: torch.Tensor, masks: torch.Tensor,
                cfg: Config = CFG) -> dict:
    """Validate the shapes, dtypes and value ranges of one training batch."""
    report = {}
    if images.ndim != 4 or images.shape[1] != 3:
        raise SanityCheckError(f"expected images (B,3,H,W), got {tuple(images.shape)}")
    if masks.ndim != 3:
        raise SanityCheckError(f"expected masks (B,H,W), got {tuple(masks.shape)}")
    if images.shape[0] != masks.shape[0] or images.shape[-2:] != masks.shape[-2:]:
        raise SanityCheckError(
            f"image/mask shape mismatch: {tuple(images.shape)} vs {tuple(masks.shape)}")
    if masks.dtype not in (torch.int64, torch.int32, torch.uint8):
        raise SanityCheckError(f"masks must be integer class ids, got {masks.dtype}")

    mn, mx = int(masks.min()), int(masks.max())
    if mn < 0 or mx >= NUM_CLASSES:
        raise SanityCheckError(
            f"mask ids outside [0,{NUM_CLASSES - 1}]: found [{mn},{mx}]")

    unique = torch.unique(masks)
    # a normalised mask would collapse to {0,1} floats or lose its id structure
    if masks.dtype.is_floating_point:
        raise SanityCheckError("mask appears to have been normalised to float")

    report["image_shape"] = tuple(images.shape)
    report["mask_shape"] = tuple(masks.shape)
    report["image_dtype"] = str(images.dtype)
    report["mask_dtype"] = str(masks.dtype)
    report["image_range"] = (round(float(images.min()), 3), round(float(images.max()), 3))
    report["mask_id_range"] = (mn, mx)
    report["unique_ids_in_batch"] = [int(u) for u in unique]
    report["class_names_in_batch"] = [ID_TO_NAME[int(u)] for u in unique]
    report["valid_pixel_fraction"] = round(
        float((masks != IGNORE_INDEX).float().mean()), 4)

    print("  batch image shape      :", report["image_shape"], report["image_dtype"])
    print("  batch mask  shape      :", report["mask_shape"], report["mask_dtype"])
    print("  image value range      :", report["image_range"], "(ImageNet-normalised)")
    print("  mask  id range         :", report["mask_id_range"],
          f"(legal: 0..{NUM_CLASSES - 1})")
    print("  labelled pixel fraction:", report["valid_pixel_fraction"])
    print("  classes present        :",
          ", ".join(f"{i}={ID_TO_NAME[i]}" for i in report["unique_ids_in_batch"][:10]),
          "..." if len(report["unique_ids_in_batch"]) > 10 else "")
    return report


def check_forward(model, images: torch.Tensor, cfg: Config = CFG) -> dict:
    """Forward pass: output must be (B, NUM_CLASSES, H, W) at input resolution."""
    device = get_device(cfg)
    model.to(device).eval()
    with torch.no_grad():
        logits = model(images.to(device))
    expected = (images.shape[0], NUM_CLASSES, images.shape[2], images.shape[3])
    if tuple(logits.shape) != expected:
        raise SanityCheckError(
            f"output shape {tuple(logits.shape)} != expected {expected}")

    pred = logits_to_prediction(logits)
    if int((pred == IGNORE_INDEX).sum()) != 0:
        raise SanityCheckError("model predicted the ignore/void class")

    print("  forward output shape   :", tuple(logits.shape), "-> matches (B,C,H,W)")
    print("  prediction id range    :", (int(pred.min()), int(pred.max())),
          "(void class correctly excluded)")
    return {"logits_shape": tuple(logits.shape),
            "prediction_range": (int(pred.min()), int(pred.max()))}


def check_optimization_step(model, images, masks, criterion,
                            cfg: Config = CFG, steps: int = 3) -> dict:
    """Overfit a single batch for a few steps; the loss must go down.

    This is the cheapest end-to-end proof that images, labels, loss and
    gradients are wired together correctly.
    """
    device = get_device(cfg)
    model.to(device).train()
    images, masks = images.to(device), masks.to(device)
    opt = torch.optim.AdamW(model.parameters(), lr=1e-4)

    losses = []
    for _ in range(steps):
        opt.zero_grad(set_to_none=True)
        logits = model(images)
        loss = criterion(logits, masks)
        loss.backward()
        grad_norm = torch.nn.utils.clip_grad_norm_(model.parameters(), 1e9)
        opt.step()
        losses.append(float(loss.detach()))

    if not np.isfinite(losses).all():
        raise SanityCheckError(f"non-finite loss during optimisation: {losses}")
    if losses[-1] >= losses[0]:
        print(f"  WARNING: loss did not decrease over {steps} steps: "
              f"{losses[0]:.4f} -> {losses[-1]:.4f}")
    print(f"  {steps} optimisation steps : loss {losses[0]:.4f} -> {losses[-1]:.4f}, "
          f"grad norm {float(grad_norm):.3f}")
    return {"losses": losses, "grad_norm": float(grad_norm)}


def sanity_check_semantic(model, loader, criterion, cfg: Config = CFG,
                          name: str = "model") -> dict:
    """Run the full pre-training checklist for a semantic model."""
    print(f"\n=== sanity checks: {name} ===")
    images, masks = next(iter(loader))
    report = {"batch": check_batch(images, masks, cfg)}
    report["forward"] = check_forward(model, images, cfg)
    report["optimization"] = check_optimization_step(model, images, masks,
                                                     criterion, cfg)
    print(f"=== {name}: all sanity checks passed ===\n")
    return report


def verify_label_mapping(dataset, n_samples: int = 5) -> dict:
    """Confirm the ids in the masks really are the official CoralScapes ids.

    Guards against a silently remapped label space (e.g. contiguous 0..N-1
    indices), which would make every per-class metric refer to the wrong class.
    """
    print("verifying label mapping against classes.json ...")
    seen: set[int] = set()
    for i in range(min(n_samples, len(dataset))):
        _, mask = dataset.load_raw(i)
        seen.update(int(u) for u in np.unique(mask))
    unknown = sorted(seen - set(ID_TO_NAME))
    if unknown:
        raise SanityCheckError(f"mask contains ids absent from classes.json: {unknown}")
    print(f"  {len(seen)} distinct ids seen in {n_samples} masks, all present in "
          f"classes.json, e.g. " +
          ", ".join(f"{i}->{ID_TO_NAME[i]}" for i in sorted(seen)[:6]))
    return {"ids_seen": sorted(seen), "unknown_ids": unknown}

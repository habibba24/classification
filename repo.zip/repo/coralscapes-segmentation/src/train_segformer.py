"""Fine-tune SegFormer-B0 (nvidia/mit-b0) on CoralScapes.

    python -m src.train_segformer [--epochs N] [--batch-size N] [--sanity-only]

The pretrained classification head is discarded and rebuilt at the CoralScapes
class count; the pretrained label space is never reused. Training uses the same
loss, schedule, resolution and seed as the U-Net run so that the comparison
isolates the architecture.
"""
from __future__ import annotations

import argparse

from .config import (CFG, CHECKPOINT_DIR, Config, OUTPUT_DIR,
                     record_environment, set_seed)
from .dataset import build_dataloaders
from .engine import fit
from .losses import build_loss, load_class_weights
from .models import build_model, count_parameters
from .sanity import sanity_check_semantic, verify_label_mapping


def parse_args(argv=None) -> argparse.Namespace:
    p = argparse.ArgumentParser(description="Fine-tune SegFormer on CoralScapes")
    p.add_argument("--epochs", type=int, default=CFG.epochs)
    p.add_argument("--batch-size", type=int, default=CFG.batch_size)
    p.add_argument("--image-size", type=int, nargs=2, default=list(CFG.image_size),
                   metavar=("H", "W"))
    p.add_argument("--lr", type=float, default=CFG.learning_rate)
    p.add_argument("--encoder-lr", type=float, default=CFG.encoder_learning_rate)
    p.add_argument("--weight-decay", type=float, default=CFG.weight_decay)
    p.add_argument("--checkpoint", type=str, default=CFG.segformer_checkpoint)
    p.add_argument("--loss", type=str, default=CFG.loss_name)
    p.add_argument("--no-class-weights", action="store_true")
    p.add_argument("--freeze-epochs", type=int, default=CFG.freeze_encoder_epochs)
    p.add_argument("--num-workers", type=int, default=CFG.num_workers)
    p.add_argument("--seed", type=int, default=CFG.seed)
    p.add_argument("--no-amp", action="store_true")
    p.add_argument("--sanity-only", action="store_true")
    return p.parse_args(argv)


def build_config(args) -> Config:
    return Config(
        seed=args.seed,
        image_size=tuple(args.image_size),
        batch_size=args.batch_size,
        num_workers=args.num_workers,
        epochs=args.epochs,
        learning_rate=args.lr,
        encoder_learning_rate=args.encoder_lr,
        weight_decay=args.weight_decay,
        freeze_encoder_epochs=args.freeze_epochs,
        segformer_checkpoint=args.checkpoint,
        loss_name=args.loss,
        use_class_weights=not args.no_class_weights,
        amp=not args.no_amp,
    )


def main(argv=None) -> None:
    args = parse_args(argv)
    cfg = build_config(args)
    set_seed(cfg.seed)
    record_environment(cfg, filename="run_environment_segformer.json")

    model = build_model("segformer", cfg)
    print("SegFormer parameters:", count_parameters(model))

    class_weights = None
    if cfg.use_class_weights:
        stats_path = OUTPUT_DIR / "metrics" / "dataset_stats.json"
        if stats_path.exists():
            class_weights = load_class_weights(stats_path)
            print("loaded sqrt-inverse-frequency class weights from dataset_stats.json")
        else:
            print("dataset_stats.json not found -- run `python -m src.explore` first; "
                  "continuing unweighted")
    criterion = build_loss(cfg.loss_name, class_weights, cfg.dice_weight)

    loaders = build_dataloaders(cfg, splits=("train", "val"))
    print(f"train batches: {len(loaders['train'])}, val batches: {len(loaders['val'])}")

    verify_label_mapping(loaders["train"].dataset)
    sanity_check_semantic(model, loaders["train"], criterion, cfg, name="SegFormer")
    if args.sanity_only:
        print("sanity checks passed; exiting before training (--sanity-only)")
        return

    fit(model, loaders, criterion, cfg, model_name="segformer",
        checkpoint_path=CHECKPOINT_DIR / "best_segformer.pth",
        history_path=OUTPUT_DIR / "segformer" / "history.json")


if __name__ == "__main__":
    main()

"""Train a YOLO-Seg instance-segmentation model on the converted CoralScapes.

    python -m src.train_yolo [--epochs N] [--imgsz 640] [--model yolo11n-seg.pt]
                             [--smoke-test] [--sanity-only]

Prerequisites (the script refuses to start without them):
  1. `python -m src.annotation_conversion`  -- writes data/yolo_seg/
  2. `python -m src.verify_yolo --n 20`     -- visual + numeric verification

The loss is Ultralytics' own segmentation loss (box + cls + DFL + mask). It is
left untouched deliberately: it is tightly coupled to the assigner and mask
prototypes, and replacing it would confound "YOLO-Seg vs the semantic models"
with "our custom loss vs theirs".

Validation uses the official CoralScapes val split; the test split is only
touched by src/evaluate.py, once.
"""
from __future__ import annotations

import argparse
import json
import shutil
import time
from pathlib import Path

from .config import (CFG, CHECKPOINT_DIR, OUTPUT_DIR, YOLO_DATA_DIR,
                     record_environment, set_seed)


def check_dataset_ready(out_root: Path) -> dict:
    """Fail early and loudly if the conversion or verification has not been run."""
    yaml_path = out_root / "coralscapes_yolo.yaml"
    mapping_path = out_root / "class_mapping.json"
    if not yaml_path.exists() or not mapping_path.exists():
        raise FileNotFoundError(
            f"{yaml_path} not found.\n"
            "Run the conversion first:  python -m src.annotation_conversion")

    for split in ("train", "val"):
        n_img = len(list((out_root / "images" / split).glob("*.jpg")))
        n_lbl = len(list((out_root / "labels" / split).glob("*.txt")))
        if n_img == 0 or n_lbl == 0:
            raise FileNotFoundError(f"split {split!r} is empty ({n_img} images, "
                                    f"{n_lbl} labels); re-run the conversion")
        if n_img != n_lbl:
            raise RuntimeError(f"split {split!r}: {n_img} images but {n_lbl} labels")

    verification = OUTPUT_DIR / "metrics" / "yolo_conversion_verification.json"
    if not verification.exists():
        raise FileNotFoundError(
            "the converted annotations have not been visually verified.\n"
            "Run:  python -m src.verify_yolo --n 20\n"
            "and inspect outputs/visualizations/yolo_annotation_verification/ "
            "before training (project rule: do not train on unverified polygons).")

    with open(mapping_path, "r", encoding="utf-8") as fh:
        mapping = json.load(fh)
    with open(verification, "r", encoding="utf-8") as fh:
        ver = json.load(fh)
    print(f"YOLO dataset ready: {mapping['n_yolo_classes']} classes, "
          f"policy={mapping['policy']}")
    print(f"conversion fidelity (rasterised polygons vs semantic GT): "
          f"pixel agreement {ver['mean_pixel_agreement']:.3f}, "
          f"weighted class IoU {ver['mean_weighted_class_iou']:.3f}")
    return mapping


def main(argv=None) -> None:
    ap = argparse.ArgumentParser(description="Train YOLO-Seg on CoralScapes")
    ap.add_argument("--model", default=CFG.yolo_checkpoint,
                    help="pretrained Ultralytics segmentation checkpoint")
    ap.add_argument("--epochs", type=int, default=CFG.yolo_epochs)
    ap.add_argument("--imgsz", type=int, default=CFG.yolo_image_size)
    ap.add_argument("--batch", type=int, default=8)
    ap.add_argument("--workers", type=int, default=CFG.num_workers)
    ap.add_argument("--seed", type=int, default=CFG.seed)
    ap.add_argument("--patience", type=int, default=10)
    ap.add_argument("--device", default=0)
    ap.add_argument("--out-root", default=str(YOLO_DATA_DIR))
    ap.add_argument("--project", default=str(OUTPUT_DIR / "yolo_seg"))
    ap.add_argument("--name", default="train")
    ap.add_argument("--smoke-test", action="store_true",
                    help="2 epochs on a few batches, to prove the pipeline runs")
    ap.add_argument("--sanity-only", action="store_true",
                    help="check the dataset and model load, then exit")
    args = ap.parse_args(argv)

    from ultralytics import YOLO

    set_seed(args.seed)
    record_environment(filename="run_environment_yolo_seg.json")
    out_root = Path(args.out_root)
    check_dataset_ready(out_root)

    model = YOLO(args.model)
    print(f"loaded pretrained checkpoint: {args.model}")

    if args.sanity_only:
        print("dataset and checkpoint load correctly; exiting (--sanity-only)")
        return

    epochs = 2 if args.smoke_test else args.epochs
    fraction = 0.03 if args.smoke_test else 1.0
    name = f"{args.name}_smoke" if args.smoke_test else args.name

    t0 = time.time()
    model.train(
        data=str(out_root / "coralscapes_yolo.yaml"),
        epochs=epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        workers=args.workers,
        seed=args.seed,
        device=args.device,
        patience=args.patience,          # early stopping on the val fitness
        project=args.project,
        name=name,
        exist_ok=True,
        pretrained=True,
        optimizer="AdamW",
        amp=True,
        fraction=fraction,
        plots=True,
        val=True,
    )
    train_time = time.time() - t0

    best = Path(args.project) / name / "weights" / "best.pt"
    if best.exists() and not args.smoke_test:
        CHECKPOINT_DIR.mkdir(parents=True, exist_ok=True)
        shutil.copy2(best, CHECKPOINT_DIR / "best_yolo_seg.pt")
        print(f"copied {best} -> {CHECKPOINT_DIR / 'best_yolo_seg.pt'}")

    meta = {"model": args.model, "epochs": epochs, "imgsz": args.imgsz,
            "batch": args.batch, "seed": args.seed, "smoke_test": args.smoke_test,
            "training_time_s": train_time, "run_dir": str(Path(args.project) / name)}
    meta_path = OUTPUT_DIR / "yolo_seg" / "training_meta.json"
    meta_path.parent.mkdir(parents=True, exist_ok=True)
    with open(meta_path, "w", encoding="utf-8") as fh:
        json.dump(meta, fh, indent=2)
    print(f"training finished in {train_time / 60:.1f} min; metadata -> {meta_path}")


if __name__ == "__main__":
    main()

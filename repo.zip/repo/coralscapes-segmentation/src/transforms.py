"""Synchronised image/mask augmentation pipelines.

Rules enforced here (see project spec sections 4 and 30):
  * every geometric op is applied identically to the image and to the mask;
  * masks are resampled with NEAREST only, so label ids are never blended;
  * photometric ops (brightness/contrast/colour) touch the image ONLY;
  * masks are never normalised -- they stay integer class ids.
"""
from __future__ import annotations

import albumentations as A
import numpy as np
from albumentations.pytorch import ToTensorV2

# ImageNet statistics -- both the ResNet50 U-Net encoder and the MiT/SegFormer
# backbone were pretrained with these.
IMAGENET_MEAN = (0.485, 0.456, 0.406)
IMAGENET_STD = (0.229, 0.224, 0.225)


def train_transform(height: int, width: int,
                    mean=IMAGENET_MEAN, std=IMAGENET_STD) -> A.Compose:
    """Augmentations for training.

    Deliberately conservative: underwater imagery already has a strong,
    depth-dependent colour cast, so aggressive hue/saturation shifts would
    create physically implausible scenes and hurt the bleaching classes
    (which are defined by being *pale*). Vertical flips are excluded because
    the transect imagery has a consistent gravity direction.
    """
    return A.Compose([
        A.RandomScale(scale_limit=(-0.25, 0.5), interpolation=1, p=0.7),
        A.PadIfNeeded(min_height=height, min_width=width,
                      border_mode=0, fill=0, fill_mask=0),
        A.RandomCrop(height=height, width=width),
        A.HorizontalFlip(p=0.5),
        A.Affine(rotate=(-12, 12), translate_percent=(-0.04, 0.04),
                 scale=(0.95, 1.05), interpolation=1, mask_interpolation=0,
                 border_mode=0, fill=0, fill_mask=0, p=0.4),
        A.RandomBrightnessContrast(brightness_limit=0.15, contrast_limit=0.15, p=0.5),
        A.HueSaturationValue(hue_shift_limit=6, sat_shift_limit=12,
                             val_shift_limit=8, p=0.3),
        A.Normalize(mean=mean, std=std),
        ToTensorV2(),
    ])


def eval_transform(height: int, width: int,
                   mean=IMAGENET_MEAN, std=IMAGENET_STD) -> A.Compose:
    """Deterministic resize used for validation and test.

    The mask is resized with NEAREST so that class ids survive intact.
    """
    return A.Compose([
        A.Resize(height=height, width=width, interpolation=1, mask_interpolation=0),
        A.Normalize(mean=mean, std=std),
        ToTensorV2(),
    ])


def denormalize(tensor, mean=IMAGENET_MEAN, std=IMAGENET_STD) -> np.ndarray:
    """CHW normalised tensor -> HWC uint8 image, for visualisation."""
    arr = tensor.detach().cpu().numpy().transpose(1, 2, 0)
    arr = arr * np.array(std) + np.array(mean)
    return (np.clip(arr, 0, 1) * 255).astype(np.uint8)

"""Visual verification of the semantic -> YOLO polygon conversion (spec section 9).

For each verified example it renders four panels:

    original image | ground-truth semantic mask | converted YOLO polygons |
    polygon overlay on the image

plus an agreement number: the IoU between the *rasterised polygons* and the
*original semantic mask*. That number is the honest ceiling for YOLO-Seg on
this dataset -- no YOLO model can score above what the annotation conversion
itself preserves -- so it is written to a JSON report as well as drawn.

    python -m src.verify_yolo --n 20

The pipeline is meant to be stopped here if the figures or the agreement
numbers look wrong, before any YOLO training is launched.
"""
from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
from PIL import Image
from tqdm import tqdm

from .config import ID_TO_COLOR, ID_TO_NAME, IGNORE_INDEX, OUTPUT_DIR, YOLO_DATA_DIR
from .annotation_conversion import load_mapping, rasterize_yolo_label
from .visualization import colorize_mask, legend_handles, overlay_mask

VERIFY_DIR = OUTPUT_DIR / "visualizations" / "yolo_annotation_verification"


def draw_polygons(image: np.ndarray, label_path: Path,
                  yolo_to_coral: dict[int, int], filled: bool = True,
                  alpha: float = 0.5, line_width: int = 2) -> np.ndarray:
    """Draw the YOLO polygons on a copy of the image, in the class palette."""
    import cv2

    h, w = image.shape[:2]
    canvas = image.copy()
    overlay = image.copy()
    lines = [l for l in Path(label_path).read_text(encoding="utf-8").splitlines()
             if l.strip()]
    for line in lines:
        parts = line.split()
        coral_id = yolo_to_coral[int(parts[0])]
        color = tuple(int(v) for v in ID_TO_COLOR[coral_id])
        pts = np.array(parts[1:], dtype=np.float64).reshape(-1, 2)
        pts[:, 0] *= w
        pts[:, 1] *= h
        pts = pts.astype(np.int32)
        if filled:
            cv2.fillPoly(overlay, [pts], color)
        cv2.polylines(canvas, [pts], True, color, line_width, lineType=cv2.LINE_AA)
    if filled:
        canvas = cv2.addWeighted(overlay, alpha, canvas, 1 - alpha, 0)
        for line in lines:                      # redraw outlines on top
            parts = line.split()
            coral_id = yolo_to_coral[int(parts[0])]
            color = tuple(int(v) for v in ID_TO_COLOR[coral_id])
            pts = np.array(parts[1:], dtype=np.float64).reshape(-1, 2)
            pts[:, 0] *= w
            pts[:, 1] *= h
            cv2.polylines(canvas, [pts.astype(np.int32)], True, color,
                          line_width, lineType=cv2.LINE_AA)
    return canvas


def conversion_agreement(semantic: np.ndarray, rasterized: np.ndarray) -> dict:
    """IoU/Dice between the original semantic mask and the rasterised polygons."""
    valid = semantic != IGNORE_INDEX
    ious, dices, weights = [], [], []
    for c in np.unique(semantic[valid]):
        g = (semantic == c) & valid
        p = (rasterized == c) & valid
        inter = float(np.logical_and(g, p).sum())
        union = float(np.logical_or(g, p).sum())
        if union == 0:
            continue
        ious.append(inter / union)
        dices.append(2 * inter / (g.sum() + p.sum()) if (g.sum() + p.sum()) else np.nan)
        weights.append(float(g.sum()))
    agree = float((semantic[valid] == rasterized[valid]).mean()) if valid.any() else np.nan
    return {
        "pixel_agreement": agree,
        "mean_class_iou": float(np.nanmean(ious)) if ious else float("nan"),
        "weighted_class_iou": (float(np.average(ious, weights=weights))
                               if ious else float("nan")),
        "mean_class_dice": float(np.nanmean(dices)) if dices else float("nan"),
        "n_classes": len(ious),
    }


def verify(n: int = 20, split: str = "train", out_root: Path = YOLO_DATA_DIR,
           save_dir: Path = VERIFY_DIR, seed: int = 42,
           prefer_classes: list[int] | None = None) -> dict:
    """Render `n` verification figures and compute conversion agreement."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    mapping = load_mapping(out_root)
    yolo_to_coral = {int(k): int(v) for k, v in mapping["yolo_index_to_coral_id"].items()}
    kinds = mapping["class_kind"]

    img_dir = out_root / "images" / split
    lbl_dir = out_root / "labels" / split
    stems = sorted(p.stem for p in lbl_dir.glob("*.txt"))
    if not stems:
        raise FileNotFoundError(f"no label files in {lbl_dir}; run the conversion first")

    # prefer images that actually contain the classes we care most about
    if prefer_classes:
        wanted = {c for c in prefer_classes}
        scored = []
        for s in stems:
            ids = {yolo_to_coral[int(l.split()[0])]
                   for l in (lbl_dir / f"{s}.txt").read_text().splitlines() if l.strip()}
            scored.append((len(ids & wanted), s))
        scored.sort(key=lambda t: -t[0])
        chosen = [s for _, s in scored[: max(n // 2, 1)]]
        rng = np.random.default_rng(seed)
        rest = [s for s in stems if s not in set(chosen)]
        chosen += list(rng.choice(rest, size=min(n - len(chosen), len(rest)),
                                  replace=False))
    else:
        rng = np.random.default_rng(seed)
        chosen = list(rng.choice(stems, size=min(n, len(stems)), replace=False))

    save_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for stem in tqdm(chosen, desc="verifying", unit="fig"):
        image = np.array(Image.open(img_dir / f"{stem}.jpg").convert("RGB"))
        h, w = image.shape[:2]
        semantic = _load_semantic_at(stem, split, (w, h))
        raster = rasterize_yolo_label(lbl_dir / f"{stem}.txt", h, w, yolo_to_coral)
        poly_img = draw_polygons(image, lbl_dir / f"{stem}.txt", yolo_to_coral)
        agree = conversion_agreement(semantic, raster)
        n_inst = len([l for l in (lbl_dir / f"{stem}.txt").read_text().splitlines()
                      if l.strip()])

        fig, axes = plt.subplots(1, 4, figsize=(23, 5.4))
        axes[0].imshow(image); axes[0].set_title("Original image")
        axes[1].imshow(colorize_mask(semantic))
        axes[1].set_title("Ground-truth semantic mask")
        axes[2].imshow(poly_img)
        axes[2].set_title(f"Converted YOLO polygons ({n_inst} instances)")
        axes[3].imshow(overlay_mask(image, raster))
        axes[3].set_title("Rasterised polygons over image")
        for ax in axes:
            ax.axis("off")

        present = sorted(set(np.unique(semantic).tolist()) - {IGNORE_INDEX})
        handles = legend_handles(present[:12])
        for hd, cid in zip(handles, present[:12]):
            hd.set_label(f"{cid}: {ID_TO_NAME[cid]} [{kinds.get(ID_TO_NAME[cid], '?')}]")
        fig.legend(handles=handles, loc="lower center", ncol=6, fontsize=8,
                   frameon=False, bbox_to_anchor=(0.5, -0.08))
        fig.suptitle(f"{stem}  |  polygon-vs-semantic pixel agreement "
                     f"{agree['pixel_agreement']:.3f}, "
                     f"weighted class IoU {agree['weighted_class_iou']:.3f}",
                     fontsize=12)
        fig.tight_layout()
        fig.savefig(save_dir / f"verify_{stem}.png", dpi=110, bbox_inches="tight")
        plt.close(fig)

        records.append({"stem": stem, "n_instances": n_inst, **agree})

    summary = {
        "split": split,
        "n_examples": len(records),
        "mean_pixel_agreement": float(np.mean([r["pixel_agreement"] for r in records])),
        "mean_weighted_class_iou": float(
            np.nanmean([r["weighted_class_iou"] for r in records])),
        "mean_instances_per_image": float(np.mean([r["n_instances"] for r in records])),
        "per_image": records,
        "note": ("pixel agreement / IoU here measure the ANNOTATION CONVERSION only "
                 "(rasterised polygons vs original semantic mask). They bound the "
                 "best possible YOLO-Seg score on this dataset."),
    }
    out_json = OUTPUT_DIR / "metrics" / "yolo_conversion_verification.json"
    out_json.parent.mkdir(parents=True, exist_ok=True)
    with open(out_json, "w", encoding="utf-8") as fh:
        json.dump(summary, fh, indent=2)

    print(f"\nwrote {len(records)} verification figures to {save_dir}")
    print(f"mean polygon-vs-semantic pixel agreement : "
          f"{summary['mean_pixel_agreement']:.4f}")
    print(f"mean weighted class IoU of the conversion: "
          f"{summary['mean_weighted_class_iou']:.4f}")
    print(f"mean instances per image                 : "
          f"{summary['mean_instances_per_image']:.1f}")
    print(f"report: {out_json}")
    return summary


def _load_semantic_at(stem: str, split: str, size_wh: tuple[int, int]) -> np.ndarray:
    """Original CoralScapes mask for `stem`, nearest-resized to the YOLO size."""
    import cv2

    from .config import DATA_ROOT, MASK_DIR_NAME, MASK_SUFFIX

    site = stem.split("_")[0]
    path = DATA_ROOT / MASK_DIR_NAME / split / site / f"{stem}{MASK_SUFFIX}"
    mask = np.array(Image.open(path))
    if mask.ndim == 3:
        mask = mask[..., 0]
    return cv2.resize(mask, size_wh, interpolation=cv2.INTER_NEAREST)


def main() -> None:
    from .config import ALGAE_CLASS_IDS, BLEACHING_CLASS_IDS

    ap = argparse.ArgumentParser(description="Visually verify the YOLO conversion")
    ap.add_argument("--n", type=int, default=20)
    ap.add_argument("--split", default="train")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out-root", default=str(YOLO_DATA_DIR))
    ap.add_argument("--any-classes", action="store_true",
                    help="sample uniformly instead of favouring algae/bleaching")
    args = ap.parse_args()

    prefer = None if args.any_classes else ALGAE_CLASS_IDS + BLEACHING_CLASS_IDS
    verify(n=args.n, split=args.split, out_root=Path(args.out_root), seed=args.seed,
           prefer_classes=prefer)


if __name__ == "__main__":
    main()

"""Colour mapping, overlays, legends and comparison figures.

Every mask rendered anywhere in this project goes through `colorize_mask`,
which uses the official CoralScapes palette from colors.json, so the same class
always has the same colour in every figure.
"""
from __future__ import annotations

from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from matplotlib.patches import Patch

from .config import ID_TO_COLOR, ID_TO_NAME, IGNORE_INDEX, NUM_CLASSES

# Lookup table: index = class id, value = RGB. Built once and reused.
PALETTE = np.zeros((256, 3), dtype=np.uint8)
for _cid, _rgb in ID_TO_COLOR.items():
    PALETTE[_cid] = _rgb


def colorize_mask(mask: np.ndarray) -> np.ndarray:
    """(H, W) class ids -> (H, W, 3) uint8 RGB using the official palette."""
    return PALETTE[np.asarray(mask).astype(np.uint8)]


def overlay_mask(image: np.ndarray, mask: np.ndarray, alpha: float = 0.55,
                 hide_ignore: bool = True) -> np.ndarray:
    """Blend a colourised mask over an RGB image."""
    image = np.asarray(image).astype(np.float32)
    color = colorize_mask(mask).astype(np.float32)
    blended = (1 - alpha) * image + alpha * color
    if hide_ignore:
        void = (mask == IGNORE_INDEX)[..., None]
        blended = np.where(void, image, blended)
    return np.clip(blended, 0, 255).astype(np.uint8)


def legend_handles(class_ids, max_items: int | None = None) -> list[Patch]:
    """Matplotlib patches for a class-id legend."""
    ids = list(class_ids)[: max_items] if max_items else list(class_ids)
    return [Patch(facecolor=np.array(ID_TO_COLOR[c]) / 255.0, edgecolor="black",
                  linewidth=0.4, label=f"{c}: {ID_TO_NAME[c]}") for c in ids]


def classes_in(mask: np.ndarray, min_pixels: int = 1,
               exclude_ignore: bool = True) -> list[int]:
    """Class ids present in a mask, ordered by descending pixel count."""
    ids, counts = np.unique(np.asarray(mask), return_counts=True)
    order = np.argsort(-counts)
    out = []
    for i in order:
        c = int(ids[i])
        if exclude_ignore and c == IGNORE_INDEX:
            continue
        if counts[i] >= min_pixels:
            out.append(c)
    return out


def show_sample(image: np.ndarray, mask: np.ndarray, title: str = "",
                save_path: Path | None = None, max_legend: int = 12):
    """Image | ground-truth mask | overlay, with a legend of present classes."""
    fig, axes = plt.subplots(1, 3, figsize=(19, 5.2))
    axes[0].imshow(image); axes[0].set_title("Image")
    axes[1].imshow(colorize_mask(mask)); axes[1].set_title("Ground-truth mask")
    axes[2].imshow(overlay_mask(image, mask)); axes[2].set_title("Overlay")
    for ax in axes:
        ax.axis("off")
    present = classes_in(mask)
    if present:
        fig.legend(handles=legend_handles(present, max_legend),
                   loc="lower center", ncol=min(6, max(1, len(present))),
                   fontsize=8, frameon=False, bbox_to_anchor=(0.5, -0.09))
    if title:
        fig.suptitle(title, fontsize=12)
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig


def comparison_row(image: np.ndarray, gt: np.ndarray, predictions: dict[str, np.ndarray],
                   title: str = "", save_path: Path | None = None,
                   overlay: bool = True, max_legend: int = 12):
    """One row: image | GT | each model prediction, all sharing the palette."""
    panels = [("Image", image), ("Ground truth", None)]
    panels += [(name, None) for name in predictions]
    n = len(panels)
    fig, axes = plt.subplots(1, n, figsize=(4.4 * n, 4.6))
    if n == 1:
        axes = [axes]

    axes[0].imshow(image); axes[0].set_title("Image")
    axes[1].imshow(overlay_mask(image, gt) if overlay else colorize_mask(gt))
    axes[1].set_title("Ground truth")
    for ax, (name, pred) in zip(axes[2:], predictions.items()):
        ax.imshow(overlay_mask(image, pred) if overlay else colorize_mask(pred))
        ax.set_title(name)
    for ax in axes:
        ax.axis("off")

    present = classes_in(gt)
    for p in predictions.values():
        present += [c for c in classes_in(p, min_pixels=64) if c not in present]
    if present:
        fig.legend(handles=legend_handles(present, max_legend), loc="lower center",
                   ncol=min(6, max(1, len(present[:max_legend]))), fontsize=8,
                   frameon=False, bbox_to_anchor=(0.5, -0.10))
    if title:
        fig.suptitle(title, fontsize=12)
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig


def plot_class_distribution(counts: dict[int, float], title: str,
                            save_path: Path | None = None, top_n: int | None = None,
                            log: bool = True):
    """Horizontal bar chart of per-class pixel share, in the palette colours."""
    items = [(c, v) for c, v in counts.items() if c != IGNORE_INDEX]
    items.sort(key=lambda kv: -kv[1])
    if top_n:
        items = items[:top_n]
    ids = [c for c, _ in items]
    vals = [v for _, v in items]
    colors = [np.array(ID_TO_COLOR[c]) / 255.0 for c in ids]
    labels = [f"{c}: {ID_TO_NAME[c]}" for c in ids]

    fig, ax = plt.subplots(figsize=(9, max(4, 0.28 * len(ids))))
    ax.barh(range(len(ids)), vals, color=colors, edgecolor="black", linewidth=0.4)
    ax.set_yticks(range(len(ids)))
    ax.set_yticklabels(labels, fontsize=8)
    ax.invert_yaxis()
    if log:
        ax.set_xscale("log")
    ax.set_xlabel("share of labelled pixels (%)" + (" - log scale" if log else ""))
    ax.set_title(title)
    ax.grid(axis="x", alpha=0.3)
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig


def plot_training_curves(history: dict, title: str, save_path: Path | None = None):
    """Loss and validation-mIoU curves from a training-history dict."""
    fig, axes = plt.subplots(1, 2, figsize=(13, 4.4))
    ep = history.get("epoch", list(range(1, len(history.get("train_loss", [])) + 1)))
    axes[0].plot(ep, history.get("train_loss", []), label="train loss", marker="o", ms=3)
    if history.get("val_loss"):
        axes[0].plot(ep, history["val_loss"], label="val loss", marker="s", ms=3)
    axes[0].set_xlabel("epoch"); axes[0].set_ylabel("loss")
    axes[0].set_title("Loss"); axes[0].legend(); axes[0].grid(alpha=0.3)

    if history.get("val_miou"):
        axes[1].plot(ep, history["val_miou"], label="val mIoU", marker="o",
                     ms=3, color="tab:green")
    if history.get("val_pixel_acc"):
        axes[1].plot(ep, history["val_pixel_acc"], label="val pixel acc",
                     marker="s", ms=3, color="tab:blue")
    axes[1].set_xlabel("epoch"); axes[1].set_ylabel("score")
    axes[1].set_title("Validation metrics"); axes[1].legend(); axes[1].grid(alpha=0.3)
    fig.suptitle(title)
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig


def plot_confusion_matrix(cm: np.ndarray, class_ids: list[int], title: str,
                          save_path: Path | None = None, normalize: bool = True,
                          top_n: int | None = 20, supports: np.ndarray | None = None):
    """Row-normalised confusion matrix over the most frequent classes.

    With 39 classes a full matrix is unreadable, so by default the `top_n`
    classes by ground-truth support are shown.
    """
    ids = list(class_ids)
    if top_n and len(ids) > top_n:
        if supports is None:
            supports = cm[np.ix_(ids, ids)].sum(axis=1)
        order = np.argsort(-np.asarray(supports))[:top_n]
        ids = [ids[i] for i in order]

    sub = cm[np.ix_(ids, ids)].astype(np.float64)
    if normalize:
        rows = sub.sum(axis=1, keepdims=True)
        sub = np.divide(sub, rows, out=np.zeros_like(sub), where=rows > 0)

    fig, ax = plt.subplots(figsize=(max(8, 0.5 * len(ids)), max(7, 0.45 * len(ids))))
    im = ax.imshow(sub, cmap="viridis", vmin=0, vmax=1 if normalize else None)
    labels = [f"{c}: {ID_TO_NAME[c]}" for c in ids]
    ax.set_xticks(range(len(ids))); ax.set_xticklabels(labels, rotation=90, fontsize=7)
    ax.set_yticks(range(len(ids))); ax.set_yticklabels(labels, fontsize=7)
    ax.set_xlabel("predicted"); ax.set_ylabel("ground truth")
    ax.set_title(title)
    fig.colorbar(im, ax=ax, fraction=0.046, label="row-normalised share" if normalize else "pixels")
    fig.tight_layout()
    if save_path:
        Path(save_path).parent.mkdir(parents=True, exist_ok=True)
        fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig


def save_palette_legend(save_path: Path, class_ids=None):
    """Standalone legend figure mapping every class id to its colour."""
    ids = list(class_ids) if class_ids is not None else [
        c for c in sorted(ID_TO_NAME) if c != IGNORE_INDEX]
    fig, ax = plt.subplots(figsize=(11, max(4, 0.3 * len(ids) / 2)))
    ax.axis("off")
    ax.legend(handles=legend_handles(ids), loc="center", ncol=3, fontsize=9,
              frameon=False)
    ax.set_title("CoralScapes class id -> colour (official palette)")
    fig.tight_layout()
    Path(save_path).parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(save_path, dpi=130, bbox_inches="tight")
    return fig
